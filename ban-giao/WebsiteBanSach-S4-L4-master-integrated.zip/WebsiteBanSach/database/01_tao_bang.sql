/* =====================================================================
   Cơ sở dữ liệu website bán sách – phạm vi chức năng mức M
   Hệ quản trị: SQL Server (chạy được trên LocalDB / SSMS localhost)
   Cơ sở dữ liệu: NhaSachOnline_S3 (khớp chuỗi kết nối trong NhaSachOnline/appsettings.json)
   Chạy file này trước, sau đó chạy 02_du_lieu_mau.sql
   Quy ước trạng thái ghi ngay trong chú thích từng cột.
   ===================================================================== */
SET QUOTED_IDENTIFIER ON;   -- bắt buộc cho chỉ mục lọc (UX_Sach_ISBN) khi chạy bằng sqlcmd
SET ANSI_NULLS ON;
GO
IF DB_ID(N'NhaSachOnline_S3') IS NULL CREATE DATABASE NhaSachOnline_S3;
GO
USE NhaSachOnline_S3;
GO

/* Xóa bảng theo thứ tự ngược khóa ngoại để chạy lại được nhiều lần */
DROP TABLE IF EXISTS DieuChinhCOD, PhieuThuCOD, DangKyBaoCoHang, YeuCauHuy, LichSuSuaDon,
    LanGoiXacNhan, CuonSach, ChiTietDon, DonHang, GioHang, ChiTietLoNhap, LoNhap, DeXuatGia,
    SachTacGia, Sach, TacGia, NhaXuatBan, TheLoai, DiaChiKhachHang, KhachHang, NhanVien,
    TaiKhoan, BangPhiGiao;
DROP VIEW IF EXISTS vw_TongTienDon;
GO

/* ---------- Nhóm tài khoản ---------- */
CREATE TABLE TaiKhoan (
    MaTaiKhoan   INT IDENTITY(1,1) PRIMARY KEY,
    Email        NVARCHAR(100) NOT NULL UNIQUE,          -- dùng để đăng nhập (nhóm chốt 14/10/2026: email, không dùng số điện thoại)
    MatKhauHash  NVARCHAR(255) NOT NULL,
    VaiTro       TINYINT NOT NULL CHECK (VaiTro BETWEEN 1 AND 4),   -- 1 khách hàng, 2 nhân viên, 3 kế toán, 4 quản lý
    TrangThai    TINYINT NOT NULL DEFAULT 1 CHECK (TrangThai IN (0,1)), -- 0 bị khóa, 1 đang hoạt động
    NgayTao      DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

CREATE TABLE KhachHang (
    MaKhachHang  INT IDENTITY(1,1) PRIMARY KEY,
    MaTaiKhoan   INT NOT NULL UNIQUE REFERENCES TaiKhoan(MaTaiKhoan),  -- quan hệ 1–1 với tài khoản
    HoTen        NVARCHAR(100) NOT NULL,
    SoDienThoai  VARCHAR(15) NOT NULL
);

/* Một khách có nhiều địa chỉ: tách bảng con để không đa trị (1NF) */
CREATE TABLE DiaChiKhachHang (
    MaDiaChi       INT IDENTITY(1,1) PRIMARY KEY,
    MaKhachHang    INT NOT NULL REFERENCES KhachHang(MaKhachHang),
    TenNguoiNhan   NVARCHAR(100) NOT NULL,
    SoDienThoai    VARCHAR(15) NOT NULL,
    DiaChiChiTiet  NVARCHAR(255) NOT NULL,
    TinhThanh      NVARCHAR(50) NOT NULL,
    MacDinh        BIT NOT NULL DEFAULT 0
);

/* Nhân viên, kế toán, quản lý đều là người nội bộ; phân biệt bằng VaiTro của tài khoản */
CREATE TABLE NhanVien (
    MaNhanVien   INT IDENTITY(1,1) PRIMARY KEY,
    MaTaiKhoan   INT NOT NULL UNIQUE REFERENCES TaiKhoan(MaTaiKhoan),
    HoTen        NVARCHAR(100) NOT NULL,
    SoDienThoai  VARCHAR(15) NULL
);

/* ---------- Nhóm sách và kho ---------- */
CREATE TABLE TheLoai (
    MaTheLoai   INT IDENTITY(1,1) PRIMARY KEY,
    TenTheLoai  NVARCHAR(100) NOT NULL UNIQUE,
    TrangThai   TINYINT NOT NULL DEFAULT 1 CHECK (TrangThai IN (0,1))  -- 0 ẩn, 1 hiển thị
);

CREATE TABLE NhaXuatBan (
    MaNXB   INT IDENTITY(1,1) PRIMARY KEY,
    TenNXB  NVARCHAR(150) NOT NULL UNIQUE
);

CREATE TABLE TacGia (
    MaTacGia   INT IDENTITY(1,1) PRIMARY KEY,
    TenTacGia  NVARCHAR(150) NOT NULL
);

/* Mỗi dòng là một ấn bản (sản phẩm). Từng cuốn vật lý nằm ở bảng CuonSach. */
CREATE TABLE Sach (
    MaSach           INT IDENTITY(1,1) PRIMARY KEY,
    ISBN             VARCHAR(13) NULL,
    TenSach          NVARCHAR(200) NOT NULL,
    MaTheLoai        INT NOT NULL REFERENCES TheLoai(MaTheLoai),
    MaNXB            INT NOT NULL REFERENCES NhaXuatBan(MaNXB),
    NamXuatBan       SMALLINT NOT NULL CHECK (NamXuatBan BETWEEN 1900 AND 2100),
    HinhThuc         TINYINT NOT NULL CHECK (HinhThuc IN (1,2)),        -- 1 bìa mềm, 2 bìa cứng
    SoTrang          INT NULL CHECK (SoTrang > 0),
    KhoiLuongGram    INT NOT NULL DEFAULT 300 CHECK (KhoiLuongGram > 0), -- dùng tính phí giao
    MoTa             NVARCHAR(MAX) NULL,
    AnhBia           NVARCHAR(300) NULL,
    GiaBan           DECIMAL(12,0) NOT NULL CHECK (GiaBan > 0),
    SoLuongCoTheBan  INT NOT NULL DEFAULT 0 CHECK (SoLuongCoTheBan >= 0),
    NguongSapHet     INT NOT NULL DEFAULT 5 CHECK (NguongSapHet >= 0),
    TrangThai        TINYINT NOT NULL DEFAULT 2 CHECK (TrangThai BETWEEN 0 AND 3),
                     -- 0 ẩn, 1 đang hiển thị, 2 chờ quản lý duyệt, 3 ngừng kinh doanh
    NgayTao          DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    NgayCapNhat      DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    NguoiTao         INT NOT NULL REFERENCES NhanVien(MaNhanVien),
    NguoiCapNhat     INT NOT NULL REFERENCES NhanVien(MaNhanVien)
);
CREATE UNIQUE INDEX UX_Sach_ISBN ON Sach(ISBN) WHERE ISBN IS NOT NULL;
CREATE INDEX IX_Sach_NgayCapNhat ON Sach(NgayCapNhat DESC);  -- danh sách mặc định sắp theo ngày cập nhật

/* Một sách có nhiều tác giả, một tác giả viết nhiều sách: bảng trung gian (nhiều–nhiều) */
CREATE TABLE SachTacGia (
    MaSach    INT NOT NULL REFERENCES Sach(MaSach),
    MaTacGia  INT NOT NULL REFERENCES TacGia(MaTacGia),
    PRIMARY KEY (MaSach, MaTacGia)
);

/* Đề xuất đổi giá chờ quản lý duyệt (UC28) */
CREATE TABLE DeXuatGia (
    MaDeXuat     INT IDENTITY(1,1) PRIMARY KEY,
    MaSach       INT NOT NULL REFERENCES Sach(MaSach),
    GiaCu        DECIMAL(12,0) NOT NULL,
    GiaMoi       DECIMAL(12,0) NOT NULL CHECK (GiaMoi > 0),
    NguoiDeXuat  INT NOT NULL REFERENCES NhanVien(MaNhanVien),
    NgayDeXuat   DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    TrangThai    TINYINT NOT NULL DEFAULT 0 CHECK (TrangThai IN (0,1,2)), -- 0 chờ duyệt, 1 đã duyệt, 2 từ chối
    NguoiDuyet   INT NULL REFERENCES NhanVien(MaNhanVien),
    NgayDuyet    DATETIME2 NULL,
    LyDo         NVARCHAR(255) NULL
);

CREATE TABLE LoNhap (
    MaLo       INT IDENTITY(1,1) PRIMARY KEY,
    NgayNhap   DATE NOT NULL,
    NguoiNhap  INT NOT NULL REFERENCES NhanVien(MaNhanVien),
    GhiChu     NVARCHAR(255) NULL
);

/* Một lô có nhiều sách, một sách nhập qua nhiều lô: bảng trung gian */
CREATE TABLE ChiTietLoNhap (
    MaLo      INT NOT NULL REFERENCES LoNhap(MaLo),
    MaSach    INT NOT NULL REFERENCES Sach(MaSach),
    SoLuong   INT NOT NULL CHECK (SoLuong > 0),
    GiaNhap   DECIMAL(12,0) NOT NULL CHECK (GiaNhap > 0),
    PRIMARY KEY (MaLo, MaSach)
);

/* ---------- Nhóm giỏ hàng và đơn hàng ---------- */
CREATE TABLE GioHang (
    MaKhachHang  INT NOT NULL REFERENCES KhachHang(MaKhachHang),
    MaSach       INT NOT NULL REFERENCES Sach(MaSach),
    SoLuong      INT NOT NULL CHECK (SoLuong > 0),
    NgayThem     DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    PRIMARY KEY (MaKhachHang, MaSach)
);

/* Thông tin người nhận lưu trên đơn: nhân viên có thể sửa riêng đơn này (UC29) */
CREATE TABLE DonHang (
    MaDon            INT IDENTITY(1,1) PRIMARY KEY,
    MaKhachHang      INT NOT NULL REFERENCES KhachHang(MaKhachHang),
    NgayDat          DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    TrangThai        TINYINT NOT NULL DEFAULT 1 CHECK (TrangThai BETWEEN 1 AND 5),
                     -- 1 chờ xác nhận, 2 đã xác nhận, 3 đang giao, 4 hoàn tất, 5 đã hủy
    TenNguoiNhan     NVARCHAR(100) NOT NULL,
    SoDienThoaiNhan  VARCHAR(15) NOT NULL,
    DiaChiNhan       NVARCHAR(255) NOT NULL,
    TinhThanh        NVARCHAR(50) NOT NULL,
    PhiGiao          DECIMAL(12,0) NOT NULL CHECK (PhiGiao >= 0),  -- chốt lúc đặt vì bảng phí có thể đổi
    LyDoHuy          NVARCHAR(255) NULL,
    NgayCapNhat      DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    NguoiCapNhat     INT NULL REFERENCES NhanVien(MaNhanVien)
);

/* Một đơn có nhiều sách, một sách nằm trong nhiều đơn: bảng trung gian, khóa gồm 2 mã */
CREATE TABLE ChiTietDon (
    MaDon    INT NOT NULL REFERENCES DonHang(MaDon),
    MaSach   INT NOT NULL REFERENCES Sach(MaSach),
    SoLuong  INT NOT NULL CHECK (SoLuong > 0),
    DonGia   DECIMAL(12,0) NOT NULL CHECK (DonGia > 0),  -- giá tại lúc đặt, không đổi theo giá mới
    PRIMARY KEY (MaDon, MaSach)
);

/* Từng cuốn vật lý: mã riêng; khi đóng gói được gắn vào đúng dòng đơn */
CREATE TABLE CuonSach (
    MaCuon     VARCHAR(20) PRIMARY KEY,
    MaSach     INT NOT NULL REFERENCES Sach(MaSach),
    MaLo       INT NOT NULL REFERENCES LoNhap(MaLo),
    TrangThai  TINYINT NOT NULL DEFAULT 1 CHECK (TrangThai BETWEEN 1 AND 5),
               -- 1 trong kho, 2 đã gắn vào đơn, 3 đã giao, 4 khách trả lại, 5 hỏng
    MaDon      INT NULL,
    CONSTRAINT FK_CuonSach_ChiTietDon FOREIGN KEY (MaDon, MaSach) REFERENCES ChiTietDon(MaDon, MaSach)
);

CREATE TABLE LanGoiXacNhan (
    MaLanGoi     INT IDENTITY(1,1) PRIMARY KEY,
    MaDon        INT NOT NULL REFERENCES DonHang(MaDon),
    MaNhanVien   INT NOT NULL REFERENCES NhanVien(MaNhanVien),
    ThoiGianGoi  DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    KetQua       TINYINT NOT NULL CHECK (KetQua IN (1,2,3)),  -- 1 đã liên hệ được, 2 không nghe máy, 3 sai số
    GhiChu       NVARCHAR(255) NULL
);

CREATE TABLE LichSuSuaDon (
    MaLichSu       INT IDENTITY(1,1) PRIMARY KEY,
    MaDon          INT NOT NULL REFERENCES DonHang(MaDon),
    TruongThayDoi  NVARCHAR(50) NOT NULL,      -- tên người nhận, số điện thoại hoặc địa chỉ
    GiaTriCu       NVARCHAR(255) NOT NULL,
    GiaTriMoi      NVARCHAR(255) NOT NULL,
    LyDo           NVARCHAR(255) NOT NULL,
    MaNhanVien     INT NOT NULL REFERENCES NhanVien(MaNhanVien),
    ThoiGian       DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

/* Trạng thái yêu cầu hủy theo dõi riêng, không lẫn với trạng thái đơn */
CREATE TABLE YeuCauHuy (
    MaYeuCau       INT IDENTITY(1,1) PRIMARY KEY,
    MaDon          INT NOT NULL UNIQUE REFERENCES DonHang(MaDon),
    ThoiDiemGui    DATETIME2 NOT NULL DEFAULT SYSDATETIME(),   -- hạn 2 giờ tính theo mốc này
    LyDo           NVARCHAR(255) NULL,
    TrangThai      TINYINT NOT NULL DEFAULT 0 CHECK (TrangThai IN (0,1,2)), -- 0 chờ duyệt, 1 đã duyệt, 2 từ chối
    LyDoTuChoi     NVARCHAR(255) NULL,
    NguoiDuyet     INT NULL REFERENCES NhanVien(MaNhanVien),
    ThoiDiemDuyet  DATETIME2 NULL
);

CREATE TABLE DangKyBaoCoHang (
    MaDangKy    INT IDENTITY(1,1) PRIMARY KEY,
    MaSach      INT NOT NULL REFERENCES Sach(MaSach),
    Email       NVARCHAR(100) NOT NULL,
    NgayDangKy  DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    DaGui       BIT NOT NULL DEFAULT 0,
    NgayGui     DATETIME2 NULL,
    CONSTRAINT UQ_DangKy UNIQUE (MaSach, Email)
);

/* ---------- Nhóm tiền COD ---------- */
CREATE TABLE PhieuThuCOD (
    MaPhieuThu      INT IDENTITY(1,1) PRIMARY KEY,
    MaDon           INT NOT NULL UNIQUE REFERENCES DonHang(MaDon),
    SoTienThucNhan  DECIMAL(12,0) NULL,           -- NULL khi tiền chưa về nhà sách
    NgayNhan        DATE NULL,
    DonViBanGiao    NVARCHAR(100) NULL,
    MaKeToan        INT NULL REFERENCES NhanVien(MaNhanVien),
    TrangThai       TINYINT NOT NULL DEFAULT 0 CHECK (TrangThai IN (0,1,2))  -- 0 chưa thu, 1 đã thu đủ, 2 bị lệch
);

CREATE TABLE DieuChinhCOD (
    MaDieuChinh  INT IDENTITY(1,1) PRIMARY KEY,
    MaPhieuThu   INT NOT NULL REFERENCES PhieuThuCOD(MaPhieuThu),
    SoTien       DECIMAL(12,0) NOT NULL,
    LyDo         NVARCHAR(255) NOT NULL,
    MaKeToan     INT NOT NULL REFERENCES NhanVien(MaNhanVien),
    ThoiGian     DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

/* Biểu phí giao tham khảo SPX theo tuyến */
CREATE TABLE BangPhiGiao (
    Tuyen            TINYINT PRIMARY KEY CHECK (Tuyen BETWEEN 1 AND 4), -- 1 nội tỉnh, 2 nội miền, 3 đặc biệt, 4 liên miền
    TenTuyen         NVARCHAR(50) NOT NULL,
    PhiDen1000g      DECIMAL(12,0) NOT NULL,
    PhiDen1500g      DECIMAL(12,0) NOT NULL,
    PhiDen2000g      DECIMAL(12,0) NOT NULL,
    PhiMoi500gTiep   DECIMAL(12,0) NOT NULL
);
GO

/* Tổng tiền không lưu trong DonHang (tránh lưu dữ liệu tính được, đúng 3NF): tính bằng view */
CREATE VIEW vw_TongTienDon AS
SELECT d.MaDon,
       SUM(c.SoLuong * c.DonGia)             AS TongTienSach,
       d.PhiGiao,
       SUM(c.SoLuong * c.DonGia) + d.PhiGiao AS TongThanhToan
FROM DonHang d JOIN ChiTietDon c ON c.MaDon = d.MaDon
GROUP BY d.MaDon, d.PhiGiao;
GO
