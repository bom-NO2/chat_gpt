# Kết quả S4-Y4 theo master

Ngày 19/10/2026. .NET SDK 10.0.402, ASP.NET Core MVC .NET 10, EF Core 10.0.13.

- Build: 0 lỗi. Có cảnh báo CS8602 ở các dòng 47/50 của Index và cảnh báo NuGet NU1902/NU1903 cho phụ thuộc Pkcs 9.0.11. Build riêng master gốc cũng có các cảnh báo này; không sửa các phần chung ngoài phạm vi Y4.
- **52/52 kiểm tra tự động đạt**, qua TestServer + Session của ASP.NET Core + SQLite tạm.
- **20/20 kiểm tra chiều rộng đạt**, Chromium ở 1366 và 360 px; không tràn ngang. Có kiểm tra nút cộng/trừ số lượng và hủy xác nhận không khóa nút.
- Kiểm tra byte: các tệp được bảo vệ giữ nguyên; bỏ khối Y4 khỏi controller thu đúng controller gốc.

| Ca | Mong đợi | Thực tế / bằng chứng |
|---|---|---|
| TC09 | Khách có nút Mua ngay/Thêm vào giỏ; không thấy số tồn | Đạt. Hai nút khóa vì giỏ/đơn chưa thuộc Sprint 4. TC09-khach-*.png |
| TC15 | Không ẩn sách chờ duyệt; ẩn rồi hiện sách đang bán | Đạt. TC15-khong-an-cho-duyet, TC15-truoc-an, TC15-sau-an, TC15-hien-lai |
| TC16 | Nhân viên gọi duyệt bị chặn; quản lý duyệt được; khách thấy sách sau duyệt | Đạt. HTTP 403, trạng thái vẫn 2 trước khi quản lý duyệt; sau duyệt là 1, khách nhận HTTP 200. TC16-*.png |
| TC17 theo cập nhật 17/10 | Xóa → 3, giữ dữ liệu; khôi phục → 0 | Đạt trên SQLite; đơn giá cũ 180000 và bản ghi đề xuất giá không mất. Sách mới không liên quan cũng giữ bản ghi. TC17-*.png |
| Gửi lại thao tác / tab cũ | Không tự hiện ngược hoặc ghi đè thay đổi mới | Đạt |
| Nhân viên gọi thẳng Xoa/KhoiPhuc | HTTP 403 | Đạt |
| Thiếu token CSRF / gọi GET Xoa | HTTP 400 / 405 | Đạt |
| Khách truy cập sách ẩn, chờ duyệt, ngừng kinh doanh | HTTP 404 | Đạt |

Mỗi nhóm ảnh có bản 1366 và 360. Ảnh TC16-tu-choi là nguyên văn phản hồi 403 dạng văn bản của server; mã HTTP được xác nhận riêng trong assertion, không vẽ giả màn hình lỗi.

Ảnh dùng dữ liệu thử trong SQLite và HTML do MVC render, không phải nghiệm thu SQL Server đang chạy. Bảng ChiTietDon trong fixture là bảng đối chứng đơn giản. Chưa kiểm tra provider SQL Server, dữ liệu thật, đăng nhập thật, giỏ/đơn hàng. Chưa có file đặc tả TC bản 17/10 đầy đủ; TC09/15/16 bám mô tả ca trong báo cáo tham khảo, TC17 áp dụng điều chỉnh mới trong nhận xét/yêu cầu.

Bằng chứng đầy đủ: ket_qua_tu_dong.json, kiem_tra_giao_dien.json, kiem_tra_giu_nguyen.json, build.log, build-master-goc.log. Bộ kiểm tra đặt ngoài dự án ứng dụng để không thêm thành phần vào Program.cs.

Nhãn “Vai: Khách” trên thanh đầu trang ở ảnh nội bộ là chữ mặc định/localStorage trong layout master, không phải vai Session dùng để xét quyền. Không sửa phần đó theo review; bộ kiểm tra đổi Session thật qua Index?vaitro và đã xác nhận quyền/HTTP status.
