# S4-L4 – Thêm sách, tích hợp trên master của nhóm

## Trạng thái

Đã ghép vào mã thật từ `WebsiteBanSach-master.zip`, nhánh cục bộ `lam`. Đây là bản thay thế bản dựng từ gói tham khảo trước đó. Không có lịch sử GitHub trong ZIP.

- GET và POST thêm sách kiểm tra vai trò Session, có CSRF.
- Nhân viên tạo sách chờ quản lý duyệt, quản lý tạo sách đang bán. Mã/creator/trạng thái lấy phía server.
- Biểu mẫu thêm/sửa dùng chung; tác giả nhiều dòng, bỏ dòng rỗng và tác giả trùng, so trùng cả bộ theo helper K1 của master.
- Kiểm tra ISBN, danh mục, khoảng dữ liệu, file ảnh. File sai hiển thị lỗi ở ô ảnh. File phải chọn lại sau lỗi; dữ liệu văn bản/số/dropdown được giữ lại.
- Sách vừa lưu đứng đầu trang 1, có dòng xanh. Phân trang tối thiểu 50 dòng; thứ tự tên vẫn giữ cho các dòng còn lại. Khi đi trang khác, vuaLuu không tiếp tục ghim sách đó. Đây chưa phải toàn bộ S4-K3.
- Sửa/chi tiết/duyệt/ẩn/xóa/khôi phục của nhóm được giữ nguyên; shared helper và điểm nối danh sách có thay đổi được nêu dưới đây.

## Những file chính cần review

| File | Thay đổi |
|---|---|
| Controllers/SachController.cs | Thêm Them GET/POST, bổ sung kiểm tra chung, điểm nối danh sách |
| Views/Sach/Them.cshtml | Trang thêm mới |
| Views/Sach/_BieuMau.cshtml | Hiển thị đủ lỗi, bước giá 1 đồng; commit riêng 1484fe9 |
| Models/SachViewModels.cs và Views/Sach/Index.cshtml | Phân trang tối thiểu, nút thêm và đưa sách vừa lưu đầu trang |
| Controllers/VaiTroController.cs | Đổi tên từ file `vaitrocontroller` không được biên dịch, POST đổi Session |
| Views/Shared/_Layout.cshtml | Nút đổi vai gửi POST thay localStorage, đọc nhãn từ Session |
| NhaSachOnline.csproj | Ghim dependency Pkcs để loại cảnh báo bảo mật NuGet |
| AppMarker.cs, tests/S4L4, NhaSachOnline.slnx | Bộ kiểm thử HTTP và browser test host |
| .gitignore | Bỏ qua ảnh upload thực tế trong images/bia |

Các sửa K1/U1 là điểm nối cần thiết đã phát hiện khi chạy thực tế: nút đổi vai cũ không có tác động lên quyền server. Đây vẫn là cơ chế thử vai cho bài tập; chưa phải xác thực tài khoản production.

## Chạy ứng dụng với SQL Server

1. Cài .NET SDK 10 và SQL Server; mở `NhaSachOnline.slnx` hoặc dùng CLI.
2. Chạy `database/01_tao_bang.sql`, rồi `02_du_lieu_mau.sql` trên CSDL thử. Script tạo bảng xóa và tạo lại dữ liệu, không chạy trên CSDL cần giữ.
3. appsettings của nhóm dùng Windows Authentication localhost, CSDL `NhaSachOnline_S3`. Máy khác cấu hình bằng user-secrets hoặc biến `ConnectionStrings__NhaSach`; không commit mật khẩu.
4. `dotnet run --project NhaSachOnline`.
5. Bấm nút Vai theo vòng Khách → Nhân viên → Quản lý → Khách. Nhân viên/quản lý thấy nút Thêm sách ở danh sách.

## Chạy lại kiểm thử

Tại thư mục repository:

```sh
dotnet build NhaSachOnline.slnx --configuration Release
dotnet run --project tests/S4L4/S4L4.csproj --configuration Release --no-build
```

Đây là test runner console: có assertion lỗi sẽ thoát khác 0. Không dùng `dotnet test` để báo đã chạy các ca này.
Mặc định test host dùng EF InMemory, có 55 sách và danh mục giả. Khi có SQL Server: tạo CSDL thử riêng bằng hai script của nhóm, cấu hình `S4L4_TEST_SQL_CONNECTION` qua môi trường rồi chạy lại cùng runner. Test sẽ thêm dữ liệu, không tự xóa CSDL. Chỉ dùng CSDL dùng một lần, không trỏ vào dữ liệu cần giữ.

Trình duyệt (hai terminal):

```sh
# Terminal 1: host dùng dữ liệu kiểm thử, không cần SQL Server
dotnet run --project tests/S4L4/S4L4.csproj --configuration Release --no-build -- --browser-host
# Terminal 2: cần Python Playwright và Chromium
python tests/S4L4/browser.py
```

Host chạy port 5000, chỉ dùng để kiểm thử. Script dùng `/usr/bin/chromium` mặc định; có thể đặt `CHROMIUM_PATH`. Đặt `S4L4_BROWSER_URL` nếu đổi địa chỉ. Dừng host bằng Ctrl+C khi xong. Ảnh bằng chứng ghi vào docs/S4-L4/screenshots. Không nhập thông tin thật vào host InMemory.

Trong cloud phiên này: SDK `/workspace/.dotnet/dotnet`, đặt `DOTNET_CLI_HOME=/workspace/.dotnet-home`, `NUGET_PACKAGES=/workspace/.nuget` khi home chỉ đọc.

## Bằng chứng thực tế

| Kiểm tra | Kết quả |
|---|---|
| Build Release | Qua, 0 lỗi; 2 cảnh báo nullable có sẵn ở tìm kiếm |
| Runner HTTP | 38 kiểm tra qua, gồm TC10–TC13, TC12b, CSRF, danh mục sai, ảnh sai/ảnh hợp lệ, sửa sách, phân vai |
| Chromium desktop 1366px/mobile 390px | 10 kiểm tra qua; thêm/bớt tác giả, đổi Session thật, báo lỗi đúng ô, giữ giá, sách đầu trang tô sáng, không tràn ngang form |
| SQL Server | Chưa chạy: tải image Microsoft trả Forbidden |
| Push và PR | Chưa làm được: GitHub trả 403 qua cấu hình truy cập hiện tại |

Logs mới ở `evidence/`, ảnh mới ở `screenshots/`. Test TC13 bằng browser tắt client validation cho một lần submit để chứng minh server trả đủ lỗi; không tắt validation trong mã sản phẩm. Lượt thêm hợp lệ và TC12 dùng tương tác trình duyệt bình thường.

## Áp dụng vào GitHub thật

Không force-push Git bundle dựng từ ZIP. Bản vá cuối được cung cấp bên ngoài ZIP mã nguồn dưới tên `S4-L4-master-integrated.patch`, chỉ gồm thay đổi so với master ZIP bạn đã gửi.

Trong một clone mới của repo thật, cập nhật master và chuyển sang nhánh lam (nếu lam đã tồn tại thì checkout lam và hợp nhất master theo quy trình nhóm, không tạo đè). Kiểm tra cây làm việc sạch, rồi:

```sh
git apply --check /duong-dan/S4-L4-master-integrated.patch
# Nếu kiểm tra qua:
git apply /duong-dan/S4-L4-master-integrated.patch
# Commit biểu mẫu trước, bằng tài khoản Git của Lâm:
git add NhaSachOnline/Views/Sach/_BieuMau.cshtml
git commit -m "S4-L4: Bieu mau dung chung cho them va sua"
# Sau khi review thay đổi còn lại và chạy test:
git add NhaSachOnline.slnx .gitignore NhaSachOnline tests docs/S4-L4 docs/prompt/lam-s4-l4.md README.md
git commit -m "S4-L4: Hoan thien them sach va kiem thu"
git push -u origin lam
```

Nếu master đã thay đổi và `git apply --check` báo xung đột, dừng áp dụng tự động và đối chiếu file; không ghi đè cả controller/layout bằng bản ZIP. Gửi `_BieuMau.cshtml`/commit đầu cho Hùng ngay khi push được. Tạo PR `lam` → `master`, nội dung gợi ý ở `PR.md`; thêm link thẻ Trello thật nếu có. Nhật ký AI ở `docs/prompt/lam-s4-l4.md`.

Chỉ đánh dấu thẻ Pass sau khi người kiểm tra xác nhận SQL Server và PR theo quy trình nhóm.
