# S4-L4: thêm sách, biểu mẫu dùng chung và kiểm tra dữ liệu

Nhân viên thêm sách hợp lệ sẽ tạo sách chờ duyệt, trở về trang 1 với dòng mới đứng đầu và tô sáng. Trang thêm dùng chung _BieuMau với sửa sách, hỗ trợ nhiều tác giả, ảnh bìa và lỗi từng ô giữ dữ liệu đã nhập. Kiểm tra trùng cả bộ tên + tập tác giả + NXB + năm + hình thức bằng helper K1 hiện có.

Ghép vào master thực tế, giữ nguyên xử lý sửa/chi tiết/duyệt/ẩn/xóa/khôi phục. Bổ sung kiểm tra danh mục và tên tác giả theo SQL, ISBN chữ số, lỗi ảnh. Nối nút đổi vai với Session (controller đầu vào thiếu đuôi .cs, nút cũ chỉ đổi localStorage), thêm phân trang 50 dòng tối thiểu cho điều kiện trang 1. Các điểm nối K1/U1/U4 cần nhóm review chung; không thay toàn bộ phần K3.

Validation: build Release qua; 38 kiểm tra MVC HTTP và 10 Chromium desktop/mobile qua với EF InMemory. Chưa xác minh SQL Server thật do Docker registry trả Forbidden. Xem docs/S4-L4/evidence và screenshots.

Biểu mẫu có commit riêng để bàn giao Hùng. Nhật ký AI: docs/prompt/lam-s4-l4.md. Thêm link thẻ Trello thật khi tạo PR.

Đây là nội dung PR chuẩn bị sẵn; không phải xác nhận đã push hoặc tạo PR. GitHub hiện trả 403 trong phiên làm việc.
