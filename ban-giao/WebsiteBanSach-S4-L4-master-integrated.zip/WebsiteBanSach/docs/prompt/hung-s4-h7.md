# Nhật ký sử dụng AI – S4-H7 Lập trình phần 4: Sửa sách và đề xuất giá

> Mẫu 04 của nhóm (thẻ S4-H1). Thầy cho dùng AI nhưng thành viên phải cho thầy biết đã prompt thế nào và phải tự review lại. Thiếu file này thì thẻ không được Pass.

## 1. Thông tin chung

| Mục | Nội dung |
|---|---|
| Mã thẻ, tên thẻ | S4-H7 · Lập trình phần 4: Sửa sách và đề xuất giá |
| Người làm | Vũ Đình Hùng |
| Công cụ AI (tên, phiên bản hoặc gói) | Claude Code (mô hình Claude Opus) trong ứng dụng Claude trên máy tính |
| Thời gian dùng (từ – đến) | 18/10/2026, khoảng 21:00 – 21:30 (giờ Việt Nam) |
| Nhánh, commit có dùng kết quả AI | Nhánh `hung` (tạo tiếp từ nhánh `huyen` để có Model, CSDL của S4-L2 và Common của S4-K1), commit S4-H7 |

## 2. Các lượt hỏi AI

### Lượt 1 – 18/10/2026

- **Mục đích:** nhờ AI làm thẻ S4-H7 trước, sau đó làm S4-H6.
- **Prompt nguyên văn:**

```text
Làm S4-H7 trước giúp mình nhé, xong rồi làm S4-H6 nha claude :D
```

- **AI trả lời (tóm tắt):** đọc thẻ S4-H7, code tham khảo bản Sprint 2 (`SachController` hàm `Sua`, `Sua.cshtml`, `_BieuMau.cshtml`) và nhánh `huyen` (đã có Model, CSDL lấy từ S4-L2, lớp dùng chung của S4-K1). Báo rằng biểu mẫu `_BieuMau`, lớp `SachBieuMau` và các hàm kiểm tra thuộc thẻ S4-L4 của Lâm nhưng Lâm chưa làm, nên hỏi Hùng cách xử lý.

### Lượt 2 – 18/10/2026 (trả lời câu hỏi của AI)

- **Mục đích:** chọn cách xử lý phần biểu mẫu chung và cách đưa code lên GitHub.
- **Nội dung trả lời:**

```text
Phần biểu mẫu: Hùng làm phần chung (AI đề xuất).
Git: Hãy hướng dẫn mình tạo nhánh, commit trên máy và push hoặc tạo PR (mà PR là gì vậy cậu?)
```

- **AI trả lời (tóm tắt):** viết `Models/SachBieuMau.cs`, `Views/Sach/_BieuMau.cshtml`, `Views/Sach/Sua.cshtml`, thêm hàm `Sua` (GET, POST) và các hàm hỗ trợ `KiemTraBieuMau`, `LayTacGia`, `NapDanhMuc`, `GanThongTin` vào `SachController`, dùng lại `VaiTroHienTai`, `KiemTraDinhDang`, `LuuAnh` của Kiệt; thêm nút “Sửa” ở bảng danh sách của nhân viên. Chạy thử trên CSDL riêng `NhaSachOnline_S4_Test` (không đụng CSDL bản Sprint 3), script tự động đạt 19/19 ca, chụp ảnh trước và sau khi sửa. Hướng dẫn Hùng tự tạo nhánh, commit, push và tạo pull request.

- **Phần giữ lại:** _toàn bộ_
- **Phần tự sửa và lý do:** _không có_
- **Phần bỏ đi và lý do:** _không có_

## 3. Tự kiểm tra sau khi dùng AI

- [ ] Đã đọc hiểu từng dòng code của hàm `Sua` và giải thích được khi thầy hỏi.
- [x] Đã chạy thử: TC14 (mã giả 999 bị bỏ qua, giá nhân viên đổi thành đề xuất, khách vẫn thấy giá cũ), quản lý đổi giá áp dụng ngay, sửa thành trùng cả bộ bị chặn, thêm và bớt tác giả lưu đúng, nhập sai báo từng lỗi và giữ dữ liệu.
- [x] Không dán mật khẩu, khóa bí mật, dữ liệu cá nhân thật vào prompt.
- [ ] Phần AI viết đã được ghi nguồn trong báo cáo cá nhân (mẫu 06) – làm ở thẻ S4-03.

## 4. Cam kết

Tôi xác nhận nhật ký này ghi đúng và đủ các lượt dùng AI cho thẻ trên.

Người làm: Vũ Đình Hùng  Ngày: 18/10/2026
