# Nhật ký AI – Lâm – S4-L4

Ngày bàn giao: 19/10/2026. Công cụ: OpenAI Codex, .NET CLI, Git, Playwright/Chromium.

## Đầu vào thực tế

- `WebsiteBanSach-master.zip` là nền tích hợp; ZIP tải từ GitHub không chứa lịch sử Git.
- Đối chiếu thêm `WebsiteBanSach-Huy.zip`, `WebsiteBanSach-hung.zip`, `WebsiteBanSach-huyen.zip`, `WebsiteBanSach-kiet.zip`.
- `tonkho-lam.zip` cung cấp bản tham khảo và quy tắc TC10–TC13. Không ghi đè master bằng bản tham khảo.
- Các văn bản đính kèm là tài liệu đối chiếu, không phải quyền thay đổi phạm vi yêu cầu hoặc bằng chứng test mới.

## Prompt nguyên văn của yêu cầu chức năng

> Thêm sách
> Làm trọn chức năng thêm sách: biểu mẫu dùng chung cho thêm và sửa (_BieuMau), kiểm tra dữ liệu, chống trùng cả bộ, thêm nhiều tác giả, tải ảnh bìa; sách nhân viên thêm ở trạng thái chờ duyệt.
> Đầu vào (cần có trước khi làm): Bản tham khảo: WebsiteBanSach/NhaSachOnline/Controllers/SachController.cs hàm Them (95–128), KiemTraBieuMau (286–309), LayTacGia (312–323), NapDanhMuc, GanThongTin; Views/Sach/Them.cshtml, _BieuMau.cshtml; SachBieuMau trong Models/SachViewModels.cs. Cần có trước: S4-L2 (script CSDL, Model, kết nối – Lâm), S4-K1 (lớp dùng chung, nút đổi vai – Kiệt), S4-U1 (bố cục chung – Huyền).
> Đầu ra (phải nộp): Code trên nhánh lam, pull request; riêng _BieuMau.cshtml đưa lên trước để Hùng làm phần 4.
> Điều kiện đạt: Đạt TC10 (khách mở trang thêm sách bị chặn), TC11 (nhân viên thêm sách hợp lệ: chờ duyệt, nằm đầu trang 1), TC12 (thêm sách trùng cả bộ thì báo trùng), TC13 (bỏ trống, nhập sai: báo lỗi từng ô, giữ dữ liệu). Sách vừa thêm nằm đầu trang 1 và được tô sáng.
> Phụ thuộc: S4-L2 (script CSDL, Model, kết nối – Lâm), S4-K1 (lớp dùng chung, nút đổi vai – Kiệt), S4-U1 (bố cục chung – Huyền)
> Nhật ký AI: file docs/prompt/lam-s4-l4.md trong repo (công cụ AI, prompt nguyên văn, phần giữ lại, phần tự sửa và lý do). Thiếu file này thì thẻ không được Pass.
> bạn cần những tài liệu gì thì có thể giúp tôi công việc này

## Prompt bổ sung nguyên văn

> - KHÔNG CÓ: link GitHub, nhánh **`lam`** đã push, AGENTS.md, S4-K1 và S4-U1 deliverable riêng (chỉ có file có vẻ thuộc 2 task này).
> - CÓ: toàn bộ bản tham khảo, S4-L2 v3 deliverable, 5 tài liệu, 5 Python script.
> - bạn làm được không

> đây bạn làm đi

> [https://github.com/James-Lloyd20/WebsiteBanSach](https://github.com/James-Lloyd20/WebsiteBanSach)
> tôi chỉ có nấy bạn làm được không

## Các prompt tiếp theo nguyên văn

> bạn cần file nào tôi lấ cho bạn

> tải file zip về kiểu j

> nó đây đủ dữ liệu chua

> đủ chưa

> vậy bạn làm đi

Các file người dùng gửi trong các lượt này: WebsiteBanSach-master.zip và bốn ZIP của thành viên nêu trên.

## Phần giữ lại

- SQL, Entity Framework model/context và cấu hình kết nối của master (CSDL NhaSachOnline_S3).
- Toàn bộ thân các action Sửa, Chi tiết, DoiTrangThai, Duyet, Xoa, KhoiPhuc và xử lý trạng thái S4-Y4 giữ nguyên, đã đối chiếu với ZIP.
- Biểu mẫu hiện có của Hùng, lớp vai trò Session, helper ảnh/chuẩn hóa K1; không chép lớp cookie từ bản tham khảo cũ.
- Tìm kiếm và thứ tự tên của S4-U4 giữ lại; thêm ưu tiên sách vừa lưu và phân trang 50 dòng để đạt điều kiện S4-L4.

## Phần AI sửa và lý do

1. Tách commit _BieuMau đầu tiên: bổ sung lỗi HinhThuc/NguongSapHet; bước giá 1 đồng khớp quy tắc máy chủ; giải thích phải chọn lại file sau lỗi.
2. Thêm GET/POST Them và Them.cshtml: phân vai phía server, chống CSRF, trạng thái nhân viên chờ duyệt/quản lý đang bán, tạo tác giả/liên kết và tải ảnh qua helper hiện có. Không nhận mã/trạng thái/ảnh cũ do client giả mạo.
3. Hoàn thiện KiemTraBieuMau: mã danh mục hợp lệ, tên tác giả <=150 ký tự theo SQL, ISBN đúng chữ số, file rỗng/đuôi/dung lượng/Content-Type. Giữ quy tắc so trùng tập tác giả và helper chuẩn hóa K1 của master (bao gồm bỏ dấu theo K1).
4. Ghép danh sách tối thiểu: phân trang 50 dòng; khi có vuaLuu, về trang 1, đưa đúng sách đó đầu danh sách và tô sáng. Giữ tìm kiếm; không triển khai bộ lọc/sắp xếp đầy đủ S4-K3.
5. Sửa điểm nối K1/U1 bắt buộc: file controller đổi vai không có đuôi .cs nên không được biên dịch; đổi thành VaiTroController.cs. Nút layout cũ chỉ đổi localStorage, thay bằng form POST có CSRF ghi Session, nhãn đọc Session. Giữ JavaScript cũ vì nó tự bỏ qua khi không có ID nút cũ. Chưa thay hệ thống vai tạm bằng đăng nhập.
6. Thêm kiểm thử MVC HTTP và Chromium; test host dùng InMemory, có chế độ SQL Server để nhóm chạy lại trên CSDL thử riêng. Thêm AppMarker để test host tìm assembly ứng dụng.
7. Ghim System.Security.Cryptography.Pkcs 10.0.13 để loại cảnh báo bảo mật NuGet thực tế xuất hiện ở dependency gián tiếp. Thêm thư mục ảnh upload images/bia vào gitignore.

## Lỗi kiểm thử đã tự sửa

- Bản test đầu so chuỗi HTML sau khi decode nên sai kỳ vọng encode. Sửa test kiểm tra raw HTML; không làm yếu encode của Razor.
- Cập nhật test cho Session và tên model master; không dùng nguyên test của bản tham khảo cookie.
- Xác minh lại host trình duyệt ở port 5000 với bản Release.

## Phần Lâm tự sửa và lý do

Chưa có thay đổi thủ công của Lâm được cung cấp trong phiên. Không gán thay đổi do AI thực hiện thành phần Lâm tự sửa. Lâm bổ sung mục này sau khi tự xem/sửa, ghi rõ phần và lý do thực tế.

## Kết quả và phần còn lại

- Build Release thành công, 0 lỗi; còn 2 cảnh báo CS8602 có sẵn ở phần tìm kiếm của master.
- 38 kiểm tra HTTP qua toàn bộ MVC pipeline và 10 kiểm tra Chromium qua; có bằng chứng ảnh và log trong docs/S4-L4.
- Các lần này dùng EF InMemory. Docker pull SQL Server trả Forbidden: chưa chạy script, ràng buộc FK/index/decimal trên SQL Server thật, không đánh dấu SQL validation đã qua.
- GitHub read vẫn 403. Nhánh lam là lịch sử cục bộ dựng từ ZIP, không có ancestry của GitHub. Chưa push/chưa tạo PR.
- Commit mang danh Codex để không giả danh thành viên. Cung cấp patch để Lâm áp dụng vào clone thật và tự commit theo hướng dẫn nhóm; không force-push lịch sử ZIP lên master/lam.
