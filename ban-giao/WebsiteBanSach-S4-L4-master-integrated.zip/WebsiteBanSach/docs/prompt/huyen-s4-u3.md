# Nhật ký AI – Thẻ S4-U3: Đặc tả UC01 (Tìm kiếm và lọc sách)

Người làm: Đỗ Thị Huyền · Người kiểm tra: Hùng · Ngày: 17/10/2026

## 1. Công cụ AI

Claude (Anthropic), dùng trên claude.ai.

## 2. Prompt nguyên văn

**Prompt 1** (kèm hai file: `01_Phát biểu bài toán (bản 17-10).docx` và `S1-02_03_04_Use_Case_Dac_ta_Activity.docx`):

```
Mô tả
Chỉnh sửa
Người làm: Đỗ Thị Huyền
Người kiểm tra: Hùng
Hạn: Thứ Bảy 17/10, 22:00
Giờ dự kiến: 2 giờ
Mô tả: Viết bảng đặc tả theo mẫu: tác nhân, điều kiện trước, luồng chính, luồng thay thế, điều kiện sau, quy tắc.
Đầu vào (cần có trước khi làm): Bản tham khảo: mẫu bảng UC12 trong Tuan5/San_pham_Sprint_1_2/S1-02_03_04_Use_Case_Dac_ta_Activity.docx; hàm Index trong SachController.
Đầu ra (phải nộp): Bảng đặc tả UC01.
Điều kiện đạt: Có luồng không tìm thấy, khách chỉ thấy sách đang bán, nhân viên lọc được theo trạng thái.
Phụ thuộc: S4-H4 (làm rõ phát biểu bài toán – Hùng)
Nhật ký AI: file docs/prompt/huyen-s4-u3.md trong repo (công cụ AI, prompt nguyên văn, phần giữ lại, phần tự sửa và lý do). Thiếu file này thì thẻ không được Pass.

dựa theo Logic , yêu cầu và file sẵn có hưỡng dẫn tôi làm từng bước một
```

**Prompt 2** (dán code của một controller, kèm câu):

```
code đây ở trong SachController
```

(Đoạn code dán lên thực ra là `HomeController`, hàm `Index()` chỉ `return View();`, không có tìm kiếm hay lọc.)

**Prompt 3:**

```
tôi nghĩ hàm index trong file đó đấy bạn, vậy nếu theo logic có thể hoàn thành nhiệm vụ?
```

**Prompt 4:**

```
giúp tôi tạo file Word luôn
```

**Prompt 5:**

```
rồi tôi nộp như thế nào?
```

**Prompt 6:**

```
bạn làm luôn cho tôi phần nhạt ký AI được không?
```

**Prompt 7** (nhờ AI đóng vai người kiểm tra, đối chiếu UC01 với phát biểu bài toán 17/10; có dán lại phần mô tả thẻ như Prompt 1):

```
Mình đang làm thẻ S4-U3: đặc tả UC01 (tìm kiếm và lọc sách) cho nhóm, Hùng sẽ kiểm tra. Hãy đóng vai người kiểm tra và đối chiếu file UC01 với file phát biểu bài toán 17/10. Chỉ dựa vào hai file này, không suy đoán thêm. 1. Với từng dòng trong bảng UC01, cho biết có khớp QS07, QS11, QS12, QS13 không và trích đúng mã QS. 2. Chỉ ra chỗ nào bảng viết mà tài liệu không nói rõ, hoặc tài liệu có nói mà bảng còn thiếu. 3. Với mỗi chỗ chưa rõ, nói mình nên hỏi Hùng câu gì. Trình bày bằng bảng 3 cột: Dòng trong bảng | Khớp/Lệch | Căn cứ
```

## 3. AI đã trả lời gì

- Hướng dẫn 8 bước làm bảng đặc tả; chỉ ra mẫu UC12 là bản 14/10, cần theo bản phát biểu bài toán 17/10.
- Chỉ ra đoạn code tôi dán là `HomeController`, chưa đối chiếu được với QS12.
- Soạn bản nháp bảng UC01 (7 hàng) chỉ dựa vào phát biểu bài toán (QS07, QS11, QS12, QS13) và tạo file Word.
- (Prompt 7) Đối chiếu từng dòng UC01 với QS07, QS11, QS12, QS13: các dòng chính đều khớp; chỉ ra các chỗ tài liệu chưa nói rõ (nhân viên mặc định thấy trạng thái nào, "mã" là mã sách hay mã cuốn, người dùng có tự chọn kiểu sắp xếp không, A2 có thuộc UC02 không, khách gửi lọc trạng thái thì bị chặn hay bỏ qua) và gợi ý câu hỏi cho Hùng.
- Nêu 3 điểm chưa rõ cần hỏi Hùng (nhóm Kho có lọc theo trạng thái không; nhân viên có thấy số tồn không; khách sửa tham số trạng thái trên URL thì xử lý thế nào).

## 4. Phần giữ lại

Giữ nguyên toàn bộ bảng UC01 (7 hàng: Tác nhân, Mô tả, Điều kiện trước, Luồng chính, Luồng thay thế/ngoại lệ, Điều kiện sau, Quy tắc nghiệp vụ) như bản AI soạn.

## 5. Phần tự sửa và lý do

Không tự sửa phần nào của bản AI soạn.

