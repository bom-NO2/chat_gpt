# Nhật ký sử dụng AI – S4-H1 Chuẩn bị form mẫu cho từng loại báo cáo

> Mẫu 04 của nhóm (thẻ S4-H1). Thầy cho dùng AI nhưng thành viên phải cho thầy biết đã prompt thế nào và phải tự review lại. Thiếu file này thì thẻ không được Pass.

## 1. Thông tin chung

| Mục | Nội dung |
|---|---|
| Mã thẻ, tên thẻ | S4-H1 Chuẩn bị form mẫu cho từng loại báo cáo |
| Người làm | Vũ Đình Hùng |
| Công cụ AI (tên, phiên bản hoặc gói) | Claude Code (Claude Opus), ứng dụng Claude trên máy tính |
| Thời gian dùng (từ – đến) | 16/10/2026 23:51 – 17/10/2026 00:13 (giờ Việt Nam) |
| Nhánh, commit có dùng kết quả AI | Chưa commit (mẫu nằm trong thư mục báo cáo, không nằm trong repo code) |

## 2. Các lượt hỏi AI

### Lượt 1 – 16/10/2026, 23:51

- **Mục đích:** soạn 6 mẫu biểu cho nhóm theo đúng thể thức văn bản hành chính và theo mẫu biên bản thầy phát.
- **Prompt nguyên văn:**

```text
Okie, mọi người trong nhóm mình đều đã đồng ý ròi. Cảm ơn cậu nhiều lắm.
Cậu có thể dựa vào style viết báo cáo của mình cũng như style mẫu biên bản cuộc họp, đúng quy chuẩn văn bản hành chính của Việt Nam cũng như các công ty công nghệ đang hoạt động và làm việc tại Việt Nam, và từ đó giúp mình hoàn thành đầu việc "S4-H1 · Chuẩn bị form mẫu cho từng loại báo cáo (Hùng)" được không?
```

- **AI trả lời (tóm tắt):** dựng 6 mẫu trong `Sản phẩm yêu cầu/Mẫu biểu` (biên bản họp, biên bản review Sprint, thẻ việc, nhật ký AI, phiếu kiểm thử, báo cáo cá nhân), khổ A4, Times New Roman 13, quốc hiệu, tiêu ngữ, số và ký hiệu theo Nghị định 30/2020/NĐ-CP; mỗi mẫu có hướng dẫn điền và ví dụ.
### Lượt 2 – 17/10/2026, 00:05

- **Mục đích:** sửa mẫu báo cáo cá nhân cho đúng lời thầy buổi 5.1.
- **Prompt nguyên văn:**

```text
File báo cáo cá nhân ấy. Mình tưởng là trong buổi học ở tuần 5.1 thầy nói là gồm có báo cáo của từng thành viên một và báo cáo chung của nhóm. Trong đó, phần báo cáo của từng thành viên một là họ sẽ làm báo cáo cho chính phần mà họ phụ trách và được đảm nhiệm nhiệm vụ đầu việc mà nhỉ?
```

- **AI trả lời (tóm tắt):** xác nhận theo bản chép bảng và ghi âm buổi 5.1; đổi mẫu 06 thành “Mẫu báo cáo sản phẩm cá nhân” với 8 mục trùng 8 mục báo cáo chung, mỗi người chỉ viết mục có thẻ của mình; hỏi có sửa luôn 5 thẻ S4-03 trên Trello không.

### Lượt 3 – 17/10/2026, 00:13

- **Mục đích:** đồng ý sửa 5 thẻ S4-03 trên Trello theo mẫu 06 mới.
- **Prompt nguyên văn:**

```text
Okie, mình có
```

- **AI trả lời (tóm tắt):** sửa mô tả 5 thẻ S4-03 trên Trello (mục cần viết của từng người, đầu vào, đầu ra) và thẻ S4-03 trong file Thẻ việc.

- **Phần giữ lại:** giữ lại toàn bộ 6 mẫu, hướng dẫn điền và ví dụ do AI soạn sau khi Hùng đọc lại và duyệt.
- **Phần tự sửa và lý do:** không tự sửa nội dung AI soạn; mẫu 06 được AI sửa lại ở lượt 2 theo đúng yêu cầu của thầy mà Hùng nhắc.
- **Phần bỏ đi và lý do:** không bỏ phần nào.

## 3. Tự kiểm tra sau khi dùng AI

- [x] Đã đọc hiểu từng mẫu, giải thích được vì sao có từng mục.
- [x] Đã mở thử từng file Word, xem đúng khổ A4, đúng phông chữ.
- [x] Không dán mật khẩu, khóa bí mật, dữ liệu cá nhân thật vào prompt.
- [ ] Đã ghi việc dùng AI trong báo cáo cá nhân – làm ở thẻ S4-03.

## 4. Cam kết

Tôi xác nhận nhật ký này ghi đúng và đủ các lượt dùng AI cho thẻ trên.

Người làm: Vũ Đình Hùng  Ngày: 17/10/2026
