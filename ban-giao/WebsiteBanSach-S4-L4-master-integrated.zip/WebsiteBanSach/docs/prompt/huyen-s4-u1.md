# Nhật ký AI - S4-U1: Khung giao diện dùng chung

- Người làm: Đỗ Thị Huyền
- Người kiểm tra: Huy
- Nhánh: `huyen`
- Ngày làm: Thứ Bảy 17/10/2026

## 1. Công cụ AI đã dùng

Claude (Anthropic), trò chuyện trên web (claude.ai).

## 2. Cách làm việc với AI

Mình dùng AI như người hướng dẫn, còn mình là người gõ code, chạy thử và kiểm tra. Quy trình lặp lại ở mỗi bước:

1. Đưa cho AI đúng nội dung thẻ (mô tả, đầu vào, đầu ra, điều kiện đạt) để AI hiểu yêu cầu.
2. Làm từng bước nhỏ. Sau mỗi bước, mình chạy thử (F5) và gửi ảnh màn hình để đối chiếu kết quả với yêu cầu, rồi mới sang bước tiếp.
3. Khi AI gửi sẵn bốn file hoàn chỉnh, mình không dùng mà yêu cầu AI hướng dẫn từng bước để tự gõ và hiểu từng phần.
4. Mọi thứ AI đề xuất đều được mình chạy thử trên máy trước khi giữ lại. Phần chỉ dùng để thử (hai dòng `TempData` trong `HomeController`) đã được xóa trước khi commit.
5. Kiểm tra `Git Changes` trước khi commit để chắc chắn chỉ commit các file thuộc thẻ này.
6. File nhật ký này do AI soạn khung từ nội dung cuộc trò chuyện; mình đọc lại, đối chiếu với code và bổ sung phần tự sửa bằng những thay đổi mình đã làm thật (xem diff trong Git Changes).

## 3. Prompt nguyên văn

Các câu mình gửi cho AI, theo thứ tự (giữ nguyên cách viết). Mình có đính kèm ảnh chụp màn hình ở hầu hết các tin nhắn.

1. Dán nguyên nội dung thẻ S4-U1 (người làm, người kiểm tra, hạn, mô tả, đầu vào, đầu ra, điều kiện đạt, phụ thuộc, nhật ký AI), kèm câu: "vậy những điều tôi cần làm là gì?"
2. "hùng đã làm xong phần của bạn ấy và tôi sẽ cần làm gì?"
3. "vậy cách để kiểm tra xem tôi đã nhận lời repo chưa như thế nào?"
4. "phần code đây à?"
5. "vs studio của tôi như thế này rồi thì sao?"
6. "bạn giải thích chi tiết việc tôi cần làm là ấn vào đâu chứ tôi không hiểu"
7. "như này rồi sao nữa?"
8. "nó hiện như này tôi nên làm gì và làm gì tiếp theo?"
9. "này là sao và tôi nên làm gì tiếp theo ?"
10. "này là sao?" (hộp thoại chứng chỉ SSL)
11. "này là chạy thử thành công?"
12. "đóng kiểu gì?"
13. "mở file ở đâu ấn thế nào?"
14. "thấy file rồi thì làm gì tiếp theo?"
15. Dán lại nội dung thẻ, kèm câu: "ý là theo công việc này của tôi thì bước tiếp theo của tôi là gì?"
16. "ý là tôi không cần file của bạn tôi cần biết tôi cần làm gì"
17. "hướng dẫn tôi từng bước làm một"
18. "ý là xóa phần nào?"
19. "chạy như này đúng chưa?"
20. "này là được chưa?"
21. "này đúng chưa và tôi nên làm gì tiếp theo?"
22. "như này đúng chưa?"
23. "là sao và tôi nên làm gì?" (mở nhầm file site.css)
24. "ok tôi xong bước 5 rồi"
25. "này đúng chưa?" (hai thông báo TempData)
26. "tôi không ấn được F12 tại máy tôi là levono thinkbook"
27. "ảnh này có chụp được không hay tôi làm sai?"
28. "tôi xóa rồi và lưu lại như thế nào?"
29. "này là sao?" (cửa sổ Git Changes)
30. "mở file explorer như thế nào?"
31. "hay là bạn viết giúp tôi đi nhưng mà kiểu thầy sẽ kiểm tra nhật ký nên viết sao cho tôi giống kiểu người điều khiển AI làm việc và sử dụng AI một cách thông minh"
32. Bình luận trên bản nháp nhật ký: "tôi không biết lý do là gì , hãy giải thích cho tôi hiểu"
33. Bình luận trên bản nháp nhật ký: "tôi không biết lý do là gì hãy giúp tôi hiểu"
34. "phần này bạn có thể điền giúp tôi?"
35. "như này được chưa và bạn có thể viết lại vào nhật ký giúp mình?"

## 4. Phần giữ lại

Những phần mình đã gõ theo hướng dẫn của AI, chạy thử và giữ lại trong code:

- **`_Layout.cshtml` - đầu trang:** thanh `navbar` của Bootstrap nền xanh dương (`bg-primary`, chữ trắng) gồm tên "Nhà sách Online", nút ba gạch để thu gọn ở màn hình hẹp, ô tìm sách (form GET, tên trường `tuKhoa`) và nút "Vai: ...".
- **`_Layout.cshtml` - vùng thông báo:** hai khối `alert-success` (xanh lá) và `alert-danger` (đỏ) hiện khi `TempData["ThanhCong"]` hoặc `TempData["Loi"]` có giá trị, có nút X để tắt.
- **`_Layout.cshtml` - chân trang:** nền xanh dương, hai dòng chữ trắng, tự xuống dòng khi màn hình hẹp.
- **`_Layout.cshtml` - bố cục:** `body` dùng `d-flex flex-column min-vh-100` và phần nội dung dùng `flex-grow-1` để chân trang luôn nằm sát đáy.
- **`site.css`:** xóa quy tắc `body { margin-bottom: 60px; }` của chân trang mặc định, vì chân trang mới không cần.
- **`site.js`:** nút đổi vai tạm xoay vòng giữa "Khách", "Khách hàng", "Quản trị" và nhớ vai đã chọn bằng `localStorage`. Đây chỉ đổi nhãn trên trình duyệt, chưa phải đăng nhập hay phân quyền thật.

`_Layout.cshtml.css` giữ nguyên bản mặc định vì khung dùng các lớp có sẵn của Bootstrap.

## 5. Phần tự sửa và lý do

Sau khi khung đã chạy đúng, mình hỏi AI nên tự chỉnh thêm gì, rồi áp dụng và kiểm tra hai chỗ sau trong `_Layout.cshtml` (có trong diff của Git Changes):

- Đổi `<html lang="en">` thành `<html lang="vi">` - vì trang viết bằng tiếng Việt. Khai báo `en` làm trình duyệt hiểu sai ngôn ngữ (Chrome cứ gợi ý dịch trang) và phần mềm đọc màn hình đọc sai giọng.
- Đổi chữ trong thẻ `<title>` từ "NhaSachOnline" thành "Nhà sách Online" - vì tên trên thẻ tab cần giống tên hiển thị ở đầu trang, thay vì tên kỹ thuật của dự án.

Những việc kiểm tra mình đã thực hiện (không phải do AI làm hộ):

- Chạy thử trên máy, kiểm tra thông báo thành công hiện màu xanh lá, thông báo lỗi hiện màu đỏ.
- Kiểm tra nút đổi vai đổi đúng thứ tự và nhớ lại sau khi tải lại trang.
- Kiểm tra ở 1366 px và 360 px, không có thanh kéo ngang.
- Xóa hai dòng `TempData` thử trong `HomeController.cs` và dọn dòng trống, để thay đổi không lẫn vào commit.
- Chọn "Stash" khi Visual Studio hỏi về thay đổi `NhaSachOnline.csproj` chưa commit, để phần Entity Framework không lẫn vào nhánh giao diện.

## 6. Hạn chế và điều cần kiểm tra thêm

- Ô tìm sách gửi đến `Sach/Index` với tham số `tuKhoa`; trang này chưa có nên hiện chưa tìm được gì. Cần nối khi nhóm làm trang danh sách sách.
- Tên hai khóa `TempData` (`ThanhCong`, `Loi`) cần thống nhất với nhóm để các trang sau dùng giống nhau.
- Nút đổi vai chỉ là tạm thời, cần thay bằng phân quyền thật ở sprint sau.

## 7. Sản phẩm kèm theo

- Code trên nhánh `huyen`.
- Ảnh màn hình ở 1366 px và 360 px.