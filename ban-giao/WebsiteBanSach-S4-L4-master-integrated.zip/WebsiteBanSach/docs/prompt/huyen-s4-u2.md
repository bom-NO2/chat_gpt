# Nhật ký AI – Thẻ S4-U2: Bản vẽ danh sách sách
Người làm: Đỗ Thị Huyền · Người kiểm tra: Lâm

## 1. Công cụ AI đã dùng
- Tạo giao diện: Claude
- Đối chiếu bản vẽ với yêu cầu, sửa bản Word, hướng dẫn nộp bài: Claude (Anthropic)

## 2. Quá trình và prompt nguyên văn

### Bước 1. Hiểu việc cần làm
Tôi sao chép nguyên mô tả thẻ S4-U2 trên Trello (người kiểm tra, hạn, giờ dự kiến,
mô tả, đầu vào, đầu ra, điều kiện đạt, phụ thuộc, nhật ký AI) để biết mình cần làm gì.
### Bước 2. Nhờ AI tạo giao diện
Prompt nguyên văn: không còn lưu lại đầy đủ. Nội dung đại ý: tôi đưa mô tả thẻ S4-U2
cho AI và nhờ vẽ màn hình danh sách sách ở hai kích thước (1366 và 360), gồm ô tìm,
bộ lọc, nút sắp xếp, phân trang, bản khách (thẻ sách) và bản nhân viên (bảng), dựa
trên các file tham khảo của thẻ.
Đầu vào tôi đưa cho AI: S1-01_Thiet_ke_giao_dien.docx, gd_1_danh_sach_may_tinh.puml,
gd_2_danh_sach_dien_thoai.puml
Kết quả: 6 khung màn hình (khách 1366, khách 360, khách 360 ngăn lọc, khách không
tìm thấy, nhân viên 1366, nhân viên 360).

### Bước 3. Nhờ Claude đối chiếu bản vẽ
Tôi gửi 6 ảnh, file S1-01 và mô tả thẻ. Prompt nguyên văn:
"vậy theo yêu cầu của nhóm trưởng và file, thì tôi làm ảnh giao diện đã đúng chưa?"

### Bước 4. Nhờ Claude kiểm tra bản Word đặc tả
Tôi gửi file S4-U2_Dac_ta_ban_ve_danh_sach_sach.docx. Prompt nguyên văn:
"tôi có bản word ghi vậy tổng có được k?"

### Bước 5. Hỏi về hình thức nộp
Prompt nguyên văn: "nhưng mà kiểu nhất thiết là Figma? tại ghi Figma hoặc ảnh"
Prompt nguyên văn: "vậy để trên gg drvie như thế nào?"
Prompt nguyên văn: "vậy tôi nên nộp trên github hay ở đâu?"
Prompt nguyên văn: "vậy hưỡng dẫn tôi cách nộp 1 cách chi tiết"

### Bước 6. Nhờ Claude sửa bản Word
Prompt nguyên văn: "ở bản word của tôi sai chỗ nào thì bạn sửa giúp tôi luôn đi"
Claude trả về file S4-U2_Dac_ta_ban_ve_danh_sach_sach_da_sua.docx.

## 3. Phần giữ lại

- Nhận xét của Claude: thẻ cho phép nộp ảnh thay vì Figma; nộp bằng link thư mục
  Google Drive; nhật ký AI nộp trên GitHub.
- Các chỗ Claude sửa trong bản Word (số trang, bỏ Giỏ ở bản nhân viên 360,
  thêm ngăn lọc có ô Trạng thái, cách sắp xếp bản nhân viên 1366, cỡ chữ tiêu đề 360).

## 4. Phần tự sửa và lý do
| Đã sửa | Lý do |
|---|---|
| Số trang cuối: 7 → 2 (khách), 3 (nhân viên) trong ảnh và Word | 99 và 120 sách, 50 sách/trang thì chỉ có 2 và 3 trang |
| Bỏ "Giỏ (0)" ở bản nhân viên 360 | Nhân viên không mua hàng; thống nhất với bản 1366 |
| Thêm ô Trạng thái vào ngăn lọc nhân viên | Nhân viên cần lọc theo trạng thái |
| Thêm mũi tên sắp xếp cho cột Tên sách, Giá bán ở bản nhân viên 1366 | Mục 1.1 và 3.5 của Word đang mâu thuẫn |




## 5. Kết quả nộp
Link thư mục Google Drive (6 ảnh + bản Word đặc tả): # Nhật ký AI – Thẻ S4-U2: Bản vẽ danh sách sách
Người làm: Đỗ Thị Huyền · Người kiểm tra: Lâm

## 1. Công cụ AI đã dùng
- Tạo giao diện: Claude
- Đối chiếu bản vẽ với yêu cầu, sửa bản Word, hướng dẫn nộp bài: Claude (Anthropic)

## 2. Quá trình và prompt nguyên văn

### Bước 1. Hiểu việc cần làm
Tôi sao chép nguyên mô tả thẻ S4-U2 trên Trello (người kiểm tra, hạn, giờ dự kiến,
mô tả, đầu vào, đầu ra, điều kiện đạt, phụ thuộc, nhật ký AI) để biết mình cần làm gì.

### Bước 2. Nhờ AI tạo giao diện
Prompt nguyên văn: không còn lưu lại đầy đủ. Nội dung đại ý: tôi đưa mô tả thẻ S4-U2
cho AI và nhờ vẽ màn hình danh sách sách ở hai kích thước (1366 và 360), gồm ô tìm,
bộ lọc, nút sắp xếp, phân trang, bản khách (thẻ sách) và bản nhân viên (bảng), dựa
trên các file tham khảo của thẻ.
Đầu vào tôi đưa cho AI: S1-01_Thiet_ke_giao_dien.docx, gd_1_danh_sach_may_tinh.puml,
gd_2_danh_sach_dien_thoai.puml
Kết quả: 6 khung màn hình (khách 1366, khách 360, khách 360 ngăn lọc, khách không
tìm thấy, nhân viên 1366, nhân viên 360).

### Bước 3. Nhờ Claude đối chiếu bản vẽ
Tôi gửi 6 ảnh, file S1-01 và mô tả thẻ. Prompt nguyên văn:
"vậy theo yêu cầu của nhóm trưởng và file, thì tôi làm ảnh giao diện đã đúng chưa?"

### Bước 4. Nhờ Claude kiểm tra bản Word đặc tả
Tôi gửi file S4-U2_Dac_ta_ban_ve_danh_sach_sach.docx. Prompt nguyên văn:
"tôi có bản word ghi vậy tổng có được k?"

### Bước 5. Hỏi về hình thức nộp
Prompt nguyên văn: "nhưng mà kiểu nhất thiết là Figma? tại ghi Figma hoặc ảnh"
Prompt nguyên văn: "vậy để trên gg drvie như thế nào?"
Prompt nguyên văn: "vậy tôi nên nộp trên github hay ở đâu?"
Prompt nguyên văn: "vậy hưỡng dẫn tôi cách nộp 1 cách chi tiết"

### Bước 6. Nhờ Claude sửa bản Word
Prompt nguyên văn: "ở bản word của tôi sai chỗ nào thì bạn sửa giúp tôi luôn đi"
Claude trả về file S4-U2_Dac_ta_ban_ve_danh_sach_sach_da_sua.docx.

## 3. Phần giữ lại
- Nhận xét của Claude: thẻ cho phép nộp ảnh thay vì Figma; nộp bằng link thư mục
  Google Drive; nhật ký AI nộp trên GitHub.
- Các chỗ Claude sửa trong bản Word (số trang, bỏ Giỏ ở bản nhân viên 360,
  thêm ngăn lọc có ô Trạng thái, cách sắp xếp bản nhân viên 1366, cỡ chữ tiêu đề 360).

## 4. Phần tự sửa và lý do
| Đã sửa | Lý do |
|---|---|
| Số trang cuối: 7 → 2 (khách), 3 (nhân viên) trong ảnh và Word | 99 và 120 sách, 50 sách/trang thì chỉ có 2 và 3 trang |
| Bỏ "Giỏ (0)" ở bản nhân viên 360 | Nhân viên không mua hàng; thống nhất với bản 1366 |
| Thêm ô Trạng thái vào ngăn lọc nhân viên | Nhân viên cần lọc theo trạng thái |
| Thêm mũi tên sắp xếp cho cột Tên sách, Giá bán ở bản nhân viên 1366 | Mục 1.1 và 3.5 của Word đang mâu thuẫn |


## 5. Kết quả nộp
Link thư mục Google Drive (6 ảnh + bản Word đặc tả): https://drive.google.com/drive/folders/11ERPpevmvQm1Y8Hd4bbkKomD7SEwi-dX?usp=sharing
