# Nhật ký sử dụng AI – S4-H5 Vẽ Use Case mức khung và mức đỉnh

> Mẫu 04 của nhóm (thẻ S4-H1). Thầy cho dùng AI nhưng thành viên phải cho thầy biết đã prompt thế nào và phải tự review lại. Thiếu file này thì thẻ không được Pass.

## 1. Thông tin chung

| Mục | Nội dung |
|---|---|
| Mã thẻ, tên thẻ | S4-H5 · Vẽ Use Case mức khung và mức đỉnh |
| Người làm | Vũ Đình Hùng |
| Công cụ AI (tên, phiên bản hoặc gói) | Claude Code (mô hình Claude Opus) trong ứng dụng Claude trên máy tính; sơ đồ vẽ bằng draw.io 32.4.1 (bản đầu dùng PlantUML, đã bỏ) |
| Thời gian dùng (từ – đến) | 18/10/2026, từ khoảng 02:10 (giờ Việt Nam) |
| Nhánh, commit có dùng kết quả AI | Không có code. Sản phẩm: `Use Case mức khung và mức đỉnh (bản 18-10).docx` và thư mục `Sơ đồ Use Case (bản 18-10)` (7 file .drawio, 7 ảnh .png) trên Google Drive |

## 2. Các lượt hỏi AI

### Lượt 1 – 18/10/2026

- **Mục đích:** nhờ AI làm tiếp thẻ S4-H5.
- **Prompt nguyên văn:**

```text
Giúp mình làm tiếp thẻ S4-H5 Use Case nhé
```

- **AI trả lời (tóm tắt):** vẽ 7 sơ đồ bằng PlantUML (1 mức khung, 6 mức đỉnh), liệt kê mã UC thành danh sách, có bảng giải thích từng đường nối. Sơ đồ khung có nhiều đường cắt nhau, khó đọc.

### Lượt 2 – 18/10/2026

- **Mục đích:** báo sơ đồ khung rối, nhắc nhận xét của thầy ngày 15/10.
- **Prompt nguyên văn:**

```text
Trời ơi, ngay sơ đồ use case "uc_0_khung" mình đã thấy cậu làm khá rối rồi :((
Mình nhớ hôm 15/10 đó, thầy còn nhận xét là nhóm làm quá tệ phần sơ đồ ERD nữa mà, nhìn như mèo mửa luôn :(
Xong thầy phán 1 câu xanh rờn "đây không phải là sơ đồ Use Case và ERD
```

- **AI trả lời (tóm tắt):** đọc lại bản chép bảng và ghi âm buổi 3.1, thấy sơ đồ cũ sai cấu trúc so với cách thầy dạy: mức khung phải là vài nhóm chức năng tổng quát “Quản lý …”; mức đỉnh phải đi từ tác nhân tới nhóm rồi tới đúng những thao tác tác nhân được làm (giới hạn quyền). Sơ đồ cũ chỉ liệt kê mã UC thành danh sách phẳng.

### Lượt 3 – 18/10/2026 (gửi thêm khi AI đang làm)

- **Mục đích:** đề nghị dùng công cụ vẽ khác cho gọn, đẹp.
- **Prompt nguyên văn:**

```text
Cậu có thể sử dụng các công cụ khác để cho ra bản vẽ hoàn chỉnh và bố cục gọn gàng, đẹp thuận mắt hơn không?
```

- **AI trả lời (tóm tắt):** thử tự dàn bố cục bằng SVG; bản mẫu còn đường cắt nhau và tràn khung.

### Lượt 4 – 18/10/2026 (gửi thêm khi AI đang làm)

- **Mục đích:** bản mẫu SVG chưa chuyên nghiệp, đề nghị công cụ khác.
- **Prompt nguyên văn:**

```text
Cậu có thể sử dụng công cụ khác để vẽ được không?
Nhìn bản này cậu vẽ nó chưa được đẹp mắt và chuyên nghiệp ấy
```

- **AI trả lời (tóm tắt):** đề xuất draw.io (diagrams.net); Hùng chọn cài bản máy tính (draw.io 32.4.1 từ GitHub chính thức của JGraph, cài bằng winget). AI viết script sinh 7 file .drawio theo ký hiệu UML chuẩn và xuất PNG: mức khung gồm 6 tác nhân, 7 nhóm “Quản lý …”, khách và kế toán bên trái, chuỗi kế thừa Nhân viên – Quản lý – Chủ cửa hàng bên phải; mức đỉnh mỗi tác nhân một sơ đồ, tác nhân → nhóm → thao tác (nối «extend», mã UC ghi nhỏ dưới tên). Script tự kiểm tra: đủ 37 mã UC, mỗi thao tác đúng nhóm chứa mã của nó, nhóm ở sơ đồ khung khớp sơ đồ đỉnh. AI xem lại từng ảnh, sửa mũi tên kế thừa đè lên hình người, tác nhân cha bị đẩy lên trên tiêu đề, chú thích bị đường nối đè. File Word viết lại với bảng giải thích cho từng tác nhân và từng thao tác.

- **Phần giữ lại:** giữ lại toàn bộ 7 sơ đồ draw.io và các bảng giải thích trong file Word bản 18/10 sau khi Hùng đọc lại và duyệt.
- **Phần tự sửa và lý do:** không tự sửa nội dung AI làm.
- **Phần bỏ đi và lý do:** bỏ toàn bộ bản PlantUML ở lượt 1 và bản mẫu SVG ở lượt 3, vì sai cấu trúc thầy dạy và bố cục rối, không chuyên nghiệp.

## 3. Tự kiểm tra sau khi dùng AI

- [x] Đã đọc hiểu từng sơ đồ, giải thích được mỗi đường nối khi thầy hỏi.
- [x] Đã đối chiếu mã và tên UC với file 06.
- [x] Không dán mật khẩu, khóa bí mật, dữ liệu cá nhân thật vào prompt.
- [ ] Phần AI viết đã được ghi nguồn trong báo cáo cá nhân (mẫu 06) – làm ở thẻ S4-03.

## 4. Cam kết

Tôi xác nhận nhật ký này ghi đúng và đủ các lượt dùng AI cho thẻ trên.

Người làm: Vũ Đình Hùng  Ngày: 18/10/2026
