# Nhật ký sử dụng AI – S4-H3 Đưa thẻ lên Trello và theo dõi hằng ngày

> Mẫu 04 của nhóm (thẻ S4-H1). Thầy cho dùng AI nhưng thành viên phải cho thầy biết đã prompt thế nào và phải tự review lại. Thiếu file này thì thẻ không được Pass.

## 1. Thông tin chung

| Mục | Nội dung |
|---|---|
| Mã thẻ, tên thẻ | S4-H3 · Đưa thẻ lên Trello và theo dõi hằng ngày |
| Người làm | Vũ Đình Hùng |
| Công cụ AI (tên, phiên bản hoặc gói) | Claude Code (mô hình Claude Opus) trong ứng dụng Claude trên máy tính, dùng trình duyệt có sẵn trong ứng dụng để thao tác Trello trên tài khoản của Hùng (Hùng tự đăng nhập) |
| Thời gian dùng (từ – đến) | 15/10/2026 16:44 – 17/10/2026 19:58 (giờ Việt Nam) |
| Nhánh, commit có dùng kết quả AI | Không có code. Sản phẩm: board Trello `BuTB6dku` và file `Thẻ việc Sprint 4 (16-20.10).docx` trên Google Drive |

## 2. Các lượt hỏi AI

### Lượt 1 – 15/10/2026, 16:44

- **Mục đích:** nhờ AI phân việc cho từng thành viên trên Trello.
- **Prompt nguyên văn:**

```text
Bây giờ cậu là 1 người quản lý ngành CNTT khó tính, nguyên tắc 
Hãy giúp mình phân việc cho từng thành viên trên trello
```

### Lượt 2 – 16/10/2026, 02:39

- **Mục đích:** yêu cầu ghi rõ nghĩa sau mỗi mã thẻ trong file Thẻ việc.
- **Prompt nguyên văn:**

```text
Mình đã check lại thẻ việc sprint 4. Cậu có thể giúp mình viết rõ ra câu giải thích ở đằng sau một mã sprint được không? Mình nhìn vào còn khó hiểu đó, huống chi là thành viên trong nhóm nè. Không nên ghi mỗi "S4-01" cậu nha
```

### Lượt 3 – 16/10/2026, 02:41

- **Mục đích:** đặt mốc xong mọi thẻ.
- **Prompt nguyên văn:**

```text
À, cậu sắp xếp sao cho tất cả các đầu việc đều được hoàn thành trước sáng 10h Thứ 3 nha. Vì mình muốn sprint 3 phải được triển khai luôn từ trưa Thứ 3 tuần sau
```

### Lượt 4 – 16/10/2026, 02:58

- **Mục đích:** dàn lịch sang cuối tuần, gửi link board, nhờ AI đưa thẻ lên Trello và hướng dẫn dùng Trello.
- **Prompt nguyên văn:**

```text
Thay vì thứ 2 là ngày căng nhất, cậu có thể dàn đều nó sang T7 và chủ nhật được không? Và mình sẽ gửi cậu link trello nha, cậu làm xong thì cậu giải thích chi tiết tùng bước và những gì cậu đã làm trên trello, cũng như hướng dẫn mình sử dụng nó nha (vì mình chưa sử dụng trello bao giờ)
https://trello.com/b/BuTB6dku/cong-ngh%E1%BB%87-ph%E1%BA%A7n-m%E1%BB%81m
```

- **AI trả lời (tóm tắt lượt 1–4):** viết file Thẻ việc Sprint 4 (mỗi thẻ có tên, mô tả, đầu vào, đầu ra, điều kiện đạt, người kiểm tra, hạn, giờ dự kiến, nhật ký AI; mã thẻ kèm giải thích); dàn lịch sang thứ Bảy, Chủ nhật; trên Trello: lưu trữ 8 thẻ mẫu cũ, tạo 6 cột (Backlog, Cần làm, Đang làm, Chờ rà soát, Pass, Fail), tạo 30 thẻ có mô tả, thành viên, hạn, nhắc hạn; giải thích từng bước và cách dùng Trello.

### Lượt 5 – 16/10/2026, 10:55

- **Mục đích:** hỏi về nhãn màu, Backlog và cách dùng board cho các Sprint sau.
- **Prompt nguyên văn:**

```text
Về nhãn màu, thẻ sprint 3 trong backlog. Backlog là gì cậu nhỉ? Với lại cứ mỗi sprint mới là mình phải tạo 1 trello mới à cậu?
```

### Lượt 6 – 16/10/2026, 11:03

- **Mục đích:** gắn nhãn cho 30 thẻ và tạo thẻ nháp Sprint 3.
- **Prompt nguyên văn:**

```text
Mình muốn cậu Gắn nhãn “Sprint 4” cho 30 thẻ hiện có, nhưng theo mình thì vẫn nên ghi rõ cái nào là sprint 1 cũ, cái nào là sprint 2 cũ
Xong sau đó cậu giúp mình Tạo thẻ Sprint 3 trong Backlog  làm ngay bản nháp nhé
```

- **AI trả lời (tóm tắt lượt 5–6):** giải thích Backlog và việc dùng một board cho mọi Sprint; tạo 6 nhãn màu, gắn nhãn “Sprint 4” và nhãn “Làm lại Sprint 1 cũ” hoặc “Làm lại Sprint 2 cũ” cho 30 thẻ; tạo 18 thẻ nháp Sprint 3 và 1 thẻ “Để sau” trong cột Backlog.

### Lượt 7 – 16/10/2026, 16:04

- **Mục đích:** đổi hạn thẻ của Huyền theo đề nghị (kèm ảnh chụp thẻ).
- **Prompt nguyên văn:**

```text
Phần này của Huyền, huyền đang báo là khoảng thời gian này không làm được vì bận việc khác. Huyền đã đề nghị mình lùi nó xuống khoảng 23-24h tối hôm đó
```

- **AI trả lời (tóm tắt):** hỏi lại thẻ nào và giờ nào; Hùng chọn S4-U1, hạn 23:59 thứ Bảy 17/10; AI đổi hạn trên Trello, dòng “Hạn” trong mô tả và file Thẻ việc.

### Lượt 8 – 17/10/2026, 00:37

- **Mục đích:** hỏi vì sao có thẻ của Kiệt hạn 22:00, rơi vào giờ Kiệt bận.
- **Prompt nguyên văn:**

```text
À, sao mình thấy có task của Kiệt ở phần Doing đang thuộc khung giờ deadline là 22h nhỉ?
```

- **AI trả lời (tóm tắt):** đó là S4-K2, AI bỏ sót khi xếp lịch theo giờ rảnh của Kiệt; Hùng chọn 18:00 Chủ nhật; AI sửa trên Trello và file Thẻ việc.

### Lượt 9 – 17/10/2026, 00:54

- **Mục đích:** báo Kiệt làm được đến 12:00 trưa.
- **Prompt nguyên văn:**

```text
Kiệt đã cho mình biết, Kiệt có thể sắp xếp thời gian deadline đến 12h trưa thay vì 6h sáng
```

### Lượt 10 – 17/10/2026, 01:00 (gửi thêm khi AI đang làm)

- **Mục đích:** dàn lại lịch để mọi việc xong trước 12:00 thứ Hai.
- **Prompt nguyên văn:**

```text
Mà cậu có thể sắp xếp lịch như nào mà dàn trải hết đi, hoàn thành trước 12h trưa T2 đi. Xong chiều cả nhóm chỉ việc làm báo cáo và họp lại với nhau thôi. Được không/
```

### Lượt 11 – 17/10/2026, 01:04

- **Mục đích:** đồng ý lịch AI đề xuất, nhắc đổi cả giờ báo cáo trên Trello và file Word.
- **Prompt nguyên văn:**

```text
Mình đồng ý. Nhưng đừng quên thời gian phần của làm báo cáo trên cà Trello và các đầu việc trong file word nữa nha
```

- **AI trả lời (tóm tắt lượt 9–11):** đề xuất lịch mới (mọi việc xong 12:00 thứ Hai, chiều viết báo cáo 13:00–16:30, họp tổng kết 17:00–18:00); sau khi Hùng đồng ý, đổi hạn và dòng “Hạn” của các thẻ liên quan trên Trello (K2, K3, K4, H3, H6, H7, Y4, L4, U4, 5 thẻ S4-03, S4-02), đổi người kiểm tra S4-L4 sang Huy, sửa file Thẻ việc, biên bản họp số 1 và các file liên quan; kiểm tra lại cả 30 thẻ.

### Lượt 12 – 17/10/2026, 19:02

- **Mục đích:** dời các hạn 6:00 sáng của Kiệt.
- **Prompt nguyên văn:**

```text
Với lại những deadline của Kiệt mình thấy hầu như đều là lúc 6h sáng, liệu cậu có thể xem xét sắp xếp vào lúc 12h hoặc 18h được không
```

- **AI trả lời (tóm tắt):** đưa các phương án; Hùng chọn S4-K2 12:00 Chủ nhật, S4-K4 12:00 thứ Hai; AI đổi trên Trello và file Word.

### Lượt 13 – 17/10/2026, 19:18

- **Mục đích:** nhờ AI báo cho Kiệt trên Trello.
- **Prompt nguyên văn:**

```text
Cậu nhắn lại trên Trello để Kiệt biết giúp mình với nhé. 
Và sau khi xong, cậu giúp mình hoàn thành đầu việc "S4-H4 · Làm rõ phát biểu bài toán (Hùng)" nhé
```

- **AI trả lời (tóm tắt):** bình luận trên S4-K2 và S4-K4 báo hạn mới (phần S4-H4 ghi ở nhật ký `hung-s4-h4.md`).

### Lượt 14 – 17/10/2026, 19:58

- **Mục đích:** cho phép sửa 3 thẻ theo quyết định mới về xóa sách và nhờ nhắn Lâm cập nhật.
- **Prompt nguyên văn:**

```text
Về mục bạn tự đề xuất, mình đồng ý sách đã xóa khi khôi phục sẽ về “Đang ẩn”, rồi hiện lại khi muốn bán
và mình cũng đồng ý cho phép cậu sửa mô tả của 3 thẻ này trên Trello, và việc update sự thay đổi này, cậu cũng phải update trên file word gì đó nữa nhỉ?; tuy nhiên phần bình luận cậu không cần phải gắn tên từng người đâu, vì mình đã gán sẵn là ai làm những gì rồi mà. Tuy nhiên, do Lâm đã hoàn thành xong thẻ S4-L3, vậy nên cậu giúp mình comment lại cho lâm update lại giúp mình nhé.
```

- **AI trả lời (tóm tắt):** sửa mô tả S4-Y4, S4-L3, S4-K4 và bình luận trên cả ba thẻ; bình luận S4-L3 nhờ Lâm cập nhật bảng đặc tả UC12 đã nộp.

- **Phần giữ lại:** giữ lại toàn bộ thẻ, nhãn, hạn, mô tả và bình luận do AI làm trên Trello sau khi Hùng đọc lại và duyệt. Mỗi lần đổi hạn đều theo đề nghị của thành viên hoặc quyết định của nhóm, ghi ở các lượt trên.
- **Phần tự sửa và lý do:** không tự sửa nội dung AI làm. Việc chuyển thẻ giữa các cột và chấm Pass do Hùng tự làm trên Trello.
- **Phần bỏ đi và lý do:** không bỏ phần nào.

## 3. Tự kiểm tra sau khi dùng AI

- [x] Đã đọc lại các thẻ trên Trello, giải thích được khi thầy hỏi.
- [x] Đã đối chiếu hạn trên Trello với file Thẻ việc Sprint 4.
- [x] Không dán mật khẩu, khóa bí mật, dữ liệu cá nhân thật vào prompt; Hùng tự đăng nhập Trello.
- [ ] Phần AI viết đã được ghi nguồn trong báo cáo cá nhân (mẫu 06) – làm ở thẻ S4-03.

## 4. Cam kết

Tôi xác nhận nhật ký này ghi đúng các lượt dùng AI cho thẻ trên.

Người làm: Vũ Đình Hùng  Ngày: 17/10/2026
