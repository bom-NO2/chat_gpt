# Nhật ký sử dụng AI – S4-H2 Khung dự án và kho GitHub

> Mẫu 04 của nhóm (thẻ S4-H1). Thầy cho dùng AI nhưng thành viên phải cho thầy biết đã prompt thế nào và phải tự review lại. Thiếu file này thì thẻ không được Pass.

## 1. Thông tin chung

| Mục | Nội dung |
|---|---|
| Mã thẻ, tên thẻ | S4-H2 · Khung dự án và kho GitHub |
| Người làm | Vũ Đình Hùng |
| Công cụ AI (tên, phiên bản hoặc gói) | Claude Code (mô hình Claude Opus) trong ứng dụng Claude trên máy tính |
| Thời gian dùng (từ – đến) | 16/10/2026 01:44 – 02:24 (giờ Việt Nam) |
| Nhánh, commit có dùng kết quả AI | `master`: `fd3688d` Xóa mã nguồn cũ để nhóm làm lại Sprint 1-2; `7b49024` S4-H2: Khởi tạo khung dự án ASP.NET Core MVC (Hùng tự gõ lệnh git) |

## 2. Các lượt hỏi AI

### Lượt 1 – 16/10/2026, 01:44

- **Mục đích:** trả lời câu hỏi của AI về cách “làm lại từ đầu” và chốt cách xử lý kho GitHub.
- **Prompt nguyên văn:**

```text
Về câu hỏi và phỏng đoán của cậu ở đoạn chat trước đó:
Câu hỏi: “Làm lại từ đầu” của nhóm cụ thể là gì? Là bỏ code hiện có và viết mới từ trang trắng, hay giữ code làm nền rồi mỗi người nhận một phần, tự đọc hiểu, sửa và commit dưới tên mình?

Mình đoán: giữ code làm nền. Lý do: 100 giờ-người không đủ để viết lại cả thiết kế lẫn code, và kế hoạch làm Sprint 3 trong nửa ngày chỉ khả thi khi đã có code sẵn. Nếu đúng như vậy, khi báo cáo nhóm không được gọi đây là “làm lại từ đầu”, mà phải nói rõ: “code nền do AI sinh, nhóm tiếp nhận, hiểu và sửa”.

Mình sẽ trả lời:
Theo mình thì vẫn sẽ giữ lại code làm nền để tham khảo, xong sau đó mỗi người nhận 1 phần và có thể sử dụng thêm AI khác để support để tự đọc hiểu, sửa và commit code dưới tên của họ


Còn về câu hỏi ở đoạn chat này:
II. phản hồi các điểm cậu đang cần mình trả lời:

1. Okie mình đồng ý với ý này của cậu

3. Okie, mình cũng đồng ý với quan điểm này của cậu
4. Okie mình đồng ý với đề xuất và quan điểm này của cậu

6. Okie, mình đồng ý. Nhưng theo mình chúng ta vẫn nên lập kế hoạch để làm sao mà đầu ra cho ra phải thật thật giống với phát biểu bài toán, logic nghiệp vụ, database, frontend, backend,... của dự án BanSachOnline này. Vì nhóm mình chỉ là chưa phân chia đầu việc cho các thành viên, và họ chưa hiểu những phần mình phụ trách trong dự án này thôi mà. Vậy nên rất hi vọng cậu sẽ mô tả các đầu việc, đầu vào và đầu ra làm sao để thành viên đó cho ra kết quả sát với phần nhiệm vụ đã làm của project BanSachOnline này ;((
7. Okie, cảm ơn cậu đã hiểu


III. Phần câu hỏi cậu đang muốn hỏi mình:
Nhóm mình sẽ quyết định là xóa toàn bộ source code trên project github hiện tại, vẫn giữ lại project nha. Nhưng mà lần này là các thành viên sẽ tự push code do mình phụ trách lên
```

- **AI trả lời (tóm tắt):** đề xuất 3 bước: (1) giữ bản Sprint 2 trên máy làm bản tham khảo; (2) một commit xóa mã nguồn cũ trên GitHub (giữ lịch sử), rồi đưa khung ASP.NET Core MVC rỗng lên `master`; (3) mời thành viên, mỗi người một nhánh. Hỏi Hùng chọn bước nào.

### Lượt 2 – 16/10/2026, 01:57

- **Mục đích:** chọn làm cả 3 bước.
- **Prompt nguyên văn:**

```text
Mình chỉ được chọn 1 trong 3 thôi ư? Mình chọn cả 3 và cậu thực hiện theo lần lượt từ 1 đến 3 được không? Nếu không được thì cậu hỏi lại mình muốn chọn lại hay không nha
```

- **AI trả lời (tóm tắt):** viết hướng dẫn từng lệnh git để Hùng tự gõ trong thư mục clone mới `WebsiteBanSach_Repo` (không đụng bản Sprint 2, Sprint 3); soạn `README.md` cách chạy và `HUONG_DAN_GIT.md` (nhánh từng người, cách commit, Pull Request, thứ tự gộp, file nào thuộc thẻ nào).

### Lượt 3 – 16/10/2026, 02:18

- **Mục đích:** hỏi vì sao không chạy được code ở bước 2, mục 5.
- **Prompt nguyên văn:**

```text
Sao ở bước 2, mục 5 mình không chạy được code nhỉ cậu?
```

### Lượt 4 – 16/10/2026, 02:24

- **Mục đích:** gửi ảnh lỗi trong terminal để AI xem.
- **Prompt nguyên văn:**

```text
Terminal đang báo lỗi này nè cậu
```

(kèm một ảnh chụp màn hình terminal)

- **AI trả lời (tóm tắt lượt 3–4):** lượt 3: lỗi ở lệnh `git add .` (`Permission denied`) vì repo chưa có `.gitignore` nên Git cố đưa cả thư mục `.vs` đang bị Visual Studio khóa; đồng thời khung tạo bằng VS bị thêm một tầng thư mục và còn tên mặc định `WebApplication1`. AI nhận một phần lỗi do hướng dẫn trước chưa nhắc tạo `.gitignore`, hướng dẫn tạo `.gitignore` (`dotnet new gitignore`) và tạo lại khung đúng tên `NhaSachOnline`. Lượt 4: ảnh terminal không phải lỗi, `git status` hiện đúng 5 mục cần đưa lên (`.gitignore`, `HUONG_DAN_GIT.md`, `NhaSachOnline.slnx`, `NhaSachOnline/`, `README.md`), không còn `.vs`, `bin`, `obj`; Hùng chạy tiếp `git add`, `git commit`, `git push`.

- **Phần giữ lại:** giữ lại toàn bộ cách làm, `README.md` và `HUONG_DAN_GIT.md` do AI soạn sau khi Hùng đọc lại và duyệt. Các lệnh git do Hùng tự gõ và tự commit.
- **Phần tự sửa và lý do:** không tự sửa nội dung AI soạn.
- **Phần bỏ đi và lý do:** không bỏ phần nào.

## 3. Tự kiểm tra sau khi dùng AI

- [x] Đã đọc hiểu từng lệnh và từng câu giữ lại, giải thích được khi thầy hỏi.
- [x] Đã kiểm tra `git status` trước khi commit: không đưa `.vs`, `bin`, `obj` lên GitHub.
- [x] Không dán mật khẩu, khóa bí mật, dữ liệu cá nhân thật vào prompt.
- [ ] Phần AI viết đã được ghi nguồn trong báo cáo cá nhân (mẫu 06) – làm ở thẻ S4-03.

## 4. Cam kết

Tôi xác nhận nhật ký này ghi đúng và đủ các lượt dùng AI cho thẻ trên.

Người làm: Vũ Đình Hùng  Ngày: 17/10/2026
