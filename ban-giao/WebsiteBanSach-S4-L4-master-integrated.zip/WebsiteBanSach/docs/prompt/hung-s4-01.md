# Nhật ký sử dụng AI – S4-01 Họp lập kế hoạch Sprint 4 và làm lại Product Backlog

> Mẫu 04 của nhóm (thẻ S4-H1). Thầy cho dùng AI nhưng thành viên phải cho thầy biết đã prompt thế nào và phải tự review lại. Thiếu file này thì thẻ không được Pass.

## 1. Thông tin chung

| Mục | Nội dung |
|---|---|
| Mã thẻ, tên thẻ | S4-01 · Họp lập kế hoạch Sprint 4 và làm lại Product Backlog (cả nhóm) |
| Người làm | Vũ Đình Hùng (nhóm trưởng, phần dùng AI để chuẩn bị kế hoạch, Product Backlog và biên bản) |
| Công cụ AI (tên, phiên bản hoặc gói) | Claude Code (mô hình Claude Opus) trong ứng dụng Claude trên máy tính |
| Thời gian dùng (từ – đến) | 15/10/2026 17:32 – 17/10/2026 00:51 (giờ Việt Nam) |
| Nhánh, commit có dùng kết quả AI | Không có code. Sản phẩm là file Word trên Google Drive của nhóm: `Product Backlog và User Story (bản 16-10).docx`, `Biên bản họp số 1 - Lập kế hoạch Sprint 4 (16-10-2026).docx`, `Mục tiêu và phạm vi Sprint 4.docx` |

## 2. Các lượt hỏi AI

### Lượt 1 – 15/10/2026, 17:32

- **Mục đích:** hỏi nên chia dự án thành bao nhiêu Sprint.
- **Prompt nguyên văn:**

```text
Nhóm mình sẽ làm lại vậy, bây giờ mình cần biết với dự án hiện tại, nhóm mình nên phân ra bao nhiêu Sprint
```

### Lượt 2 – 15/10/2026, 17:39

- **Mục đích:** góp ý số Sprint và báo lịch làm việc của nhóm.
- **Prompt nguyên văn:**

```text
Hiện thầy của mình mới cho lớp đến sprint 2, liệu 7 sprint có dày đặc quá không?
Với lại nhóm mình chốt lại là mỗi tuần sẽ bắt đầu họp từ T2 và tiến độ làm việc đến T6
Và nhóm mình đặt mục tiêu hoàn thành tất cả sprint vào ngày 06/11
```

### Lượt 3 – 15/10/2026, 18:02

- **Mục đích:** sửa mốc thời gian các Sprint đã qua.
- **Prompt nguyên văn:**

```text
Mình sửa lại chút về mốc thời gian của sprint nhé
Sprint 1 là từ  ngày 30/09 đến ngày 02/10
Sprint 2 là từ ngày 05/10 đến ngày 09/10
Sprint 3 là từ ngày 12/10 đến ngày 16/10. Tuy nhiên thầy đã bảo gác lại và nếu hoàn thành rồi thì sẽ được cộng điểm. Giữa kì là show ra tiến độ của nhóm
Còn 2 ngày cuối tuần hàng tuần thì leader rà soát kết quả, đạt thì cho pass, không đạt thì cho faill và chuyển tiếp sang sprint sau
```

### Lượt 4 – 16/10/2026, 00:35

- **Mục đích:** chốt hướng làm lại Sprint 1, 2; nhờ AI đóng vai người thầy khó tính để phản biện; gửi ghi chép góp ý của thầy.
- **Prompt nguyên văn:**

```text
Mình đồng ý vớt UC06, đúng là nó phức tạp thật
Còn về ý cậu đang cần mình chốt:

1. Phần này cậu đưa mình 1 bảng phân chia sẵn công việc đầu người, mình sẽ đánh giá tiến độ để cậu nắm rõ
2. Mỗi ngày tính 8 giờ nha
3. Từ từ nhé, sprint 1, 2 nhóm mình đang tính là sẽ làm lại, phân chia lại công việc từ đầu, và triển khai nhanh chóng hoàn thành trước T3 tuần sau. Còn sprint 3 nếu xong 1, 2 trước T3 thì làm luôn, nếu không thì T3 buổi chiều tối và sáng hôm sau làm luôn để T4 tuần sau thầy check tiến độ của nhóm. Không cần sprint 4 đâu nha

Theo cậu thế nào? Hãy đóng vai là 1 người thầy có kinh nghiệm quản lý dự án công nghệ phần mềm khó tính trong lĩnh vực này. Và phản biện, hỏi mình thật sâu nhé. Cậu có thể lựa chọn và sử dụng những skill phù hợp cho câu hỏi cũng như dự án này.
Đồng thời mình cũng gửi cậu. 

Những ý mà mình đã note lại trong lúc nhóm trao đổi riêng với thầy để cải thiện tình hình:
Chia đầu việc là là nhiệm vụ của leader
Product backlog của các bạn đâu? Thì phải làm lại từ đầu, cái phát biểu bài toàn thì phải làm rõ ràng
List danh sách công việc, xong cả nhóm ngồi lại bàn “bây giờ chúng ta sẽ triển khai như nào trong từng tuần một, tuần đấy là sprint 1 thì đưa list công việc vào sprint 1” đưa xong thì cả nhòm ngồi phân chia công việc để làm, đầu việc ai nhận thì người đấy phải làm, mọi người đều phải nhận công việc (không nên theo năng lực, vì mình không biết ai như nào ai như nào được, mà nên hỗ trợ support nhau), ai cũng phải code ai cũng phải có nhiệm vụ và theo từng mức ưu tiên. Phải chia như vậy mọi người mới biết đầu việc được. Chứ bắt mọi người về nghĩ lại từ đầu thì sao ra được
Còn product backlog, cả nhóm tự làm để vạch danh sách đầu việc ra, dành 1 buổi gom hết đầu việc theo tuần lại, xong rồi bổ đầu việc theo từng người, bổ đầu việc theo deadline, xong rồi làm việc yêu cầu báo cáo, leader cần chuẩn bị form mẫu cho từng loại báo cáo một. Ví dụ báo cáo về nội dung A thì tôi cần cái form mẫu như này, nội dung B thì tôi cần form mẫu như này, nội dung C thì tôi cần form mẫu như này; sau khi đã bổ sung đầy đủ những cái form mẫu như này rồi thì yêu cầu kết quả. Vì là có form mẫu rồi thì bắt đầu điền nội dung vào form mẫu đấy, kết quả đạt được nội dung này của tôi cần phải làm được những bước nào. Xong sau đó cùng đánh giá với nhau, cả nhóm đánh giá với nhau như vậy thì mới ra được thành phẩm
Nhóm không nói miệng nữa, mà nhóm tiến hành làm luôn, ok bài toán đây, triển khai luôn, triển khai đầu việc, triển khai đầu việc xong rồi thì gom thành từng tuần, gom xong chia đầu việc luôn, và làm form mẫu luôn, làm 1 buổi đến 2 buổi rồi báo cáo kết quả. Trưởng nhóm phân công đầu việc lên Trello, đẩy các đầu việc lên Trello để lấy danh sách ở trên đấy để theo dõi theo tuần đó luôn, yêu cầu các thành viên trong nhóm phải lên đấy nhìn. Và lúc làm phải có 1 task doing, và bắt đầu làm đến 1-2 ngày thì bắt đầu gom task lại, doing 2 ngày rồi thì kết quả đâu? Làm như vậy 1 tuần 1 bản. Nếu ai ở vai trò leader thì 2 hôm làm rồi, trễ deadline rồi thì dục, ví dụ như A nhiệm vụ của mày làm đi ạ, B nhiệm vụ của mày mày làm đi ạ, làm đi và trả ra kết quả đi, trả về kết quả là phải review luôn, review muộn hay review hiệu quả, và vẫn phải có biên bản review và review như này là thành công hay không thành công, tại sao kết quả lại ra thành công và tại sao kết quả lại ra không thành công, để ta có 1 cái luồn, để ta đứng trên 1 cái vai trò review nó phải rõ ràng, đấy chính là phần test, test đấy có thành công hay không? Làm như vậy thì mới đưa ra sản phẩm cho các bạn được. Làm như vậy là các bạn đi rõ luôn, các bạn theo dõi được cả 1 cái luồng hoạt động từ đầu đến cuối luôn. Leader phải theo dõi, thành viên tự làm việc của họ, khó khăn thì họ phải đưa issues lên. Ví dụ như em làm về phần code, đang gặp khó khăn code không thành công -> đẩy issues lên là tôi đang gặp trục trặc trong quá trình code, thì bây giờ cái task đấy phải kéo dài ra một chút, giả sử như lúc trước tôi có 1 task là lúc 8 giờ, bây giờ hoàn thành là 10 giờ, và người leader điều phối. Chứ không phải là Cuối cùng các bạn mới thông báo là việc này các bạn làm chưa xong, ví dụ deadline là thứ tư, hết ngày thứ 3 thông báo là lý do không xong là gì để người ta còn điều phối người. Đóng vai trò là leader là như vậy đấy, điều phối như thế. Mà thành viên cũng như vậy thôi, active lên, bây giờ chúng ta lo làm, nếu không xong chúng ta thông báo, mà xong thì cũng thông báo. Mà làm việc thì chúng ta cũng phải làm việc cẩn thận, nội dung chúng ta cũng phải làm rõ nghĩa ra, bởi vì AI bây giờ hỗ trợ các bạn rất nhiều mà, làm xong nhất thiết thì phải hỏi lại, review lại 1 lượt nữa, trước khi gửi đi review lại 1 lượt nữa. Chứ không phải là làm cho có, thầy muốn các bạn làm là làm theo dạng như kiểu là doanh nghiệp. Sản phẩm đại diện cho giá trị của mình mang lại, sản phẩm mang lại giá trị thì nó sẽ khác hoàn toàn so với sản phẩm mà không có giá trị. Nếu muốn có giá trị thì phải làm như nào, nếu muốn có giá trị thì bây giờ ta phải chứng mình nó có hiệu quả. Tất nhiên trong quá trình các bạn chứng minh thì nó vẫn có lỗi phát sinh thì mới cần người test. Chúng ta phải làm hết mức của chúng ta đã, chứ không phải đợi đến lúc làm xong rồi, người ta test rồi, xong các bạn mới quay lại bắt đầu làm hoàn chỉnh thì như vậy không đúng. Nói rõ nó ra, đầu việc cũng ghi rõ nó ra, đầu việc này là gì? Mô tả rõ đầu việc, rất rõ đầu việc ra, tên đầu việc là gì, mô tả bên trong đầu việc là gì thì phải làm rõ nó ra
```

- **AI trả lời (tóm tắt lượt 1–4):** đề xuất số Sprint và lịch đến 06/11; phản biện kế hoạch (giờ công, rủi ro dồn việc, cách gọi "làm lại"); đề xuất gom việc làm lại Sprint 1, 2 thành Sprint 4 (16/10–20/10); bỏ UC06 khỏi mục tiêu 06/11.

### Lượt 5 – 16/10/2026, 21:38

- **Mục đích:** nhờ AI hoàn thành thẻ S4-01 (gửi lại file đầu việc, Product Backlog, làm biên bản họp theo mẫu thầy).
- **Prompt nguyên văn:**

```text
Ở đầu việc S4-01 hình như nhóm mình đã làm trước đó rồi đúng không cậu? Phần phát biểu bài toán đã được làm rõ ràng, chi tiết, dễ hiểu và chuẩn xác rồi chứ nhỉ? Liệt kê toàn bộ đầu việc thì cũng đã liệt kê trên Trello và file gì đó rồi thì phải, cậu gửi lại file mà nhóm đã liệt kê toàn bộ đầu việc cho mình nha. Còn product backlog cũng đã liệt kê trên trello và file gì đó rồi thì phải, mình không biết nó đã được viết chi tiết, rõ ràng và chuẩn xác hay chưa nữa; nhưng cậu cứ gửi lại file cho mình nhé. Còn chọn từng đầu việc trên sprint 4 và xác nhận đầu việc đó nhóm mình cũng đã họp và xác nhận những đầu việc được giao trên trello rồi. Còn form mẫu biên bản cuộc họp mình gửi cậu file word đính kèm đoạn chat này nha.
Cậu có thể giúp mình hoàn thành task này được không? Nhóm mình đã họp và bàn bạc với nhau, đồng ý triển khai theo đầu việc được giao trên trello rồi
```

### Lượt 6 – 16/10/2026, 23:02

- **Mục đích:** cung cấp thông tin thật của buổi họp để AI điền biên bản.
- **Prompt nguyên văn:**

```text
1. file mẫu biên bản cuộc họp chính là file mẫu mà thầy gửi nha, cậu sử dụng file đó nhé
2. Về thông tin buổi họp:

* Ngày, giờ bắt đầu: 16/10/2026 lúc 11h00, họp trực tiếp ở thư viện P702
* tất cả các thành viên đều có mặt, Huyền chịu trách nhiệm ghi biên bản
* Nhóm mình đã cùng ngồi lại, đọc lại toàn bộ phát biểu bài toán, liệt kê toàn bộ đầu việc, viết lại Product Backlog, chọn đầu việc cho Sprint 4, xác nhận từng người nhận thẻ nào trên Trello, bàn bạc, phân chia đầu việc qua file word "Thẻ việc Sprint 4", đồng thời update các task đầu việc lên Trello và các thành viên đều đồngý với các đầu việc mình được phân, mọi người cũng đồng ý rằng lịch sẽ được dàn đều để không bị ngợp quá; đồng thời Huyền đã đề nghị được điều chỉnh các task của mình về thời gian dealine xuống khung giờ tối, tránh khung giờ từ sáng đến 12h trưa, nhóm cũng đã nhất trí và thay đổi lại đầu việc phù hợp cho Huyền; Hùng chủ trì, Huyền ghi biên bản theo form mẫu
* Nhóm mình không có ai phản đối và không có ai góp ý. Nhóm sau đó đã chốt và kí biên bản cuộc họp

3. Mình hoàn toàn đồng ý với cách này, cậu claude à, cậu cũng chính là 'trợ lý thứ 2" đắc lực của mình đó, hãy làm thật tốt phần này giúp mình nhé
```

### Lượt 6b – 16/10/2026, 23:06 (gửi thêm khi AI đang làm)

- **Mục đích:** bổ sung thông tin Kiệt nêu trong buổi họp.
- **Prompt nguyên văn:**

```text
À, kiệt cũng có thông tin trong buổi họp là kiệt bận từ lúc 18:30 đến 00h sáng. Và kiệt xác nhận rằng kiệt có thể làm và hoàn thành vào thời gian từ 00h đến 06h sáng và từ 13h chiều đến 18h tối
```

- **AI trả lời (tóm tắt lượt 5–6b):** gửi lại file Thẻ việc Sprint 4 và Mục tiêu và phạm vi Sprint 4; dựng Product Backlog bản 16/10 (37 chức năng, mỗi chức năng một User Story “Là …, tôi muốn …, để …”, mức M/C, Sprint, người nhận, giờ ước lượng); điền biên bản họp số 1 theo đúng file mẫu của thầy từ thông tin trên, để trống giờ kết thúc cho thư ký điền.

### Lượt 7 – 17/10/2026, 00:48

- **Mục đích:** sửa biên bản cho khớp điều chỉnh lịch nhóm đã chốt (hạn của Kiệt).
- **Prompt nguyên văn:**

```text
Cậu sửa giúp mình nội dung thông tin trong cả biên bản cuộc họp nữa nhé. Nhóm mình có chốt trước đó rồi
```

### Lượt 8 – 17/10/2026, 00:51

- **Mục đích:** yêu cầu AI so sánh đoạn trước và sau khi sửa.
- **Prompt nguyên văn:**

```text
Okie, mình đóng rồi. Và cậu sau khi sửa xong thì so sánh cho mình đoạn mà cậu đã sửa nha
```

- **AI trả lời (tóm tắt lượt 7–8):** dựng lại biên bản, thêm mốc S4-K2 của Kiệt vào mục II.6, đưa bảng so sánh đoạn cũ và đoạn mới; nhắc nhóm in lại trang có thay đổi và ký lại.

- **Phần giữ lại:** giữ lại toàn bộ kế hoạch, Product Backlog bản 16/10 và biên bản do AI soạn sau khi Hùng đọc lại và duyệt. Các thay đổi sau đó (lịch Sprint 4, hạn của Huyền, Kiệt) do nhóm yêu cầu và được ghi thành các lượt hỏi riêng.
- **Phần tự sửa và lý do:** không tự sửa nội dung AI soạn.
- **Phần bỏ đi và lý do:** không bỏ phần nào.

## 3. Tự kiểm tra sau khi dùng AI

- [x] Đã đọc hiểu từng câu giữ lại, giải thích được khi thầy hỏi.
- [x] Biên bản ghi đúng thông tin buổi họp do Hùng cung cấp; giờ kết thúc để thư ký điền.
- [x] Không dán mật khẩu, khóa bí mật, dữ liệu cá nhân thật vào prompt.
- [ ] Phần AI viết đã được ghi nguồn trong báo cáo cá nhân (mẫu 06) – làm ở thẻ S4-03.

## 4. Cam kết

Tôi xác nhận nhật ký này ghi đúng các lượt dùng AI cho thẻ trên.

Người làm: Vũ Đình Hùng  Ngày: 17/10/2026
