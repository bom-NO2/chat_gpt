# Nhật ký sử dụng AI – S4-H4 Làm rõ phát biểu bài toán

> Mẫu 04 của nhóm (thẻ S4-H1). Thầy cho dùng AI nhưng thành viên phải cho thầy biết đã prompt thế nào và phải tự review lại. Thiếu file này thì thẻ không được Pass.

## 1. Thông tin chung

| Mục | Nội dung |
|---|---|
| Mã thẻ, tên thẻ | S4-H4 · Làm rõ phát biểu bài toán |
| Người làm | Vũ Đình Hùng |
| Công cụ AI (tên, phiên bản hoặc gói) | Claude Code (mô hình Claude Opus 5.5) trong ứng dụng Claude trên máy tính |
| Thời gian dùng (từ – đến) | Tối 17/10/2026 (Hùng ghi giờ chính xác) |
| Nhánh, commit có dùng kết quả AI | Không có code. Sản phẩm là file Word `Sản phẩm yêu cầu/Vũ Đình Hùng/01. Phát biểu bài toán (bản 17-10).docx` trên Google Drive của nhóm |

## 2. Các lượt hỏi AI

### Lượt 1 – 17/10/2026, buổi tối

- **Mục đích:** nhờ AI viết lại phát biểu bài toán theo mô tả và điều kiện đạt của thẻ S4-H4 trên Trello.
- **Prompt nguyên văn:**

```text
Cậu nhắn lại trên Trello để Kiệt biết giúp mình với nhé.
Và sau khi xong, cậu giúp mình hoàn thành đầu việc "S4-H4 · Làm rõ phát biểu bài toán (Hùng)" nhé
```

- **AI đã làm:** đọc mô tả thẻ S4-H4; đọc file 01 bản tuần 2, trang tóm tắt ngày 15/10, file 06 (bản 15/10), Product Backlog bản 16/10, code quản lý sách bản Sprint 2 (`SachController`, `Sach`, `SachViewModels`) và kết quả chạy thử TC01–TC17 ngày 14/10. Sau đó viết file Word gồm: bài toán và số liệu khảo sát; bảng năm vai; việc làm được, không được làm của từng vai (kèm mã UC, mức M/C); 13 quy tắc quản lý sách QS01–QS13 kèm căn cứ; quy tắc đơn hàng, tiền COD; phạm vi; thay đổi so với bản 15/10 và 4 điểm còn chờ nhóm chốt.
- **AI tự sửa trước khi giao:** bỏ một đoạn mô tả hiện trạng nhà sách (nhận đơn qua điện thoại, mạng xã hội) vì không có nguồn trong tài liệu của nhóm; thay bằng số liệu khảo sát có trong file 06.
- **Phần giữ lại:** giữ lại toàn bộ file 01 bản 17/10 do AI soạn sau khi Hùng đọc lại và duyệt. 4 điểm AI nêu là “chờ nhóm chốt” được Hùng chốt ở lượt 2.
- **Phần tự sửa và lý do:** không tự sửa nội dung AI soạn.
- **Phần bỏ đi và lý do:** không bỏ phần nào.

### Lượt 2 – 17/10/2026, buổi tối

- **Mục đích:** Hùng trả lời 4 điểm AI nêu là "chờ nhóm chốt" ở cuối file, nhờ AI ghi thành quyết định và sửa file 06 cho khớp.
- **Prompt nguyên văn:**

```text
Về mục cuối mà cậu cần mình chốt:

1. Quản lý hoàn toàn được phép, chủ cửa hàng thì có toàn quyền quyết định
2. Giúp mình ghi thành quyết định nhé. Nhưng nhớ thêm quyền của Sếp vào nhé, vì quyền hạn xắp xếp theo quyền lực của cấp bậc mà. Toàn quyền nhất vẫn là Sếp, tiếp đó là quản lý, xong đến nhân viên
3. Hoàn toàn được nhé. Nhưng mà theo những gì thầy nói, tính năng "xóa" rất nên hạn chế. Chủ yếu tính năng xóa lúc này chỉ là nói cho dễ hiểu, chứ bản chất của nó chỉ là ẩn sản phẩm mà cửa hàng đang muốn xóa đi thôi
4. Vậy giúp mình update lại nhé
```

- **AI hỏi lại một câu** về nút Xóa (ba cách: chuyển "Ngừng kinh doanh"; chỉ còn Ẩn/Hiện; ẩn nhưng vẫn xóa hẳn sách nhập nhầm). Hùng chọn: **Xóa = chuyển "Ngừng kinh doanh"**, không xóa khỏi CSDL, quản lý và chủ cửa hàng làm được, khôi phục được.
- **AI đã làm:** thêm đoạn cấp bậc quyền (Chủ cửa hàng > Quản lý > Nhân viên); thêm UC17, UC19, UC22, UC31 cho Quản lý; QS05 thêm "sách do quản lý, chủ cửa hàng thêm thì bán ngay"; viết lại QS08–QS10 theo cách xóa mới; đổi mục cuối thành danh sách quyết định 17/10. Sửa file 06 (bản sao lưu trước khi sửa: `Tuan2/Bo_luu_noi_bo_nhom_26-09-2026/Ban_luu_truoc_sua_17-10-2026/`): UC01, UC06, UC12, UC17, UC19, UC22, UC28, UC31 và đoạn giới thiệu bảng chức năng. Sửa file Thẻ việc (S4-H4, S4-Y4, S4-L3, TC17) và Product Backlog (UC12, UC28) cho khớp.
- **Phần AI tự đề xuất:** sách đã xóa khôi phục về "Đang ẩn". Hùng đồng ý ở lượt 3.
- **Phần giữ lại / tự sửa / bỏ đi:** giữ lại toàn bộ; không tự sửa; không bỏ phần nào.

### Lượt 3 – 17/10/2026, buổi tối

- **Mục đích:** chốt đề xuất khôi phục, nhờ AI sửa 3 thẻ Trello liên quan và các file Word.
- **Prompt nguyên văn:**

```text
Về mục bạn tự đề xuất, mình đồng ý sách đã xóa khi khôi phục sẽ về “Đang ẩn”, rồi hiện lại khi muốn bán
và mình cũng đồng ý cho phép cậu sửa mô tả của 3 thẻ này trên Trello, và việc update sự thay đổi này, cậu cũng phải update trên file word gì đó nữa nhỉ?; tuy nhiên phần bình luận cậu không cần phải gắn tên từng người đâu, vì mình đã gán sẵn là ai làm những gì rồi mà. Tuy nhiên, do Lâm đã hoàn thành xong thẻ S4-L3, vậy nên cậu giúp mình comment lại cho lâm update lại giúp mình nhé.
```

- **AI đã làm:** bỏ chữ "đề xuất" trong QS09; sửa file 06 (UC12), Thẻ việc (S4-Y4, S4-L3, S4-K4, TC17), Product Backlog (UC12), ví dụ trong mẫu 06. Trên Trello (tài khoản của Hùng): sửa mô tả S4-Y4, S4-L3, S4-K4 và bình luận trên cả ba thẻ, không gắn tên; bình luận S4-L3 nhờ Lâm cập nhật bảng đặc tả UC12 đã nộp.
- **Phần giữ lại / tự sửa / bỏ đi:** giữ lại toàn bộ; không tự sửa; không bỏ phần nào.

## 3. Tự kiểm tra sau khi dùng AI

- [x] Đã đọc hiểu từng câu giữ lại, giải thích được khi thầy hỏi.
- [x] Đã đối chiếu năm vai và QS01–QS13 với file 06 và Product Backlog 16/10; 4 điểm từng chờ chốt đã được chốt ngày 17/10 và sửa cả hai file cho khớp.
- [x] Không dán mật khẩu, khóa bí mật, dữ liệu cá nhân thật vào prompt.
- [ ] Phần AI viết đã được ghi nguồn trong báo cáo cá nhân (mẫu 06) – làm ở thẻ S4-03.

## 4. Cam kết

Tôi xác nhận nhật ký này ghi đúng và đủ các lượt dùng AI cho thẻ trên.

Người làm: Vũ Đình Hùng  Ngày: 17/10/2026
