# Nhật ký sử dụng AI – S4-H6 Vẽ biểu đồ lớp MVC phần quản lý sách

> Mẫu 04 của nhóm (thẻ S4-H1). Thầy cho dùng AI nhưng thành viên phải cho thầy biết đã prompt thế nào và phải tự review lại. Thiếu file này thì thẻ không được Pass.

## 1. Thông tin chung

| Mục | Nội dung |
|---|---|
| Mã thẻ, tên thẻ | S4-H6 · Vẽ biểu đồ lớp MVC phần quản lý sách |
| Người làm | Vũ Đình Hùng |
| Công cụ AI (tên, phiên bản hoặc gói) | Claude Code (mô hình Claude Opus) trong ứng dụng Claude trên máy tính; biểu đồ vẽ bằng draw.io 32.4.1 |
| Thời gian dùng (từ – đến) | 18/10/2026, khoảng 21:40 – 22:20 (bản nháp); 19/10/2026, khoảng 01:40 – 02:10 và 11:20 – 11:35 (bản 19-10) (giờ Việt Nam) |
| Nhánh, commit có dùng kết quả AI | Không có code. Sản phẩm: thư mục `Biểu đồ lớp (bản nháp 18-10)` và `Biểu đồ lớp (bản 19-10)` (file .drawio, ảnh .png, file Word có bảng “lớp nào ở file nào”), script `doi_chieu_bieu_do_lop.py`, trên Google Drive |

## 2. Các lượt hỏi AI

### Lượt 1 – 18/10/2026

- **Mục đích:** sau khi xong S4-H7, nhờ AI làm tiếp S4-H6.
- **Prompt nguyên văn:**

```text
Làm S4-H7 trước giúp mình nhé, xong rồi làm S4-H6 nha claude :D
```

- **AI trả lời (tóm tắt):** đọc lại phần thầy giảng tuần 4 về biểu đồ lớp (ảnh bảng Bang4.2_Class_MVC, ảnh vở Vo4.2, bản ghi âm): vẽ trước khi code, đúng mô hình MVC, thiết kế có bao nhiêu thuộc tính và phương thức thì code có bấy nhiêu; khối Common nằm ngoài Controller. Vẽ bằng draw.io theo bố cục của bảng: CSDL nối vào khối Model (lớp ứng với bảng và model riêng cho màn hình), khối Controller, khối View, khối Common. Thuộc tính và phương thức lấy từ code thật trên nhánh `huyen` và code S4-H7; phần chưa có code lấy theo thẻ việc, in xám kèm “(dự kiến)”. AI xem lại ảnh, sửa nhãn đè lên hình CSDL, mũi tên cắt ngang hộp Index, hai hộp View dính nhau. Viết file Word gồm biểu đồ, cách đọc, bảng “lớp nào ở file nào” và danh sách chỗ code chưa khớp thiết kế.

### Lượt 2 – 19/10/2026

- **Mục đích:** làm tiếp S4-H6 (sửa biểu đồ cho khớp code đã gộp).
- **Prompt nguyên văn:**

```text
Okie, Giờ chúng ta làm tiếp S4-H6 nhé
```

- **AI trả lời (tóm tắt):** kiểm tra GitHub, thấy từ 22:38 ngày 18/10 chưa có code mới nào được gộp (S4-K3, S4-L4, S4-Y4 chưa đẩy). Viết script `doi_chieu_bieu_do_lop.py` đọc toàn bộ code C# và so từng lớp với file .drawio theo hai chiều (code có mà biểu đồ thiếu; biểu đồ ghi chữ đen mà code không có; dòng “dự kiến” đã có code), có phần tự kiểm tra bằng code mẫu. Chạy trên master: thuộc tính và phương thức khớp hoàn toàn, chỉ còn 3 trang chưa có code.

### Lượt 3 – 19/10/2026

- **Mục đích:** chốt S4-H6 trước hạn 11:30.
- **Prompt nguyên văn:**

```text
Okie, giờ làm tiếp S4-H6 cậu nha
```

- **AI trả lời (tóm tắt):** lúc 11:24 vẫn chưa có code mới trên master (PR #7 của Kiệt chưa đạt, L4 và Y4 chưa có pull request). Chốt bản 19-10 khớp master commit b4f2829: đổi tiêu đề và chú thích, thêm bảng kết quả đối chiếu tự động (0 lệch) và mục chỗ code S4-K3 chưa khớp thiết kế (file thiếu đuôi .cs, tên SoLuongTon, TongTrang). Phần của S4-K3, S4-L4, S4-Y4 vẫn ghi “(dự kiến)”.

- **Phần giữ lại:** _toàn bộ biểu đồ draw.io, file Word và bảng “lớp nào ở file nào”_ (bản nháp); bản 19-10 và script đối chiếu: _(Hùng điền)_
- **Phần tự sửa và lý do:** _không có_
- **Phần bỏ đi và lý do:** _không có_

## 3. Tự kiểm tra sau khi dùng AI

- [ ] Đã đọc hiểu từng lớp, giải thích được mỗi đường nối khi thầy hỏi.
- [x] Sáng 19/10 đã đối chiếu lại với code trên master bằng script (0 lệch); phần của S4-K3, S4-L4, S4-Y4 chưa gộp nên vẫn ghi “(dự kiến)”.
- [x] Không dán mật khẩu, khóa bí mật, dữ liệu cá nhân thật vào prompt.
- [ ] Phần AI viết đã được ghi nguồn trong báo cáo cá nhân (mẫu 06) – làm ở thẻ S4-03.

## 4. Cam kết

Tôi xác nhận nhật ký này ghi đúng và đủ các lượt dùng AI cho thẻ trên.

Người làm: Vũ Đình Hùng  Ngày: 18/10/2026
