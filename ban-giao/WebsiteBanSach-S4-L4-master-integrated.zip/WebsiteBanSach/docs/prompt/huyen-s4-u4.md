# Nhật ký AI: S4-U4 (Lập trình phần 1: Danh sách sách và tìm kiếm)

- Người làm: Đỗ Thị Huyền
- Nhánh: `huyen`
- Ngày: 18/10/2026

## 1. Công cụ AI đã dùng

Claude (Anthropic), dùng qua giao diện chat, trong **hai phiên chat**:

- **Phiên 1 (khoảng 18:25 đến 18:30): dựng môi trường và code ban đầu.** Giải nén gói S4-L2 của Lâm, chạy script CSDL, cài gói EF, cấu hình kết nối, sửa `Program.cs`, tạo 3 file `SachViewModels.cs`, `SachController.cs`, `Views/Sach/Index.cshtml`.
- **Phiên 2 (buổi tối): kiểm thử, chụp ảnh, sửa lỗi, nộp bài.** Chụp ảnh các ca TC, phục hồi code, sửa lỗi Session, commit và nộp.

Cả hai phiên đều có gửi ảnh chụp màn hình (File Explorer, SSMS, Visual Studio, trình duyệt, Google Drive, GitHub). Nhiều tin nhắn chỉ gồm ảnh, không kèm chữ.

## 2. Prompt nguyên văn

### Phiên 1: dựng môi trường và code ban đầu

1. `trong file có những mục này` (kèm ảnh thư mục S4-L2.zip có 4 mục: database, docs, NhaSachOnline, README.md)
2. `như này?` (kèm ảnh thư mục S4-L2 đã giải nén trên Desktop)
3. Ảnh thư mục `database` có 2 file `01_tao_bang.sql` và `02_du_lieu_mau.sql` (chỉ gửi ảnh, không kèm chữ)
4. Ảnh Visual Studio sau khi cài gói `Microsoft.EntityFrameworkCore.SqlServer`, có cảnh báo NU1902/NU1903 (chỉ gửi ảnh, không kèm chữ)
5. Ảnh sau khi chạy lệnh `Copy-Item ... appsettings.json` (chỉ gửi ảnh, không kèm chữ)

[Huyền kiểm tra lại: nếu ở phiên 1 bạn còn gõ câu nào khác (ví dụ gửi kết quả SSMS, tên server `.\SQLEXPRESS01`, nội dung `VaiTroHienTai.cs`), hãy thêm vào đây đúng nguyên văn.]

### Phiên 2: kiểm thử, chụp ảnh, sửa lỗi, nộp bài

1. `tôi đang chụp những ảnh bạn giúp tôi là tôi dag cần làm những gì dc k?` (kèm nội dung thẻ việc S4-U4 và ảnh log SQL trong Developer PowerShell)
2. `là những cái này?` (kèm 4 ảnh: danh sách khách, tìm `zzzqq`, tìm tác giả Mario Puzo, ảnh trùng có thông báo Snipping Tool)
3. `TC04 là ảnh nào nói rõ ra`
4. `vậy tổng hợp các ảnh đạt tiêu chuẩn giúp tôi`
5. `vậy tôi xong phần ảnh rồi giờ làm gì?`
6. `vậy tôi cần làm gì?`
7. `hãy hướng dẫn chạy code để xong phẩn ảnh` (kèm ảnh Visual Studio)
8. `mở kiểu gì?` (kèm ảnh Output, chương trình đã thoát)
9. `hàm Index?` (kèm ảnh `SachController.cs`)
10. `tôi bị mất code rồi bạn giúp tôi lấy lại?` (kèm ảnh tab `SachController.cs` trống)
11. `tôi tìm lại code rồi`
12. `thế có dùng code đó được không?`
13. `tôi có file index rồi bạn suy ra code của file sachcontroller dc k?` (sau đó dán toàn bộ nội dung `Index.cshtml`)
14. `ảnh tô sáng? làm thế nào để có?`
15. `bây giờ như này, hãy cho tôi biết tôi cần nộp những gì`
16. `hướng dẫn từng cái một`
17. `nộp ảnh trên link gg drive dán trên trello là dc`
18. `có lẽ nên làm bước 3 nhật ký AI`
19. `thêm vào nhật lý những phần này` (kèm file ghi lại phiên 1)

Ngoài ra có gửi ảnh không kèm chữ: ảnh lỗi `Session has not been configured`, ảnh Diff của `Program.cs`, ảnh danh sách thay đổi Git, ảnh GitHub sau khi push, ảnh Google Drive.

## 3. Phần giữ lại

**Từ phiên 1 (môi trường và code ban đầu):**
- Giải nén `S4-L2.zip` trước khi dùng (không chạy trực tiếp từ bên trong file zip).
- Chạy lần lượt `01_tao_bang.sql` rồi `02_du_lieu_mau.sql` trong SSMS, kiểm tra bằng câu lệnh đếm trạng thái, kết quả đúng là: 0 → 8, 1 → 99, 2 → 8, 3 → 5.
- Cài gói `Microsoft.EntityFrameworkCore.SqlServer`; hai cảnh báo NU1902/NU1903 chỉ là cảnh báo bảo mật của gói đi kèm, không phải lỗi, nên bỏ qua.
- Chép `appsettings.json` của Lâm sang dự án và đổi tên server cho đúng máy: `Server=.\\SQLEXPRESS01;Database=NhaSachOnline_S3;Trusted_Connection=True;TrustServerCertificate=True;`.
- Sửa `Program.cs`: thêm `AddDbContext<NhaSachContext>`, `AddSession`, `UseSession`.
- Tạo 3 file `Models/SachViewModels.cs`, `Controllers/SachController.cs`, `Views/Sach/Index.cshtml` theo code AI đưa ở phiên 1.
- Chạy thử bằng `/Sach?vaitro=Khach`, khách phải ra 99 sách.
- Lưu ý đã nhận: không `git add` file `.csproj` nếu Lâm đã thêm gói đó trong PR của mình, để tránh xung đột khi gộp.

**Từ phiên 2 (kiểm thử và nộp bài):**
- Bảng đối chiếu ca kiểm thử với ảnh minh chứng (TC01, TC04, TC05, TC06, TC18, nhân viên thấy bảng, tô sáng sách vừa lưu).
- Cách chụp TC18: bật DevTools, chế độ Responsive 360 x 740, kiểm tra một cột và không có thanh cuộn ngang.
- Cách giải thích câu truy vấn: `INNER JOIN TheLoai`, `LEFT JOIN` tác giả, `WHERE TrangThai = HienThi` cho khách, `EXISTS ... LIKE ... ESCAPE` khi tìm theo tác giả (không nhân đôi dòng sách).
- Cách đọc `Index.cshtml` để biết controller phải truyền `SachDanhSach` gồm `TimKiem`, `DanhSach`, `LaNhanVien`, `MaSachVuaLuu`.
- Cách kiểm tra tô sáng bằng địa chỉ `?vaitro=NhanVien&vuaLuu=37`.
- Các bước commit, push lên nhánh `huyen` và nộp ảnh qua Google Drive dán vào Trello.
- [Huyền điền: bản `SachController.cs` cuối cùng lấy từ đâu: bản AI đưa ở phiên 1 rồi tự tìm lại / bản AI dựng lại từ `Index.cshtml` ở phiên 2 / kết hợp. Ghi đúng sự thật.]

## 4. Phần tự sửa và lý do

| Việc đã sửa | Lý do |
|---|---|
| Đổi `Server=localhost` thành `Server=.\\SQLEXPRESS01` trong `appsettings.json` | Máy của Huyền cài SQL Server Express với tên instance `SQLEXPRESS01`, `localhost` không kết nối được |
| Bỏ ảnh danh sách khách có thông báo Snipping Tool, giữ ảnh sạch | Ảnh trùng và dính thông báo không thuộc trang web |
| Chụp lại ảnh TC04 (từ khóa `Chí Phèo`) | Ảnh đầu bị cắt mất thanh địa chỉ và có biểu tượng "abc" mờ, không thấy `TimTheo=ten&TuKhoa=...` |
| Chụp lại TC18 ở chế độ Responsive 360 x 740 | Ảnh đầu mới mở DevTools dock bên phải, trang vẫn hiển thị chiều rộng máy tính |
| Đối chiếu code `SachController.cs` lấy lại với `Index.cshtml` | Bản lấy lại dùng `timTheo`, `tuKhoa`, `vuaLuu`, Session, khác bản đang xem trước đó (dùng Cookie, `SachTimKiem`), nên phải kiểm tra có khớp view |
| Sửa `Program.cs`: thêm `AddDistributedMemoryCache()`, `AddSession()` và `app.UseSession()` đặt sau `UseRouting()`, trước `UseAuthorization()` | Chạy báo lỗi `Session has not been configured for this application or request` |
| Đổi route mặc định sang `controller=Sach` | Để mở trang chủ vào thẳng danh sách sách |
| Nộp ảnh qua Google Drive thay vì commit vào repo | Nhóm quy định nộp ảnh bằng link Drive dán trên Trello |
| [Huyền điền thêm nếu có: lỗi build, tên tham số, chỗ khác phải sửa tay] | |

## 5. Ghi chú kiểm tra

- Khách chỉ thấy sách đang bán (99 sách); nhân viên thấy mọi trạng thái (120 sách), kể cả "Chờ quản lý duyệt".
- Tìm theo tên, mã/ISBN, tác giả, thể loại đều dùng `Contains` (EF dịch thành `LIKE`).
- Sách mã 18 "Bố Già" không có ISBN là do dữ liệu mẫu, không phải lỗi.