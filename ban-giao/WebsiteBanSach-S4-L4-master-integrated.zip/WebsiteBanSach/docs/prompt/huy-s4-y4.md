# Nhật ký sử dụng AI – S4-Y4

## 1. Thông tin chung

- Người thực hiện: Phạm Quang Huy.
- Thẻ: S4-Y4 – Chi tiết sách, ẩn/hiện, duyệt, xóa chuyển Ngừng kinh doanh, khôi phục về Đang ẩn.
- Công cụ: ChatGPT/Codex trong ChatGPT Work. Không tự điền tên phiên bản mô hình không có bằng chứng trong phiên làm việc.
- Ngày: 19/10/2026 (giờ Việt Nam).
- Nền: ZIP WebsiteBanSach-master, commit b4f2829e3087d2bafa38615629ba7be581a2be22.
- Nhánh dự kiến: huy. Người dùng xác nhận đã hoàn thành cả 4 mục lúc 12:57 ngày 19/10/2026. Mã commit và link PR chưa được cung cấp trong cuộc trò chuyện.

## 2. Các lượt hỏi AI

### Lượt triển khai ban đầu – tóm tắt bối cảnh

Người dùng yêu cầu thực hiện S4-Y4 trên bộ tham khảo và các gói S4-K1/L2/U1/MH02–MH03. AI đã làm một bản dựa trên dự án Sprint 2, có thay cơ chế vai trò và một số tệp dùng chung. Leader review chỉ rõ cần ghép theo master và thu hẹp phạm vi. Đoạn này là **tóm tắt bối cảnh**, không trình bày là prompt nguyên văn của lượt dài ban đầu.

### Lượt sửa theo review – prompt nguyên văn

```text
Đây là phần nhận xét của leader, bạn hãy dựa vào đó để sửa lại, (phần của kiệt chính là file zip S1-k1 tôi đã gửi cho bạn)
```

Kèm ảnh nhận xét của leader, nội dung yêu cầu được chép lại để theo dõi:

```text
(1) Cập nhật nhánh Huy theo master (git merge origin/master), làm trên đó.
(2) Chỉ thêm phần của Y4 vào SachController.cs hiện có: ChiTiet, DoiTrangThai, Duyet, Xoa, KhoiPhuc và các hàm hỗ trợ của chúng; giữ nguyên Index, Sua, các hàm KiemTraBieuMau, LayTacGia, NapDanhMuc... đang có.
(3) Không thay Program.cs, _Layout.cshtml, Views/Sach/Index.cshtml, VaiTroHienTai; dùng VaiTroHienTai của Kiệt (VaiTroHienTai.LaQuanLy(HttpContext.Session)...). QuyenSach.cs, ChiTiet.cshtml, s4-y4.css, s4-y4.js thì giữ.
(4) Bỏ Services/DieuKienDatSach.cs (giỏ hàng, đặt hàng chưa thuộc Sprint 4).
(5) Sửa chú thích bị lẫn chữ Trung trong Models/Sach.cs (hoặc không sửa file Sach.cs).
(6) Build không lỗi rồi chụp ảnh từng ca TC09, TC15, TC16, TC17; thêm docs/prompt/huy-s4-y4.md; push nhánh Huy và tạo pull request.
```

AI kiểm tra thấy gói S4-K1 cũ dùng cookie khác API Session trong review, nên yêu cầu bản master hiện tại. Người dùng gửi WebsiteBanSach-master.zip, không kèm thêm nội dung văn bản. AI dùng ZIP đó làm nền thay vì suy đoán API.

## 3. Phần giữ lại, phần sửa và lý do

### Giữ lại từ phần Y4

- QuyenSach: ma trận chuyển trạng thái hợp lệ, sửa tên vai theo constants của Kiệt.
- ChiTiet: giao diện theo vai, form POST + anti-forgery token, thông tin quản lý chỉ nội bộ.
- S4-y4.css/js: giữ thiết kế và tương tác, bổ sung CSS giới hạn trong .mh02 và khóa nút ngay trong JS Y4 vì site.js của master khác bản cũ.
- Compare-and-set theo TrangThai + NgayCapNhat để yêu cầu cũ/lặp không đảo trạng thái ngoài ý muốn.

### Sửa theo review

- Chỉ chèn khối Y4 vào controller master; constructor, Index, Sua và các helper cũ giữ nguyên.
- Dùng VaiTroHienTai.Doc/LaNhanVien/LaQuanLy(HttpContext.Session) và MaNhanVienTam có sẵn. Không sửa helper của Kiệt hoặc thêm scheme xác thực mới.
- Thông báo thành công dùng TempData["ThanhCong"] đúng layout master.
- Không đưa Program, layout, Index, cấu hình, Model, VaiTroController hoặc Services/DieuKienDatSach vào phần thay đổi.
- Chú thích Model Sach.cs ở master đã đúng tiếng Việt, không sửa file.
- Thêm ảnh bìa mặc định để view không tham chiếu tệp không tồn tại.

### Người dùng cần tự review

Không đánh dấu thay người dùng rằng đã đọc hiểu code, kiểm tra trên SQL Server hoặc ký cam kết. Người làm cần bổ sung xác nhận và commit/PR thật sau khi xem lại.

## 4. Kiểm tra đã thực hiện

- Build dự án sửa và build master gốc: đều 0 lỗi; các cảnh báo CS8602 ở Index và cảnh báo NuGet là phần có sẵn, không tự sửa code/phụ thuộc của người khác.
- 52 assertions qua TestServer + Session thật của ASP.NET Core + SQLite trong bộ nhớ đạt. Không sử dụng fake header vai như ở bản trước.
- 20 ảnh/kiểm tra chiều rộng qua Chromium, tương ứng các bước của TC09/15/16/17 tại 1366 và 360 px; không tràn ngang. Kiểm tra nút số lượng và hủy xác nhận vẫn thao tác được.
- So sánh byte các tệp được yêu cầu giữ nguyên; bỏ khối Y4 thu đúng controller master gốc.
- Ở thời điểm AI kiểm tra và đóng gói ban đầu, AI chưa kiểm tra SQL Server thật, chưa merge origin/master trực tuyến hoặc push/PR. Sau đó người dùng xác nhận đã hoàn thành các mục này; AI ghi nhận xác nhận đó, không tuyên bố đã tự thực hiện.

## 5. Phần tự sửa của sinh viên và xác nhận

- [x] Tôi đã đọc và hiểu các action Y4.
- [x] Tôi đã chạy TC09/TC15/TC16/TC17 trên SQL Server máy mình.
- [x] Tôi đã cập nhật nhánh huy từ origin/master và xử lý xung đột nếu có.
- [x] Tôi đã điền commit, link PR và ghi nhận phần tự sửa thực tế.

Cập nhật ngày 19/10/2026 lúc 12:57 (giờ Việt Nam): cả 4 ô được đánh dấu theo xác nhận trực tiếp của người dùng trong cuộc trò chuyện. Link PR và mã commit chưa được cung cấp cho AI nên không tự điền.
