namespace NhaSachOnline;

/// <summary>Điểm tham chiếu assembly ứng dụng cho kiểm thử HTTP tích hợp.</summary>
public sealed class AppMarker { }
