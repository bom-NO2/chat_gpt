using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace NhaSachOnline.Common
{
    /// <summary>
    /// Tiện ích kiểm tra định dạng: ISBN, chuẩn hóa chữ, lọc danh sách tác giả.
    /// </summary>
    public static class KiemTraDinhDang
    {
        /// <summary>
        /// Kiểm tra ISBN chỉ nhận đúng 10 hoặc 13 chữ số (bỏ qua dấu gạch/khoảng trắng).
        /// </summary>
        public static bool LaIsbnHopLe(string? isbn)
        {
            if (string.IsNullOrWhiteSpace(isbn))
                return false;

            // Chỉ giữ lại chữ số
            var chiSo = Regex.Replace(isbn, @"[^\d]", "");
            return chiSo.Length == 10 || chiSo.Length == 13;
        }

        /// <summary>
        /// Trả về ISBN đã làm sạch (chỉ còn chữ số), hoặc null nếu không hợp lệ.
        /// </summary>
        public static string? ChuanHoaIsbn(string? isbn)
        {
            if (!LaIsbnHopLe(isbn))
                return null;

            return Regex.Replace(isbn!, @"[^\d]", "");
        }

        /// <summary>
        /// Chuẩn hóa chuỗi để so trùng: bỏ dấu tiếng Việt, viết thường, gộp khoảng trắng.
        /// Ví dụ: "Nguyễn Văn A" → "nguyen van a"
        /// </summary>
        public static string ChuanHoaChuDeSoTrung(string? input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return string.Empty;

            // Chuẩn hóa Unicode (FormD) để tách dấu
            var normalized = input.Trim().Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder();

            foreach (var c in normalized)
            {
                var category = CharUnicodeInfo.GetUnicodeCategory(c);
                if (category != UnicodeCategory.NonSpacingMark)
                    sb.Append(c);
            }

            var khongDau = sb.ToString().Normalize(NormalizationForm.FormC).ToLowerInvariant();

            // Gộp nhiều khoảng trắng thành 1
            khongDau = Regex.Replace(khongDau, @"\s+", " ").Trim();

            return khongDau;
        }

        /// <summary>
        /// Lọc danh sách tác giả: tách theo dấu phẩy / chấm phẩy, chuẩn hóa, bỏ trống, loại trùng (không phân biệt hoa thường/dấu).
        /// </summary>
        public static List<string> LocDanhSachTacGia(string? danhSachTacGia)
        {
            if (string.IsNullOrWhiteSpace(danhSachTacGia))
                return new List<string>();

            var parts = danhSachTacGia
                .Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(p => p.Trim())
                .Where(p => !string.IsNullOrWhiteSpace(p))
                .ToList();

            // Loại trùng theo bản chuẩn hóa, giữ tên gốc đầu tiên
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var ketQua = new List<string>();

            foreach (var ten in parts)
            {
                var key = ChuanHoaChuDeSoTrung(ten);
                if (string.IsNullOrEmpty(key))
                    continue;

                if (seen.Add(key))
                    ketQua.Add(ten);
            }

            return ketQua;
        }
    }
}
