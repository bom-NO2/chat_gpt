using System.Globalization;
using Microsoft.EntityFrameworkCore;
using NhaSachOnline.Models;

// Hiển thị số, ngày theo kiểu Việt Nam (99.000đ)
CultureInfo.DefaultThreadCurrentCulture = CultureInfo.DefaultThreadCurrentUICulture = new CultureInfo("vi-VN");

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Đăng ký NhaSachContext – đọc chuỗi kết nối "NhaSach" từ appsettings.json
// (Server=localhost;Database=NhaSachOnline_S3;Trusted_Connection=True;TrustServerCertificate=True;)
// CSDL phải đã được tạo bằng database/01_tao_bang.sql và nạp dữ liệu bằng 02_du_lieu_mau.sql.
builder.Services.AddDbContext<NhaSachContext>(o => o.UseSqlServer(builder.Configuration.GetConnectionString("NhaSach")));

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseSession();

app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Sach}/{action=Index}/{id?}")
    .WithStaticAssets();

app.Run();
