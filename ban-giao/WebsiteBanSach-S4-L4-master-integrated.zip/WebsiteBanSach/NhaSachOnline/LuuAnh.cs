using Microsoft.AspNetCore.Http;

namespace NhaSachOnline.Common
{
    /// <summary>
    /// Kiểm tra và lưu ảnh bìa: chỉ jpg, png, webp; tối đa 2 MB.
    /// </summary>
    public static class LuuAnh
    {
        private static readonly HashSet<string> PhanMoRongChoPhep =
            new(StringComparer.OrdinalIgnoreCase) { ".jpg", ".jpeg", ".png", ".webp" };

        private const long KichThuocToiDa = 2 * 1024 * 1024; // 2 MB

        public static bool KiemTraAnhHopLe(IFormFile? file, out string thongBaoLoi)
        {
            thongBaoLoi = string.Empty;

            if (file == null || file.Length == 0)
            {
                thongBaoLoi = "Chưa chọn file ảnh.";
                return false;
            }

            if (file.Length > KichThuocToiDa)
            {
                thongBaoLoi = "Ảnh vượt quá 2 MB.";
                return false;
            }

            var ext = Path.GetExtension(file.FileName);
            if (string.IsNullOrEmpty(ext) || !PhanMoRongChoPhep.Contains(ext))
            {
                thongBaoLoi = "Chỉ chấp nhận ảnh jpg, png, webp.";
                return false;
            }

            // Kiểm tra Content-Type cơ bản
            var contentType = file.ContentType?.ToLowerInvariant() ?? "";
            if (!contentType.StartsWith("image/"))
            {
                thongBaoLoi = "File không phải là ảnh.";
                return false;
            }

            return true;
        }

        /// <summary>
        /// Lưu ảnh vào thư mục wwwroot/images/bia (hoặc path tùy chọn).
        /// Trả về đường dẫn tương đối (ví dụ: /images/bia/xxx.jpg) hoặc null nếu lỗi.
        /// </summary>
        public static async Task<(bool ThanhCong, string? DuongDanTuongDoi, string ThongBao)> LuuAnhBiaAsync(
            IFormFile file,
            string webRootPath,
            string thuMucCon = "images/bia")
        {
            if (!KiemTraAnhHopLe(file, out var loi))
                return (false, null, loi);

            var folder = Path.Combine(webRootPath, thuMucCon.Replace('/', Path.DirectorySeparatorChar));
            Directory.CreateDirectory(folder);

            var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (ext == ".jpeg") ext = ".jpg";

            var tenFile = $"{Guid.NewGuid():N}{ext}";
            var fullPath = Path.Combine(folder, tenFile);

            await using (var stream = new FileStream(fullPath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var relative = "/" + Path.Combine(thuMucCon, tenFile).Replace('\\', '/');
            return (true, relative, "Lưu ảnh thành công.");
        }
    }
}
