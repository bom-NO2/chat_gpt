using Microsoft.AspNetCore.Http;

namespace NhaSachOnline.Common
{
    /// <summary>
    /// Đọc / ghi vai trò hiện tại (khách, nhân viên, quản lý) qua Session.
    /// Sprint 2 chưa có đăng nhập nên dùng session tạm.
    /// </summary>
    public static class VaiTroHienTai
    {
        public const string KeySession = "VaiTroHienTai";

        public const string Khach = "Khach";
        public const string NhanVien = "NhanVien";
        public const string QuanLy = "QuanLy";

        private static readonly HashSet<string> CacVaiHopLe =
            new(StringComparer.OrdinalIgnoreCase) { Khach, NhanVien, QuanLy };

        public static string Doc(ISession session)
        {
            var vai = session.GetString(KeySession);
            if (string.IsNullOrWhiteSpace(vai) || !CacVaiHopLe.Contains(vai))
                return Khach; // mặc định

            // Chuẩn hóa tên
            if (vai.Equals(NhanVien, StringComparison.OrdinalIgnoreCase)) return NhanVien;
            if (vai.Equals(QuanLy, StringComparison.OrdinalIgnoreCase)) return QuanLy;
            return Khach;
        }

        public static bool Dat(ISession session, string vaiTro)
        {
            if (string.IsNullOrWhiteSpace(vaiTro) || !CacVaiHopLe.Contains(vaiTro))
                return false;

            string chuan;
            if (vaiTro.Equals(NhanVien, StringComparison.OrdinalIgnoreCase)) chuan = NhanVien;
            else if (vaiTro.Equals(QuanLy, StringComparison.OrdinalIgnoreCase)) chuan = QuanLy;
            else chuan = Khach;

            session.SetString(KeySession, chuan);
            return true;
        }

        public static bool LaQuanLy(ISession session) => Doc(session) == QuanLy;
        public static bool LaNhanVien(ISession session) => Doc(session) == NhanVien;
        public static bool LaKhach(ISession session) => Doc(session) == Khach;
    }
}
