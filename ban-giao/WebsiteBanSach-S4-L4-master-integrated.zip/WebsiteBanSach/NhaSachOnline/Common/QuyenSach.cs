using NhaSachOnline.Models;

namespace NhaSachOnline.Common;

/// <summary>Ma trận quyền/trạng thái dùng chung ở controller và giao diện.</summary>
public static class QuyenSach
{
    public static bool NoiBo(string vai) => vai is VaiTroHienTai.NhanVien or VaiTroHienTai.QuanLy;
    public static bool QuanLy(string vai) => vai is VaiTroHienTai.QuanLy;
    public static bool Xem(string vai, byte tt) => tt <= 3 && (NoiBo(vai) || tt == TrangThaiSach.HienThi);

    public static byte? Dich(string vai, byte tt, string thaoTac) => thaoTac switch
    {
        "an" when NoiBo(vai) && tt == TrangThaiSach.HienThi => TrangThaiSach.An,
        "hien" when NoiBo(vai) && tt == TrangThaiSach.An => TrangThaiSach.HienThi,
        "duyet" when QuanLy(vai) && tt == TrangThaiSach.ChoDuyet => TrangThaiSach.HienThi,
        "xoa" when QuanLy(vai) && tt is 0 or 1 or 2 => TrangThaiSach.NgungKinhDoanh,
        "khoiphuc" when QuanLy(vai) && tt == TrangThaiSach.NgungKinhDoanh => TrangThaiSach.An,
        _ => null
    };
}
