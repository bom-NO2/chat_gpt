﻿document.addEventListener("DOMContentLoaded", function () {
    var danhSachVai = ["Khách", "Khách hàng", "Quản trị"];
    var nut = document.getElementById("nutDoiVai");
    var nhan = document.getElementById("tenVai");

    if (!nut || !nhan) {
        return;
    }

    var vaiDaLuu = localStorage.getItem("vaiTam");
    if (vaiDaLuu && danhSachVai.indexOf(vaiDaLuu) !== -1) {
        nhan.textContent = vaiDaLuu;
    }

    nut.addEventListener("click", function () {
        var viTri = danhSachVai.indexOf(nhan.textContent);
        var vaiMoi = danhSachVai[(viTri + 1) % danhSachVai.length];
        nhan.textContent = vaiMoi;
        localStorage.setItem("vaiTam", vaiMoi);
    });
});