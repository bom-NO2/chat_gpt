// Capture chạy trước bộ khóa nút chung; hủy xác nhận không được khóa biểu mẫu.
document.addEventListener('submit', function (e) {
    const f = e.target;
    if (!f.matches('form[data-xac-nhan]')) return;
    if (f.dataset.dangGui === 'true') { e.preventDefault(); return; }
    const text = f.dataset.xacNhan;
    if (text && !window.confirm(text)) { e.preventDefault(); return; }
    f.dataset.dangGui = 'true';
    const button = f.querySelector('button[type=submit]');
    if (button) { button.dataset.nhanCu = button.textContent; button.disabled = true; button.textContent = 'Đang xử lý…'; }
    f.setAttribute('aria-busy', 'true');
}, true);
window.addEventListener('pageshow', function () {
    document.querySelectorAll('form[data-xac-nhan]').forEach(f => {
        delete f.dataset.dangGui; f.removeAttribute('aria-busy');
        const button = f.querySelector('button[type=submit]');
        if (button && button.dataset.nhanCu) { button.disabled = false; button.textContent = button.dataset.nhanCu; }
    });
});
const soLuong = document.getElementById('so-luong');
if (soLuong) {
    const doc = () => Math.max(1, Math.min(999, parseInt(soLuong.value, 10) || 1));
    document.querySelector('[data-giam]')?.addEventListener('click', () => soLuong.value = Math.max(1, doc() - 1));
    document.querySelector('[data-tang]')?.addEventListener('click', () => soLuong.value = Math.min(999, doc() + 1));
    soLuong.addEventListener('change', () => soLuong.value = doc());
}
document.querySelectorAll('[data-bia-sach]').forEach(img => {
    img.addEventListener('error', function () {
        if (this.dataset.daThay) return;
        this.dataset.daThay = 'true';
        // Giữ PathBase khi chạy dưới thư mục ảo; lấy từ CSS/script hiện có.
        const script = document.querySelector('script[src*="/js/s4-y4.js"]');
        const prefix = script ? new URL(script.src).pathname.split('/js/')[0] : '';
        this.src = prefix + '/images/bia-mac-dinh.png';
    });
});
