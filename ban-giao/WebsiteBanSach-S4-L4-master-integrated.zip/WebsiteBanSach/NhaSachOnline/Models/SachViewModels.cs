namespace NhaSachOnline.Models;

/// <summary>Điều kiện tìm: chỉ tìm theo MỘT thông tin (TimTheo) với một từ khóa.</summary>
public class SachTimKiem
{
    public string TimTheo { get; set; } = "ten";   // ten | ma | tacgia | theloai
    public string? TuKhoa { get; set; }
}

/// <summary>Dữ liệu truyền sang view danh sách.</summary>
public class SachDanhSach
{
    public const int SoDong = 50;
    public int Trang { get; set; } = 1;
    public int TongSo { get; set; }
    public int SoTrang => Math.Max(1, (int)Math.Ceiling(TongSo / (double)SoDong));
    public SachTimKiem TimKiem { get; set; } = new();
    public List<Sach> DanhSach { get; set; } = new();
    public bool LaNhanVien { get; set; }
    public int? MaSachVuaLuu { get; set; }   // sách vừa lưu, để tô sáng
}