using System.ComponentModel.DataAnnotations;

namespace NhaSachOnline.Models;

/// <summary>
/// Biểu mẫu thêm, sửa sách (model riêng của màn hình, không phải bảng).
/// Mã sách không có ô nhập: chỉ đọc (QS01). Giới hạn lấy theo QS03 và cột trong database/01_tao_bang.sql.
/// </summary>
public class SachBieuMau
{
    public int MaSach { get; set; }

    [Display(Name = "ISBN"), StringLength(17, ErrorMessage = "ISBN quá dài")]
    public string? ISBN { get; set; }

    [Required(ErrorMessage = "Nhập tên sách"), StringLength(200, ErrorMessage = "Tên sách tối đa 200 ký tự"), Display(Name = "Tên sách")]
    public string TenSach { get; set; } = "";

    // Mỗi dòng nhập một tác giả; nút + thêm dòng
    [Display(Name = "Tác giả")]
    public List<string> TacGia { get; set; } = new() { "" };

    [Required(ErrorMessage = "Chọn thể loại"), Display(Name = "Thể loại")]
    public int? MaTheLoai { get; set; }

    [Required(ErrorMessage = "Chọn nhà xuất bản"), Display(Name = "Nhà xuất bản")]
    public int? MaNXB { get; set; }

    [Required(ErrorMessage = "Nhập năm xuất bản"), Range(1900, 2100, ErrorMessage = "Năm xuất bản từ 1900 đến 2100"), Display(Name = "Năm xuất bản")]
    public short? NamXuatBan { get; set; }

    [Range(1, 2, ErrorMessage = "Chọn bìa mềm hoặc bìa cứng"), Display(Name = "Hình thức")]
    public byte HinhThuc { get; set; } = 1;

    [Range(1, 10000, ErrorMessage = "Số trang phải lớn hơn 0"), Display(Name = "Số trang")]
    public int? SoTrang { get; set; }

    [Range(1, 20000, ErrorMessage = "Khối lượng phải lớn hơn 0"), Display(Name = "Khối lượng (gram)")]
    public int KhoiLuongGram { get; set; } = 300;

    [Required(ErrorMessage = "Nhập giá bán"), Range(1000, 100000000, ErrorMessage = "Giá bán từ 1.000đ trở lên"), Display(Name = "Giá bán (đồng)")]
    public decimal? GiaBan { get; set; }

    [Range(0, 100000, ErrorMessage = "Số lượng không được âm"), Display(Name = "Số lượng có thể bán")]
    public int SoLuongCoTheBan { get; set; }

    [Range(0, 1000, ErrorMessage = "Ngưỡng báo sắp hết từ 0 đến 1000"), Display(Name = "Ngưỡng báo sắp hết")]
    public int NguongSapHet { get; set; } = 5;

    [Display(Name = "Mô tả")]
    public string? MoTa { get; set; }

    [Display(Name = "Ảnh bìa")]
    public IFormFile? AnhBiaMoi { get; set; }
    public string? AnhBiaHienTai { get; set; }
}
