namespace NhaSachOnline.Models;

// Các lớp ứng với bảng danh mục dùng khi quản lý sách.
// Mỗi thuộc tính khớp 1-1 với cột trong database/01_tao_bang.sql.

/// <summary>Bảng TheLoai: 0 ẩn, 1 hiển thị.</summary>
public class TheLoai
{
    public int MaTheLoai { get; set; }
    public string TenTheLoai { get; set; } = "";
    public byte TrangThai { get; set; } = 1;   // 0 ẩn, 1 hiển thị
}

/// <summary>Bảng NhaXuatBan.</summary>
public class NhaXuatBan
{
    public int MaNXB { get; set; }
    public string TenNXB { get; set; } = "";
}

/// <summary>Bảng TacGia.</summary>
public class TacGia
{
    public int MaTacGia { get; set; }
    public string TenTacGia { get; set; } = "";
}

/// <summary>Bảng trung gian Sach – TacGia (quan hệ nhiều–nhiều).</summary>
public class SachTacGia
{
    public int MaSach { get; set; }
    public int MaTacGia { get; set; }
    public TacGia? TacGia { get; set; }
}

/// <summary>
/// Bảng NhanVien. SoDienThoai để NULL trong SQL (VARCHAR(15) NULL)
/// vì nhân viên nội bộ có thể chưa cập nhật số điện thoại khi mới tạo tài khoản.
/// </summary>
public class NhanVien
{
    public int MaNhanVien { get; set; }
    public int MaTaiKhoan { get; set; }
    public string HoTen { get; set; } = "";
    public string? SoDienThoai { get; set; }   // VARCHAR(15) NULL
}

/// <summary>
/// Bảng DeXuatGia (UC28) – đề xuất đổi giá chờ quản lý duyệt.
/// Bổ sung 3 cột NguoiDuyet, NgayDuyet, LyDo để khớp 100% với script SQL
/// (bản trước thiếu 3 cột này nên khi load dữ liệu mẫu sẽ mất thông tin duyệt).
/// </summary>
public class DeXuatGia
{
    public int MaDeXuat { get; set; }
    public int MaSach { get; set; }
    public decimal GiaCu { get; set; }
    public decimal GiaMoi { get; set; }
    public int NguoiDeXuat { get; set; }
    public DateTime NgayDeXuat { get; set; }
    public byte TrangThai { get; set; }        // 0 chờ duyệt, 1 đã duyệt, 2 từ chối
    public int? NguoiDuyet { get; set; }        // INT NULL FK NhanVien – NULL khi chờ duyệt
    public DateTime? NgayDuyet { get; set; }   // DATETIME2 NULL – NULL khi chưa duyệt
    public string? LyDo { get; set; }           // NVARCHAR(255) NULL – lý do từ chối hoặc ghi chú
}
