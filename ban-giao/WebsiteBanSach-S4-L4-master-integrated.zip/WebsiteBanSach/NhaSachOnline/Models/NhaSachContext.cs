using Microsoft.EntityFrameworkCore;

namespace NhaSachOnline.Models;

/// <summary>
/// Kết nối tới cơ sở dữ liệu NhaSachOnline_S3 đã tạo bằng database/01_tao_bang.sql
/// và nạp dữ liệu mẫu bằng database/02_du_lieu_mau.sql.
/// Chuỗi kết nối "NhaSach" được đọc trong Program.cs từ appsettings.json.
/// </summary>
public class NhaSachContext(DbContextOptions<NhaSachContext> options) : DbContext(options)
{
    public DbSet<Sach> Sach => Set<Sach>();
    public DbSet<TheLoai> TheLoai => Set<TheLoai>();
    public DbSet<NhaXuatBan> NhaXuatBan => Set<NhaXuatBan>();
    public DbSet<TacGia> TacGia => Set<TacGia>();
    public DbSet<SachTacGia> SachTacGia => Set<SachTacGia>();
    public DbSet<NhanVien> NhanVien => Set<NhanVien>();
    public DbSet<DeXuatGia> DeXuatGia => Set<DeXuatGia>();

    protected override void OnModelCreating(ModelBuilder m)
    {
        // Sach – DECIMAL(12,0) phải khai báo HasPrecision để EF không ép về decimal(18,2) mặc định.
        m.Entity<Sach>(e =>
        {
            e.ToTable("Sach").HasKey(x => x.MaSach);
            e.Property(x => x.GiaBan).HasPrecision(12, 0);
            e.HasOne(x => x.TheLoai).WithMany().HasForeignKey(x => x.MaTheLoai);
            e.HasOne(x => x.NhaXuatBan).WithMany().HasForeignKey(x => x.MaNXB);
            e.HasMany(x => x.SachTacGias).WithOne().HasForeignKey(x => x.MaSach);
        });
        m.Entity<TheLoai>().ToTable("TheLoai").HasKey(x => x.MaTheLoai);
        m.Entity<NhaXuatBan>().ToTable("NhaXuatBan").HasKey(x => x.MaNXB);
        m.Entity<TacGia>().ToTable("TacGia").HasKey(x => x.MaTacGia);

        // SachTacGia – khóa chính kép (MaSach, MaTacGia).
        m.Entity<SachTacGia>(e =>
        {
            e.ToTable("SachTacGia").HasKey(x => new { x.MaSach, x.MaTacGia });
            e.HasOne(x => x.TacGia).WithMany().HasForeignKey(x => x.MaTacGia);
        });

        m.Entity<NhanVien>().ToTable("NhanVien").HasKey(x => x.MaNhanVien);

        // DeXuatGia – cả GiaCu và GiaMoi đều DECIMAL(12,0) trong SQL.
        m.Entity<DeXuatGia>(e =>
        {
            e.ToTable("DeXuatGia").HasKey(x => x.MaDeXuat);
            e.Property(x => x.GiaCu).HasPrecision(12, 0);
            e.Property(x => x.GiaMoi).HasPrecision(12, 0);
        });
    }
}
