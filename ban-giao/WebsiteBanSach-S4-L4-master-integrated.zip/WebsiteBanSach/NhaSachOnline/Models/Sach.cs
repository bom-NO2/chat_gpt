﻿namespace NhaSachOnline.Models;

/// <summary>Một ấn bản sách (bảng Sach). Từng cuốn vật lý nằm ở bảng CuonSach.</summary>
/// <remarks>
/// Ánh xạ 1-1 với các cột trong database/01_tao_bang.sql:
///   MaSach            INT IDENTITY PK
///   ISBN              VARCHAR(13) NULL                -> string?  (null = ISBN NULL)
///   TenSach           NVARCHAR(200) NOT NULL          -> string   (không null)
///   MaTheLoai         INT NOT NULL FK TheLoai         -> int      + navigation TheLoai?
///   MaNXB             INT NOT NULL FK NhaXuatBan       -> int      + navigation NhaXuatBan?
///   NamXuatBan        SMALLINT NOT NULL CHECK 1900..2100 -> short  (System.Int16)
///   HinhThuc          TINYINT NOT NULL CHECK 1..2      -> byte    (System.Byte)
///   SoTrang           INT NULL CHECK > 0              -> int?     (nullable)
///   KhoiLuongGram     INT NOT NULL DEFAULT 300 CHECK > 0 -> int   (mặc định 300)
///   MoTa              NVARCHAR(MAX) NULL              -> string?
///   AnhBia            NVARCHAR(300) NULL              -> string?
///   GiaBan            DECIMAL(12,0) NOT NULL CHECK > 0 -> decimal (HasPrecision(12,0) trong DbContext)
///   SoLuongCoTheBan   INT NOT NULL DEFAULT 0 CHECK >= 0 -> int
///   NguongSapHet      INT NOT NULL DEFAULT 5 CHECK >= 0 -> int   (mặc định 5)
///   TrangThai         TINYINT NOT NULL DEFAULT 2 CHECK 0..3 -> byte (mặc định ChoDuyet = 2)
///   NgayTao           DATETIME2 NOT NULL DEFAULT SYSDATETIME() -> DateTime
///   NgayCapNhat       DATETIME2 NOT NULL DEFAULT SYSDATETIME() -> DateTime
///   NguoiTao          INT NOT NULL FK NhanVien        -> int
///   NguoiCapNhat      INT NOT NULL FK NhanVien        -> int
/// </remarks>
public class Sach
{
    public int MaSach { get; set; }
    public string? ISBN { get; set; }
    public string TenSach { get; set; } = "";
    public int MaTheLoai { get; set; }
    public int MaNXB { get; set; }
    public short NamXuatBan { get; set; }
    public byte HinhThuc { get; set; }            // 1 bìa mềm, 2 bìa cứng
    public int? SoTrang { get; set; }
    public int KhoiLuongGram { get; set; } = 300;
    public string? MoTa { get; set; }
    public string? AnhBia { get; set; }
    public decimal GiaBan { get; set; }
    public int SoLuongCoTheBan { get; set; }
    public int NguongSapHet { get; set; } = 5;
    public byte TrangThai { get; set; } = TrangThaiSach.ChoDuyet;
    public DateTime NgayTao { get; set; }
    public DateTime NgayCapNhat { get; set; }
    public int NguoiTao { get; set; }
    public int NguoiCapNhat { get; set; }

    // Navigation properties – đặt tên khớp khóa ngoại để EF Core tự liên kết.
    public TheLoai? TheLoai { get; set; }
    public NhaXuatBan? NhaXuatBan { get; set; }
    public List<SachTacGia> SachTacGias { get; set; } = new();

    // Thuộc tính tính toán – không ánh xạ SQL, chỉ phục vụ UI.
    public bool SapHet => SoLuongCoTheBan > 0 && SoLuongCoTheBan <= NguongSapHet;
    public string TenTacGia => string.Join(", ", SachTacGias.Select(x => x.TacGia?.TenTacGia));
}

/// <summary>Giá trị cột Sach.TrangThai. 0 và 1 theo đúng cách thầy dạy (ẩn/hiện).</summary>
public static class TrangThaiSach
{
    public const byte An = 0;               // 0 ẩn – không hiển thị trên danh sách công khai
    public const byte HienThi = 1;         // 1 đang bán – hiển thị công khai, có thể đặt vào giỏ
    public const byte ChoDuyet = 2;         // 2 chờ quản lý duyệt – nhân viên mới thêm, chờ duyệt
    public const byte NgungKinhDoanh = 3;   // 3 ngừng kinh doanh – không bán nữa, giữ lịch sử

    /// <summary>Tên tiếng Việt theo đúng quy ước trong script SQL. Dùng cho UI/Excel.</summary>
    public static string Ten(byte tt) => tt switch
    {
        An => "Đang ẩn",
        HienThi => "Đang bán",
        ChoDuyet => "Chờ quản lý duyệt",
        NgungKinhDoanh => "Ngừng kinh doanh",
        _ => "Không rõ"
    };
}

