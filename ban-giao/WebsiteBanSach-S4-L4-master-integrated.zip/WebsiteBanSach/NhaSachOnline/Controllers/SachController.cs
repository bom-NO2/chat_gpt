using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NhaSachOnline.Common;
using NhaSachOnline.Models;

namespace NhaSachOnline.Controllers;

public class SachController(NhaSachContext db, IWebHostEnvironment env) : Controller
{
    public async Task<IActionResult> Index(string? timTheo, string? tuKhoa, int? vuaLuu, string? vaitro, int trang = 1)
    {
        // TẠM ĐỂ TEST: /Sach?vaitro=NhanVien hoặc ?vaitro=Khach. Xóa 2 dòng này khi nhóm có đăng nhập
        if (!string.IsNullOrEmpty(vaitro))
            VaiTroHienTai.Dat(HttpContext.Session, vaitro);

        // Nhân viên và quản lý thấy mọi trạng thái, còn lại là khách
        bool laNhanVien = VaiTroHienTai.LaNhanVien(HttpContext.Session)
                          || VaiTroHienTai.LaQuanLy(HttpContext.Session);

        // Sách vừa lưu: từ địa chỉ (?vuaLuu=) hoặc TempData
        int? maVuaLuu = vuaLuu ?? (TempData["MaSachVuaLuu"] as int?);

        timTheo ??= "ten";
        tuKhoa = tuKhoa?.Trim();

        IQueryable<Sach> query = db.Sach.AsNoTracking()
            .Include(s => s.TheLoai)
            .Include(s => s.SachTacGias).ThenInclude(st => st.TacGia);

        // TC01: khách chỉ thấy sách đang bán
        if (!laNhanVien)
            query = query.Where(s => s.TrangThai == TrangThaiSach.HienThi);

        // Tìm theo MỘT thông tin (Contains -> LIKE N'%từ khóa%' ESCAPE)
        if (!string.IsNullOrEmpty(tuKhoa))
        {
            switch (timTheo)
            {
                case "ma":
                    query = int.TryParse(tuKhoa, out var ma)
                        ? query.Where(s => s.MaSach == ma || (s.ISBN != null && s.ISBN.Contains(tuKhoa)))
                        : query.Where(s => s.ISBN != null && s.ISBN.Contains(tuKhoa));
                    break;
                case "tacgia":
                    // EXISTS: không nhân đôi dòng sách khi sách có nhiều tác giả
                    query = query.Where(s => s.SachTacGias.Any(st => st.TacGia.TenTacGia.Contains(tuKhoa)));
                    break;
                case "theloai":
                    query = query.Where(s => s.TheLoai.TenTheLoai.Contains(tuKhoa));
                    break;
                default: // "ten"
                    timTheo = "ten";
                    query = query.Where(s => s.TenSach.Contains(tuKhoa));
                    break;
            }
        }

        // S4-L4: trở về trang 1 sau khi lưu, ưu tiên dòng vừa lưu; giữ sắp xếp tên của S4-U4.
        var tongSo = await query.CountAsync();
        var soTrang = Math.Max(1, (int)Math.Ceiling(tongSo / (double)SachDanhSach.SoDong));
        trang = maVuaLuu.HasValue ? 1 : Math.Clamp(trang, 1, soTrang);
        var ds = await query.OrderByDescending(s => s.MaSach == maVuaLuu)
            .ThenBy(s => s.TenSach).ThenBy(s => s.MaSach)
            .Skip((trang - 1) * SachDanhSach.SoDong).Take(SachDanhSach.SoDong).ToListAsync();

        return View(new SachDanhSach
        {
            TimKiem = new SachTimKiem { TimTheo = timTheo, TuKhoa = tuKhoa },
            DanhSach = ds,
            LaNhanVien = laNhanVien,
            Trang = trang, TongSo = tongSo,
            MaSachVuaLuu = maVuaLuu
        });
    }

    // ---------------- Thêm sách (S4-L4) ----------------
    [HttpGet]
    public async Task<IActionResult> Them()
    {
        if (!LaNoiBo()) return KhongCoQuyen();
        await NapDanhMuc();
        return View(new SachBieuMau());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Them(SachBieuMau f)
    {
        if (!LaNoiBo()) return KhongCoQuyen();
        // Không tin mã/ảnh cũ/trạng thái gửi từ client khi tạo mới.
        f.MaSach = 0;
        f.AnhBiaHienTai = null;
        var tacGia = await KiemTraBieuMau(f, maSachDangSua: null);
        if (!ModelState.IsValid) { await NapDanhMuc(); return View(f); }

        string? anhBia = null;
        if (f.AnhBiaMoi is { Length: > 0 })
        {
            var (ok, duongDan, loiAnh) = await LuuAnh.LuuAnhBiaAsync(f.AnhBiaMoi, env.WebRootPath);
            if (!ok) { ModelState.AddModelError(nameof(f.AnhBiaMoi), loiAnh); await NapDanhMuc(); return View(f); }
            anhBia = duongDan;
        }
        var nv = MaNhanVienTam();
        var bayGio = DateTime.Now;
        var sach = new Sach
        {
            NgayTao = bayGio, NguoiTao = nv, AnhBia = anhBia,
            TrangThai = VaiTroHienTai.LaQuanLy(HttpContext.Session)
                ? TrangThaiSach.HienThi : TrangThaiSach.ChoDuyet,
        };
        GanThongTin(sach, f, bayGio, nv);
        sach.GiaBan = f.GiaBan!.Value;
        sach.SachTacGias = await LayTacGia(tacGia);
        db.Sach.Add(sach);
        await db.SaveChangesAsync();
        TempData["ThanhCong"] = sach.TrangThai == TrangThaiSach.ChoDuyet
            ? $"Đã thêm sách mã {sach.MaSach}. Sách đang chờ quản lý duyệt nên khách chưa thấy."
            : $"Đã thêm sách mã {sach.MaSach}.";
        return RedirectToAction(nameof(Index), new { vuaLuu = sach.MaSach, trang = 1 });
    }

    // ---------------- Sửa sách (S4-H7, UC12) ----------------
    public async Task<IActionResult> Sua(int id)
    {
        if (!LaNoiBo()) return KhongCoQuyen();
        var s = await db.Sach.AsNoTracking().Include(x => x.SachTacGias).ThenInclude(x => x.TacGia)
            .FirstOrDefaultAsync(x => x.MaSach == id);
        if (s is null) return NotFound();
        await NapDanhMuc();
        return View(new SachBieuMau
        {
            MaSach = s.MaSach, ISBN = s.ISBN, TenSach = s.TenSach, MaTheLoai = s.MaTheLoai, MaNXB = s.MaNXB,
            NamXuatBan = s.NamXuatBan, HinhThuc = s.HinhThuc, SoTrang = s.SoTrang, KhoiLuongGram = s.KhoiLuongGram,
            GiaBan = s.GiaBan, SoLuongCoTheBan = s.SoLuongCoTheBan, NguongSapHet = s.NguongSapHet, MoTa = s.MoTa,
            AnhBiaHienTai = s.AnhBia,
            TacGia = s.SachTacGias.Select(x => x.TacGia!.TenTacGia).DefaultIfEmpty("").ToList(),
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Sua(int id, SachBieuMau f)
    {
        if (!LaNoiBo()) return KhongCoQuyen();
        // Mã sách chỉ đọc (QS01): luôn lấy từ đường dẫn, bỏ qua mọi mã gửi lên từ biểu mẫu
        var s = await db.Sach.Include(x => x.SachTacGias).FirstOrDefaultAsync(x => x.MaSach == id);
        if (s is null) return NotFound();
        f.MaSach = id;
        f.AnhBiaHienTai = s.AnhBia;
        var tacGia = await KiemTraBieuMau(f, maSachDangSua: id);
        if (!ModelState.IsValid) { await NapDanhMuc(); return View(f); }

        var nv = MaNhanVienTam();
        var bayGio = DateTime.Now;
        GanThongTin(s, f, bayGio, nv);
        var thongBao = $"Đã cập nhật sách mã {id}.";
        if (f.GiaBan!.Value != s.GiaBan)
        {
            if (VaiTroHienTai.LaQuanLy(HttpContext.Session))
            {
                // QS06: quản lý đổi giá thì áp dụng ngay, vẫn ghi lại lần đổi (đề xuất đã duyệt)
                db.DeXuatGia.Add(new DeXuatGia
                {
                    MaSach = id, GiaCu = s.GiaBan, GiaMoi = f.GiaBan.Value, NguoiDeXuat = nv, NgayDeXuat = bayGio,
                    TrangThai = 1, NguoiDuyet = nv, NgayDuyet = bayGio,
                });
                s.GiaBan = f.GiaBan.Value;
            }
            else
            {
                // QS06: nhân viên đổi giá thành đề xuất chờ duyệt, giữ nguyên giá đang bán.
                // Sách đã có đề xuất chờ duyệt thì thay giá trong đề xuất đó, không tạo thêm.
                var dx = await db.DeXuatGia.FirstOrDefaultAsync(d => d.MaSach == id && d.TrangThai == 0);
                if (dx is null) db.DeXuatGia.Add(dx = new DeXuatGia { MaSach = id, GiaCu = s.GiaBan, TrangThai = 0 });
                dx.GiaMoi = f.GiaBan.Value;
                dx.NguoiDeXuat = nv;
                dx.NgayDeXuat = bayGio;
                thongBao += $" Giá mới {f.GiaBan.Value:N0}đ đang chờ quản lý duyệt; khách vẫn thấy giá cũ {s.GiaBan:N0}đ.";
            }
        }
        if (f.AnhBiaMoi is { Length: > 0 })
        {
            var (ok, duongDan, loiAnh) = await LuuAnh.LuuAnhBiaAsync(f.AnhBiaMoi, env.WebRootPath);
            if (!ok) { ModelState.AddModelError(nameof(f.AnhBiaMoi), loiAnh); await NapDanhMuc(); return View(f); }
            s.AnhBia = duongDan;
        }
        // Giữ tác giả cũ còn trong danh sách, bỏ tác giả bị xóa, thêm tác giả mới
        var moi = await LayTacGia(tacGia);
        var maGiuLai = moi.Where(x => x.TacGia!.MaTacGia != 0).Select(x => x.TacGia!.MaTacGia).ToHashSet();
        s.SachTacGias.RemoveAll(x => !maGiuLai.Contains(x.MaTacGia));
        var daCo = s.SachTacGias.Select(x => x.MaTacGia).ToHashSet();
        s.SachTacGias.AddRange(moi.Where(x => x.TacGia!.MaTacGia == 0 || !daCo.Contains(x.TacGia.MaTacGia)));
        await db.SaveChangesAsync();

        TempData["ThanhCong"] = thongBao;
        return RedirectToAction(nameof(Index), new { vuaLuu = id });
    }

    // ================= S4-Y4: Phạm Quang Huy =================
    [HttpGet]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public async Task<IActionResult> ChiTiet(int id, string? quayLai)
    {
        var s = await db.Sach.AsNoTracking()
            .Include(x => x.TheLoai).Include(x => x.NhaXuatBan)
            .Include(x => x.SachTacGias).ThenInclude(x => x.TacGia)
            .FirstOrDefaultAsync(x => x.MaSach == id);
        if (s is null || !QuyenSach.Xem(VaiTroHienTai.Doc(HttpContext.Session), s.TrangThai))
            return NotFound();
        ViewBag.QuayLai = Url.IsLocalUrl(quayLai) ? quayLai : Url.Action(nameof(Index));
        if (LaNoiBo())
        {
            ViewBag.DeXuatChoDuyet = await db.DeXuatGia.AsNoTracking()
                .Where(d => d.MaSach == id && d.TrangThai == 0)
                .OrderByDescending(d => d.NgayDeXuat).FirstOrDefaultAsync();
            ViewBag.NguoiCapNhat = await db.NhanVien.Where(n => n.MaNhanVien == s.NguoiCapNhat)
                .Select(n => n.HoTen).FirstOrDefaultAsync();
        }
        else
        {
            ViewBag.CungTheLoai = await db.Sach.AsNoTracking()
                .Include(x => x.SachTacGias).ThenInclude(x => x.TacGia)
                .Where(x => x.MaTheLoai == s.MaTheLoai && x.MaSach != id && x.TrangThai == TrangThaiSach.HienThi)
                .OrderByDescending(x => x.NgayCapNhat).ThenByDescending(x => x.MaSach).Take(8).ToListAsync();
        }
        return View(s);
    }

    // ---------------- S4-Y4: các thao tác trạng thái đều POST + CSRF ----------------
    [HttpPost, ValidateAntiForgeryToken]
    public Task<IActionResult> DoiTrangThai(int id, byte? trangThaiCu, long? phienBan, string? quayLai)
    {
        // Đích do trạng thái người dùng đã xem quyết định, không đảo trạng thái mới trong CSDL.
        var thaoTac = trangThaiCu == TrangThaiSach.HienThi ? "an" : "hien";
        return ChuyenTrangThai(id, trangThaiCu, phienBan, thaoTac, quayLai);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public Task<IActionResult> Duyet(int id, byte? trangThaiCu, long? phienBan, string? quayLai) =>
        ChuyenTrangThai(id, trangThaiCu, phienBan, "duyet", quayLai);

    [HttpPost, ValidateAntiForgeryToken]
    public Task<IActionResult> Xoa(int id, byte? trangThaiCu, long? phienBan, string? quayLai) =>
        ChuyenTrangThai(id, trangThaiCu, phienBan, "xoa", quayLai);

    [HttpPost, ValidateAntiForgeryToken]
    public Task<IActionResult> KhoiPhuc(int id, byte? trangThaiCu, long? phienBan, string? quayLai) =>
        ChuyenTrangThai(id, trangThaiCu, phienBan, "khoiphuc", quayLai);

    private async Task<IActionResult> ChuyenTrangThai(int id, byte? cu, long? phienBan, string thaoTac, string? quayLai)
    {
        var vai = VaiTroHienTai.Doc(HttpContext.Session);
        if (!QuyenSach.NoiBo(vai) || (thaoTac is "duyet" or "xoa" or "khoiphuc" && !VaiTroHienTai.LaQuanLy(HttpContext.Session)))
            return KhongCoQuyenY4();
        if (!ModelState.IsValid || id <= 0 || cu is null || phienBan is null
            || phienBan <= DateTime.MinValue.Ticks || phienBan >= DateTime.MaxValue.Ticks)
            return BadRequest("Yêu cầu không hợp lệ. Vui lòng tải lại trang.");
        var nv = MaNhanVienTam();
        if (!await db.NhanVien.AnyAsync(x => x.MaNhanVien == nv)) return KhongCoQuyenY4();
        if (nv == 0) return KhongCoQuyenY4();
        var s = await db.Sach.AsNoTracking().FirstOrDefaultAsync(x => x.MaSach == id);
        if (s is null) return NotFound();
        var dich = QuyenSach.Dich(vai, cu.Value, thaoTac);
        if (s.TrangThai != cu || s.NgayCapNhat.Ticks != phienBan || dich is null)
        {
            TempData["Loi"] = "Sách đã thay đổi hoặc thao tác không phù hợp với trạng thái hiện tại. Vui lòng kiểm tra lại.";
            return RedirectToAction(nameof(ChiTiet), new { id, quayLai = QuayLaiHopLe(quayLai) });
        }
        var moc = new DateTime(phienBan.Value, DateTimeKind.Unspecified);
        var bayGio = DateTime.Now;
        if (bayGio <= moc) bayGio = moc.AddTicks(1);
        try
        {
            // Compare-and-set trong một UPDATE: yêu cầu lặp không đảo ngược trạng thái;
            // chỉ cập nhật đúng ba cột, không động vào đơn hàng, kho hay lịch sử giá.
            var soDong = await db.Sach.Where(x => x.MaSach == id && x.TrangThai == cu.Value && x.NgayCapNhat == moc)
                .ExecuteUpdateAsync(u => u.SetProperty(x => x.TrangThai, dich.Value)
                    .SetProperty(x => x.NgayCapNhat, bayGio).SetProperty(x => x.NguoiCapNhat, nv));
            if (soDong == 0)
                TempData["Loi"] = "Sách vừa được người khác cập nhật. Trang đã tải trạng thái mới; vui lòng kiểm tra lại.";
            else
                TempData["ThanhCong"] = thaoTac switch
                {
                    "an" => "Đã ẩn sách.", "hien" => "Đã hiện sách.",
                    "duyet" => "Đã duyệt, sách đang bán.",
                    "xoa" => "Đã chuyển sách sang Ngừng kinh doanh. Dữ liệu và lịch sử được giữ nguyên.",
                    _ => "Đã khôi phục sách về Đang ẩn. Chọn Hiện sách khi muốn bán trở lại."
                };
        }
        catch (Exception ex) when (ex is System.Data.Common.DbException or DbUpdateException)
        {
            HttpContext.RequestServices.GetRequiredService<ILogger<SachController>>().LogError(ex, "Không thể chuyển trạng thái sách {MaSach}, thao tác {ThaoTac}", id, thaoTac);
            TempData["Loi"] = "Chưa thể lưu thay đổi. Vui lòng thử lại sau.";
        }
        return RedirectToAction(nameof(ChiTiet), new { id, quayLai = QuayLaiHopLe(quayLai) });
    }

    private string? QuayLaiHopLe(string? quayLai) => Url.IsLocalUrl(quayLai) ? quayLai : null;

    private IActionResult KhongCoQuyenY4() => StatusCode(403, "Vai trò hiện tại không có quyền thực hiện thao tác này.");

    // ================= Kết thúc S4-Y4 =================

    // ================= Hàm hỗ trợ dùng chung cho thêm và sửa =================
    private bool LaNoiBo() => VaiTroHienTai.LaNhanVien(HttpContext.Session) || VaiTroHienTai.LaQuanLy(HttpContext.Session);

    // shortcut: chưa có đăng nhập nên gán cố định nhân viên mẫu 1, quản lý mẫu 4 (02_du_lieu_mau.sql); thay bằng tài khoản đăng nhập ở Sprint đăng nhập
    private int MaNhanVienTam() => VaiTroHienTai.LaQuanLy(HttpContext.Session) ? 4 : 1;

    private IActionResult KhongCoQuyen()
    {
        TempData["Loi"] = "Vai trò hiện tại không có quyền làm thao tác này.";
        return RedirectToAction(nameof(Index));
    }

    private async Task NapDanhMuc()
    {
        ViewBag.TheLoai = new SelectList(await db.TheLoai.AsNoTracking().Where(t => t.TrangThai == 1).OrderBy(t => t.TenTheLoai).ToListAsync(), "MaTheLoai", "TenTheLoai");
        ViewBag.NXB = new SelectList(await db.NhaXuatBan.AsNoTracking().OrderBy(n => n.TenNXB).ToListAsync(), "MaNXB", "TenNXB");
    }

    private static void GanThongTin(Sach s, SachBieuMau f, DateTime bayGio, int nv)
    {
        s.ISBN = string.IsNullOrWhiteSpace(f.ISBN) ? null : KiemTraDinhDang.ChuanHoaIsbn(f.ISBN);
        s.TenSach = f.TenSach.Trim();
        s.MaTheLoai = f.MaTheLoai!.Value;
        s.MaNXB = f.MaNXB!.Value;
        s.NamXuatBan = f.NamXuatBan!.Value;
        s.HinhThuc = f.HinhThuc;
        s.SoTrang = f.SoTrang;
        s.KhoiLuongGram = f.KhoiLuongGram;
        s.SoLuongCoTheBan = f.SoLuongCoTheBan;
        s.NguongSapHet = f.NguongSapHet;
        s.MoTa = f.MoTa;
        s.NgayCapNhat = bayGio;
        s.NguoiCapNhat = nv;
    }

    /// <summary>Kiểm tra các quy tắc không diễn đạt được bằng thuộc tính (QS03, QS04); trả về danh sách tác giả đã làm sạch.</summary>
    private async Task<List<string>> KiemTraBieuMau(SachBieuMau f, int? maSachDangSua)
    {
        var tacGia = KiemTraDinhDang.LocDanhSachTacGia(string.Join(",", f.TacGia ?? []));
        if (tacGia.Count == 0) ModelState.AddModelError(nameof(f.TacGia), "Nhập ít nhất một tác giả");
        // ISBN được bỏ trống; có nhập thì phải đủ 10 hoặc 13 chữ số
        if (!string.IsNullOrWhiteSpace(f.ISBN) && !System.Text.RegularExpressions.Regex.IsMatch(f.ISBN.Trim(), @"^([0-9]{10}|[0-9]{13})$", System.Text.RegularExpressions.RegexOptions.CultureInvariant))
            ModelState.AddModelError(nameof(f.ISBN), "ISBN phải gồm 10 hoặc 13 chữ số");
        if (f.AnhBiaMoi is not null && !LuuAnh.KiemTraAnhHopLe(f.AnhBiaMoi, out var loiAnh))
            ModelState.AddModelError(nameof(f.AnhBiaMoi), loiAnh);
        if (tacGia.Any(t => t.Length > 150))
            ModelState.AddModelError(nameof(f.TacGia), "Tên mỗi tác giả tối đa 150 ký tự");
        if (!ModelState.IsValid) return tacGia;
        if (!await db.TheLoai.AnyAsync(t => t.MaTheLoai == f.MaTheLoai && t.TrangThai == 1))
            ModelState.AddModelError(nameof(f.MaTheLoai), "Chọn thể loại đang hoạt động");
        if (!await db.NhaXuatBan.AnyAsync(n => n.MaNXB == f.MaNXB))
            ModelState.AddModelError(nameof(f.MaNXB), "Chọn nhà xuất bản hợp lệ");
        if (!ModelState.IsValid) return tacGia;

        var isbn = string.IsNullOrWhiteSpace(f.ISBN) ? null : KiemTraDinhDang.ChuanHoaIsbn(f.ISBN);
        if (isbn is not null && await db.Sach.AnyAsync(s => s.ISBN == isbn && s.MaSach != maSachDangSua))
            ModelState.AddModelError(nameof(f.ISBN), "ISBN này đã có ở một sách khác");

        // QS04: tên được trùng, nhưng không trùng cả bộ tên, tác giả, NXB, năm, hình thức
        var ungVien = await db.Sach.AsNoTracking().Include(s => s.SachTacGias).ThenInclude(x => x.TacGia)
            .Where(s => s.MaNXB == f.MaNXB && s.NamXuatBan == f.NamXuatBan && s.HinhThuc == f.HinhThuc && s.MaSach != maSachDangSua)
            .ToListAsync();
        var ten = KiemTraDinhDang.ChuanHoaChuDeSoTrung(f.TenSach);
        var boTacGia = tacGia.Select(KiemTraDinhDang.ChuanHoaChuDeSoTrung).ToHashSet();
        var trung = ungVien.FirstOrDefault(s => KiemTraDinhDang.ChuanHoaChuDeSoTrung(s.TenSach) == ten
            && s.SachTacGias.Select(x => KiemTraDinhDang.ChuanHoaChuDeSoTrung(x.TacGia?.TenTacGia)).ToHashSet().SetEquals(boTacGia));
        if (trung is not null)
            ModelState.AddModelError(nameof(f.TenSach), $"Đã có sách mã {trung.MaSach} trùng cả tên, tác giả, nhà xuất bản, năm và hình thức");
        return tacGia;
    }

    /// <summary>Tìm tác giả theo tên (không phân biệt hoa thường, dấu); chưa có thì tạo mới.</summary>
    private async Task<List<SachTacGia>> LayTacGia(List<string> ten)
    {
        var tatCa = await db.TacGia.ToListAsync();
        var kq = new List<SachTacGia>();
        foreach (var t in ten)
        {
            var tg = tatCa.FirstOrDefault(x => KiemTraDinhDang.ChuanHoaChuDeSoTrung(x.TenTacGia) == KiemTraDinhDang.ChuanHoaChuDeSoTrung(t));
            if (tg is null) { tg = new TacGia { TenTacGia = t }; db.TacGia.Add(tg); tatCa.Add(tg); }
            kq.Add(new SachTacGia { TacGia = tg });
        }
        return kq;
    }
}