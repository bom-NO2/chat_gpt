using Microsoft.AspNetCore.Mvc;
using NhaSachOnline.Common;

namespace NhaSachOnline.Controllers
{
    /// <summary>
    /// Nút đổi vai tạm (khách / nhân viên / quản lý) vì Sprint 2 chưa có đăng nhập.
    /// </summary>
    public class VaiTroController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return RedirectToAction("Index", "Sach");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DoiVai(string vaiTro, string? returnUrl = null)
        {
            if (!VaiTroHienTai.Dat(HttpContext.Session, vaiTro))
            {
                TempData["Loi"] = "Vai trò không hợp lệ. Chỉ chấp nhận: Khach, NhanVien, QuanLy.";
            }
            else
            {
                TempData["ThanhCong"] = $"Đã chuyển sang vai: {VaiTroHienTai.Doc(HttpContext.Session)}";
            }

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("Index", "Sach");
        }
    }
}
