# Website bán sách trực tuyến (NhaSachOnline)

Đồ án môn Công nghệ phần mềm, nhóm 5 người: Vũ Đình Hùng (nhóm trưởng), Đỗ Thị Huyền, Phạm Quang Huy, Nguyễn Anh Kiệt, Lê Hoàng Lâm.

Sprint 4 (16/10–20/10/2026): nhóm làm lại Sprint 1 (thiết kế) và Sprint 2 (kết nối cơ sở dữ liệu, quản lý sách). Mỗi thành viên làm một phần trên nhánh riêng; xem `HUONG_DAN_GIT.md`.

## Công nghệ
- C#, ASP.NET Core MVC (.NET 10), Visual Studio 2026
- SQL Server trên máy (localhost), Entity Framework Core

## Cách chạy
1. Cài .NET SDK 10 và SQL Server (Developer hoặc Express).
2. Tạo cơ sở dữ liệu: mở SSMS, kết nối `localhost`, chạy lần lượt `database/01_tao_bang.sql` và `database/02_du_lieu_mau.sql` (hai file này có sau thẻ S4-L2).
3. Mở `NhaSachOnline.slnx` bằng Visual Studio, bấm F5. Hoặc chạy lệnh `dotnet run --project NhaSachOnline`.

## Nhật ký dùng AI
Thầy cho dùng AI hỗ trợ nhưng phải cho biết đã prompt thế nào. Mỗi thẻ có một file `docs/prompt/<tên>-<mã thẻ>.md`, ví dụ `docs/prompt/hung-s4-h7.md`, ghi: công cụ AI, prompt nguyên văn, phần giữ lại, phần tự sửa và lý do.

## Bàn giao S4-L4

Chức năng thêm sách đã tích hợp trên bản master được cung cấp. Xem [hướng dẫn, kết quả và giới hạn kiểm thử](docs/S4-L4/BAN-GIAO.md), [nội dung PR](docs/S4-L4/PR.md), [nhật ký AI](docs/prompt/lam-s4-l4.md).
