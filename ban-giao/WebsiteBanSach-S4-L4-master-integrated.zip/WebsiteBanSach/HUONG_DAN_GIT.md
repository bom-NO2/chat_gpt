# Hướng dẫn Git cho nhóm (Sprint 4)

Thầy yêu cầu: mỗi thành viên một nhánh, có nhánh chính `master`, mỗi người có commit của chính mình. Không ai commit hộ ai.

## 1. Lần đầu (mỗi người làm một lần)
```
git clone https://github.com/James-Lloyd20/WebsiteBanSach.git
cd WebsiteBanSach
git config user.name "Họ Tên Của Bạn"
git config user.email "email-github-cua-ban@example.com"
git checkout -b <nhánh của bạn>
```
Nhánh: `hung`, `huyen`, `huy`, `kiet`, `lam`.

## 2. Mỗi lần làm xong một bước
```
git add <các file của thẻ mình>
git commit -m "S4-xx: <việc vừa làm>"
git push -u origin <nhánh của bạn>
```
Commit ghi mã thẻ ở đầu, ví dụ `S4-L4: Kiểm tra trùng cả bộ khi thêm sách`. Sửa lỗi sau kiểm thử thì ghi mã ca, ví dụ `S4-L4: Sửa TC13 giữ dữ liệu khi báo lỗi`.

## 3. Khi thẻ xong: tạo Pull Request vào master
1. Lấy bản mới nhất của master về nhánh mình trước: `git pull origin master`. Nếu báo xung đột, mở file bị xung đột, giữ cả phần của mình và phần của bạn khác, chạy thử lại rồi commit.
2. Lên GitHub, tạo Pull Request từ nhánh của bạn vào `master`, ghi mã thẻ và link thẻ Trello.
3. Người kiểm tra của thẻ xem Pull Request, ghi nhận xét. Đạt thì gộp; chưa đạt thì người làm sửa tiếp trên nhánh của mình.

## 4. Thứ tự gộp vào master
Nhiều phần cùng sửa `SachController.cs` và `Views/Sach/Index.cshtml`, nên gộp theo thứ tự này để ít xung đột:
1. S4-L2 (Lâm): CSDL, Model, kết nối
2. S4-K1 (Kiệt): Common, nút đổi vai tạm
3. S4-U1 (Huyền): bố cục chung
4. S4-U4 (Huyền): phần 1 danh sách, tìm kiếm
5. S4-L4 (Lâm): phần 3 thêm sách (đưa `_BieuMau.cshtml` lên sớm)
6. S4-H7 (Hùng): phần 4 sửa sách
7. S4-Y4 (Huy): phần 5 chi tiết, ẩn/hiện, duyệt, xóa
8. S4-K3 (Kiệt): phần 2 lọc, sắp xếp, phân trang

Mỗi người thêm hàm của phần mình vào `SachController.cs`, không sửa hàm của phần người khác. Cần đổi chỗ dùng chung thì ghi issue trên thẻ để nhóm trưởng điều phối.

## 5. File nào thuộc thẻ nào
| Thẻ | Người | File chính |
|---|---|---|
| S4-L2 | Lâm | `database/*`, `NhaSachOnline/Models/Sach.cs`, `DanhMuc.cs`, `NhaSachContext.cs`, `appsettings.json`, `Program.cs` |
| S4-K1 | Kiệt | `NhaSachOnline/Common/*`, `Controllers/VaiTroController.cs` |
| S4-U1 | Huyền | `Views/Shared/_Layout.cshtml`, `_Layout.cshtml.css`, `wwwroot/css/site.css`, `wwwroot/js/site.js` |
| S4-U4 | Huyền | `Controllers/SachController.cs` (hàm Index phần danh sách, tìm kiếm), `Views/Sach/Index.cshtml` (phần danh sách), `Models/SachViewModels.cs` (SachTimKiem, SachDanhSach) |
| S4-K3 | Kiệt | `SachController.cs` (Index phần lọc, sắp xếp, phân trang), `Views/Sach/Index.cshtml` (bộ lọc, sắp xếp, phân trang) |
| S4-L4 | Lâm | `SachController.cs` (Them, KiemTraBieuMau, LayTacGia, NapDanhMuc, GanThongTin), `Views/Sach/Them.cshtml`, `_BieuMau.cshtml`, `SachBieuMau` |
| S4-H7 | Hùng | `SachController.cs` (Sua), `Views/Sach/Sua.cshtml` |
| S4-Y4 | Huy | `SachController.cs` (ChiTiet, DoiTrangThai, Duyet, Xoa), `Views/Sach/ChiTiet.cshtml` |
| S4-Y3 | Huy | `wwwroot/images/bia-mau/*` |

## 6. Không đưa lên Git
`bin/`, `obj/`, `.vs/`, ảnh bìa tải lên trong `wwwroot/images/sach/` (đã có trong `.gitignore`).
