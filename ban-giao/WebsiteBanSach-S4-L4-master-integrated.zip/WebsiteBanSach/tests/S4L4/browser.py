"""Browser checks against --browser-host. Requires Playwright and a Chromium browser."""
import os, re, base64, uuid
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'docs/S4-L4/screenshots'
OUT.mkdir(parents=True, exist_ok=True)
BASE=os.environ.get('S4L4_BROWSER_URL','http://localhost:5000')
passed=0
BOOK='ZZZZ S4L4 Browser Book '+uuid.uuid4().hex[:8]

def check(ok,label):
 global passed
 assert ok,label
 passed+=1
 print('PASS '+label,flush=True)

with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1366,'height':900})
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE+'/Sach/Them')
 expect(page.locator('.alert-danger')).to_contain_text('không có quyền')
 check('/Sach/Them' not in page.url,'TC10 browser guest redirected')
 page.screenshot(path=str(OUT/'TC10-guest.png'),full_page=True)
 page.locator('#nutDoiVaiSession').click()
 expect(page.locator('#nutDoiVaiSession')).to_contain_text('Nhân viên')
 check(True,'role button changes server Session')
 page.get_by_role('link',name='Thêm sách',exact=True).click()
 page.locator('#TenSach').fill(BOOK)
 page.locator('#MaTheLoai').select_option('1')
 page.locator('#MaNXB').select_option('1')
 page.locator('#NamXuatBan').fill('2026')
 page.locator('#GiaBan').fill('99001')
 page.locator('input[name="TacGia"]').first.fill('Tác giả Một')
 page.locator('#nut-them-tac-gia').click()
 page.locator('input[name="TacGia"]').nth(1).fill('Tác giả Hai')
 page.locator('#nut-them-tac-gia').click()
 check(page.locator('input[name="TacGia"]').count()==3,'author add buttons create three rows')
 page.locator('.nut-bo-tac-gia').nth(2).click()
 check(page.locator('input[name="TacGia"]').count()==2,'author remove button removes selected row')
 page.locator('#nut-them-tac-gia').click() # retain blank row for TC11
 png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a9N8AAAAASUVORK5CYII=')
 page.locator('#AnhBiaMoi').set_input_files({'name':'cover.png','mimeType':'image/png','buffer':png})
 page.get_by_role('button',name='Lưu sách',exact=True).click()
 expect(page.locator('tbody tr').first).to_have_class('table-success')
 expect(page.locator('tbody tr').first).to_contain_text(BOOK)
 expect(page.locator('tbody tr').first).to_contain_text('Chờ quản lý duyệt')
 expect(page.get_by_role('navigation',name='Phân trang sách')).to_contain_text('Trang 1 /')
 check(True,'TC11 browser valid price 99001, pending, first row, highlight, page 1')
 page.screenshot(path=str(OUT/'TC11-created-desktop.png'),full_page=True)
 page.set_viewport_size({'width':390,'height':844})
 page.screenshot(path=str(OUT/'TC11-created-mobile.png'),full_page=True)
 page.set_viewport_size({'width':1366,'height':900})
 page.goto(BASE+'/Sach/Them')
 page.locator('#TenSach').fill('  '+BOOK.lower()+'  ')
 page.locator('#MaTheLoai').select_option('1');page.locator('#MaNXB').select_option('1')
 page.locator('#NamXuatBan').fill('2026');page.locator('#GiaBan').fill('99001')
 page.locator('input[name="TacGia"]').fill(' tác giả hai ')
 page.locator('#nut-them-tac-gia').click()
 page.locator('input[name="TacGia"]').nth(1).fill('TÁC GIẢ MỘT')
 page.get_by_role('button',name='Lưu sách',exact=True).click()
 expect(page.locator('[data-valmsg-for="TenSach"]')).to_contain_text('trùng cả tên')
 check(True,'TC12 browser duplicate with reversed author order rejected')
 page.screenshot(path=str(OUT/'TC12-duplicate.png'),full_page=True)
 page.goto(BASE+'/Sach/Them')
 page.locator('#TenSach').fill('')
 page.locator('#ISBN').fill('12345')
 page.locator('#GiaBan').fill('99001')
 page.locator('#MaTheLoai').select_option('1');page.locator('#MaNXB').select_option('1');page.locator('#NamXuatBan').fill('2026')
 # Disable client validation for this submit to exercise all server-side errors together.
 page.locator('form[enctype="multipart/form-data"]').evaluate('(form) => { form.noValidate=true; if(window.jQuery) jQuery(form).removeData("validator").off("submit.validate"); form.submit(); }')
 expect(page.locator('[data-valmsg-for="TenSach"]')).to_contain_text('Nhập tên sách')
 expect(page.locator('[data-valmsg-for="ISBN"]')).to_contain_text('ISBN phải gồm')
 expect(page.locator('[data-valmsg-for="TacGia"]')).to_contain_text('Nhập ít nhất một tác giả')
 expect(page.locator('#GiaBan')).to_have_value('99001')
 check(True,'TC13 browser server errors at fields and price retained')
 page.screenshot(path=str(OUT/'TC13-errors-desktop.png'),full_page=True)
 page.set_viewport_size({'width':390,'height':844})
 page.screenshot(path=str(OUT/'TC13-errors-mobile.png'),full_page=True)
 check(page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'),'mobile form has no horizontal overflow')
 # Keep a final author row so users can enter an author again.
 page.locator('.nut-bo-tac-gia').first.click()
 check(page.locator('input[name="TacGia"]').count()==1,'last author row remains available')
 check(not errors,'no browser JavaScript errors')
 browser.close()
print(f'RESULT: {passed} browser checks passed. Data provider is test EF InMemory, not SQL Server.')
