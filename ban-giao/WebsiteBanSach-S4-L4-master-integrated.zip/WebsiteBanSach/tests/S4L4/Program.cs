using System.Net;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using NhaSachOnline.Models;

// Only point S4L4_TEST_SQL_CONNECTION at a disposable database prepared from the supplied SQL scripts.
var sql = Environment.GetEnvironmentVariable("S4L4_TEST_SQL_CONNECTION");
await using var factory = new WebApplicationFactory<NhaSachOnline.AppMarker>().WithWebHostBuilder(b => b.ConfigureServices(services => {
    services.RemoveAll<NhaSachContext>();
    services.RemoveAll<DbContextOptions<NhaSachContext>>();
    services.RemoveAll<IDbContextOptionsConfiguration<NhaSachContext>>();
    services.AddDbContext<NhaSachContext>(o => {
        if (string.IsNullOrEmpty(sql)) o.UseInMemoryDatabase("S4L4-" + Environment.ProcessId);
        else o.UseSqlServer(sql);
    });
}));
if (args.Contains("--browser-host")) factory.UseKestrel(options => options.ListenLocalhost(5000));
Console.WriteLine(string.IsNullOrEmpty(sql) ? "Provider: EF InMemory (not SQL constraints)" : "Provider: SQL Server, supplied schema and sample data");
using (var scope = factory.Services.CreateScope()) {
    var db = scope.ServiceProvider.GetRequiredService<NhaSachContext>();
    if (string.IsNullOrEmpty(sql)) {
        db.TheLoai.Add(new TheLoai { MaTheLoai=1, TenTheLoai="Văn học", TrangThai=1 });
        db.NhaXuatBan.Add(new NhaXuatBan { MaNXB=1, TenNXB="NXB" });
        for (var i=0;i<55;i++) db.Sach.Add(new Sach {
            TenSach=$"AAA Sample {i:D3}", MaTheLoai=1, MaNXB=1, NamXuatBan=2026,
            HinhThuc=1, GiaBan=99000, TrangThai=1, NgayTao=DateTime.Now, NgayCapNhat=DateTime.Now,
            NguoiTao=1, NguoiCapNhat=1
        });
        await db.SaveChangesAsync();
    }
}
if (args.Contains("--browser-host")) {
    Console.WriteLine("BROWSER_HOST_READY: port 5000; disposable test data only. Stop with Ctrl+C.");
    await Task.Delay(Timeout.Infinite);
    return;
}
int passed=0;
void Check(bool ok, string name) {
    if (!ok) throw new Exception("FAIL " + name);
    Console.WriteLine("PASS " + name); passed++;
}
string Decode(string html) => WebUtility.HtmlDecode(html);
string Token(string html) => Regex.Match(html, "name=\"__RequestVerificationToken\"[^>]*value=\"([^\"]+)\"").Groups[1].Value;
using var client = factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect=false, BaseAddress=new Uri("https://localhost") });
async Task<string> Get(string path) => Decode(await client.GetStringAsync(path));
var index = await Get("/Sach");
var token=Token(index);
Check(token.Length>0, "Session role form renders CSRF token");
Check((await client.GetAsync("/Sach/Them")).StatusCode==HttpStatusCode.Redirect, "TC10 guest GET blocked");
var guestPost = await client.PostAsync("/Sach/Them",new FormUrlEncodedContent(new Dictionary<string,string>{{"__RequestVerificationToken",token}}));
Check(guestPost.StatusCode==HttpStatusCode.Redirect, "TC10 guest POST blocked with valid CSRF token");
async Task Role(string role) {
    var page=await Get("/Sach");
    var res=await client.PostAsync("/VaiTro/DoiVai",new FormUrlEncodedContent(new Dictionary<string,string> {
        ["__RequestVerificationToken"]=Token(page), ["vaiTro"]=role, ["returnUrl"]="/Sach"
    }));
    Check(res.StatusCode==HttpStatusCode.Redirect,"server Session role switch: " + role);
}
await Role("NhanVien");
index=await Get("/Sach");
Check(index.Contains("Thêm sách") && index.Contains("Nhân viên"), "staff role and add link visible");
var html=await Get("/Sach/Them");
token=Token(html);
Check(html.Contains("multipart/form-data") && html.Contains("ds-tac-gia"),"shared add form and multi-author controls rendered");
var marker="ZZZ-S4L4-"+Guid.NewGuid().ToString("N")[..10];
List<KeyValuePair<string,string>> Form(string name) => [
    new("__RequestVerificationToken",token), new("TenSach",name), new("ISBN",""),
    new("TacGia","Tác giả Một"),new("TacGia",""),new("TacGia","Tác giả Hai"),new("TacGia"," tác giả một "),
    new("MaTheLoai","1"),new("MaNXB","1"),new("NamXuatBan","2026"),new("HinhThuc","1"),
    new("GiaBan","99001"),new("SoLuongCoTheBan","7"),new("NguongSapHet","5"),new("KhoiLuongGram","300"),
    new("MoTa","Mô tả giữ lại <script>alert(1)</script>")
];
void Set(List<KeyValuePair<string,string>> f,string key,params string[] values) { f.RemoveAll(x=>x.Key==key);foreach(var v in values) f.Add(new(key,v)); }
async Task<HttpResponseMessage> Post(List<KeyValuePair<string,string>> f) => await client.PostAsync("/Sach/Them",new FormUrlEncodedContent(f));
var f=Form(marker);
f.Add(new("MaSach","999999"));f.Add(new("TrangThai","1"));f.Add(new("AnhBiaHienTai","/fake.png"));
var response=await Post(f);
Check(response.StatusCode==HttpStatusCode.Redirect,"TC11 valid staff create (blank/repeated author rows)");
int id;
using(var scope=factory.Services.CreateScope()) {
    var db=scope.ServiceProvider.GetRequiredService<NhaSachContext>();
    var book=await db.Sach.Include(x=>x.SachTacGias).SingleAsync(x=>x.TenSach==marker);
    id=book.MaSach;
    Check(book.TrangThai==TrangThaiSach.ChoDuyet && book.NguoiTao==1 && book.GiaBan==99001 && book.MaSach!=999999 && book.AnhBia==null,"TC11 server assigns pending status, creator and identity");
    Check(book.SachTacGias.Count==2,"TC11 two authors; empty and repeated rows removed");
}
index=await Get(response.Headers.Location!.ToString());
Check(Regex.IsMatch(index,@"<tbody>\s*<tr class=""table-success"">\s*<td>"+id+@"</td>"),"TC11 created book is first row and highlighted");
Check(index.Contains("Trang 1 /") && index.Contains("Chờ quản lý duyệt"),"TC11 first page and pending label");
var page2=await Get("/Sach?trang=2");
Check(page2.Contains("Trang 2 /") && Regex.Matches(index,"<tr class=").Count<=50,"pagination limits page to 50");
f=Form("  "+marker.ToLowerInvariant()+"  "); Set(f,"TacGia"," TÁC GIẢ HAI "," tác giả một ");
response=await Post(f);html=Decode(await response.Content.ReadAsStringAsync());
Check(response.IsSuccessStatusCode && html.Contains("trùng cả tên") && html.Contains("99001"),"TC12 normalized duplicate set rejected and price retained");
f=Form(marker);Set(f,"TacGia","Tác giả khác");response=await Post(f);
Check(response.StatusCode==HttpStatusCode.Redirect,"TC12b different author set is allowed");
f=Form("");Set(f,"ISBN","12345");Set(f,"TacGia","");response=await Post(f);html=Decode(await response.Content.ReadAsStringAsync());
Check(response.IsSuccessStatusCode && new[]{"Nhập tên sách","ISBN phải gồm","Nhập ít nhất một tác giả","99001"}.All(html.Contains),"TC13 errors at fields and valid input retained");
var rawHtml=await response.Content.ReadAsStringAsync();
Check(rawHtml.Contains("&lt;script&gt;") && !rawHtml.Contains("<script>alert(1)</script>"),"retained description is HTML encoded");
f=Form(marker+"-bad-number");Set(f,"GiaBan","abc");response=await Post(f);html=Decode(await response.Content.ReadAsStringAsync());
Check(response.IsSuccessStatusCode && html.Contains("value=\"abc\"") && html.Contains("field-validation-error"),"TC13 numeric binding error retains raw input");
foreach(var (key,value,label) in new[]{("MaNXB","999999","unknown publisher"),("MaTheLoai","999999","unknown genre"),("HinhThuc","9","invalid format"),("TacGia",new string('A',151),"long author"),("ISBN","abc1234567890","ISBN with letters"),("NguongSapHet","-1","negative threshold")}) {
    f=Form(marker+"-invalid");Set(f,key,value);response=await Post(f);html=Decode(await response.Content.ReadAsStringAsync());
    Check(response.IsSuccessStatusCode && html.Contains("data-valmsg-for=\""+key+"\"") && html.Contains("field-validation-error"),"field error: "+label);
}
Check((await client.PostAsync("/Sach/Them",new FormUrlEncodedContent(new Dictionary<string,string>()))).StatusCode==HttpStatusCode.BadRequest,"POST without antiforgery token rejected");
var png=Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a9N8AAAAASUVORK5CYII=");
async Task<HttpResponseMessage> Upload(string name,string fileName,byte[] bytes,string contentType) {
    using var multipart=new MultipartFormDataContent();
    foreach(var field in Form(name)) multipart.Add(new StringContent(field.Value),field.Key);
    var image=new ByteArrayContent(bytes);image.Headers.ContentType=new MediaTypeHeaderValue(contentType);
    multipart.Add(image,"AnhBiaMoi",fileName);
    return await client.PostAsync("/Sach/Them",multipart);
}
response=await Upload(marker+"-cover","cover.PNG",png,"image/png");
Check(response.StatusCode==HttpStatusCode.Redirect,"multipart image create succeeds");
using(var scope=factory.Services.CreateScope()) {
    var book=await scope.ServiceProvider.GetRequiredService<NhaSachContext>().Sach.SingleAsync(x=>x.TenSach==marker+"-cover");
    var path=Path.Combine(factory.Services.GetRequiredService<IWebHostEnvironment>().WebRootPath,book.AnhBia!.TrimStart('/'));
    Check(Regex.IsMatch(book.AnhBia,@"/images/bia/[a-f0-9]{32}\.png") && File.ReadAllBytes(path).SequenceEqual(png),"image saved with GUID and exact bytes");
    File.Delete(path);
}
foreach(var (name,bytes,type,label) in new[]{("bad.exe",png,"image/png","extension"),("big.png",new byte[2097153],"image/png","size"),("empty.png",Array.Empty<byte>(),"image/png","empty file"),("mime.png",png,"text/plain","content type")}) {
    response=await Upload(marker+"-bad-image",name,bytes,type);html=Decode(await response.Content.ReadAsStringAsync());
    Check(response.IsSuccessStatusCode && html.Contains("field-validation-error") && html.Contains("data-valmsg-for=\"AnhBiaMoi\""),"image rejection: "+label);
}
// Shared partial must continue to render and submit edit without creating a new identity.
html=await Get("/Sach/Sua/"+id);
Check(html.Contains("Lưu thay đổi") && html.Contains(marker),"edit still renders shared form");
f=Form(marker);Set(f,"__RequestVerificationToken",Token(html));Set(f,"GiaBan","99001");Set(f,"MaSach","999999");
response=await client.PostAsync("/Sach/Sua/"+id,new FormUrlEncodedContent(f));
Check(response.StatusCode==HttpStatusCode.Redirect,"edit excludes own book from duplicate check, ignores posted identity");
await Role("QuanLy");html=await Get("/Sach/Them");token=Token(html);
response=await Post(Form(marker+"-manager"));
Check(response.StatusCode==HttpStatusCode.Redirect,"manager create succeeds");
using(var scope=factory.Services.CreateScope()) {
    var book=await scope.ServiceProvider.GetRequiredService<NhaSachContext>().Sach.SingleAsync(x=>x.TenSach==marker+"-manager");
    Check(book.TrangThai==TrangThaiSach.HienThi && book.NguoiTao==4,"manager book is published with manager creator");
}
await Role("Khach");
index=await Get("/Sach?timTheo=ten&tuKhoa="+marker);
Check(!index.Contains(marker+"-cover") && !index.Contains("<td>"+id+"</td>") && index.Contains(marker+"-manager"),"guest list hides pending books and shows manager book");
Check((await client.GetAsync("/Sach/ChiTiet/"+id)).StatusCode==HttpStatusCode.NotFound,"pending book details hidden from guest");
Console.WriteLine($"RESULT: {passed} checks passed. JavaScript interaction requires browser checks.");
